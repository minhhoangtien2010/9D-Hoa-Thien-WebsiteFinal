using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using WebPage.ViewModel;

namespace WebPage.Services;

// Every read and mutation uses the existing account database. No browser balances.
public class PortalRepository(IConfiguration configuration) {
 public async Task<(List<NewsPoco> Items,int TotalCount)> AdminNewsAsync(string? category,int page) {
  using var c=Connection();using var results=await c.QueryMultipleAsync("sp_Web_Portal_Admin_News",new{category,page=Math.Max(1,page)},commandType:CommandType.StoredProcedure);
  return((await results.ReadAsync<NewsPoco>()).AsList(),await results.ReadSingleAsync<int>());
 }
 public async Task<NewsPoco?> AdminNewsDetailAsync(int id) {using var c=Connection();return await c.QuerySingleOrDefaultAsync<NewsPoco>("sp_Web_Portal_Admin_NewsDetail",new{id},commandType:CommandType.StoredProcedure);}
 public async Task SaveNewsAsync(NewsPoco m) {using var c=Connection();await c.ExecuteAsync("sp_Web_Portal_Admin_SaveNews",new{m.NewsID,m.Title,m.Excerpt,m.Content,m.Category,m.ThumbnailUrl,m.AuthorName,m.IsPublished,m.IsFeatured,m.ThumbnailFit,m.ThumbnailPositionX,m.ThumbnailPositionY,m.ThumbnailAspect},commandType:CommandType.StoredProcedure);}
 public async Task DeleteNewsAsync(int id) {using var c=Connection();await c.ExecuteAsync("sp_Web_Portal_Admin_DeleteNews",new{id},commandType:CommandType.StoredProcedure);}
 public async Task<List<DepositBonusPoco>> BonusesAsync() {using var c=Connection();return(await c.QueryAsync<DepositBonusPoco>("sp_Web_Portal_Admin_Bonuses",commandType:CommandType.StoredProcedure)).AsList();}
 public async Task SaveBonusAsync(DepositBonusPoco m) {using var c=Connection();await c.ExecuteAsync("sp_Web_Portal_Admin_SaveBonus",new{m.BonusId,m.MinAmount,m.BonusPercent,m.MaxBonus,m.IsActive},commandType:CommandType.StoredProcedure);}
 public async Task DeleteBonusAsync(int id) {using var c=Connection();await c.ExecuteAsync("sp_Web_Portal_Admin_DeleteBonus",new{id},commandType:CommandType.StoredProcedure);}
 public async Task<List<DepositLog>> DepositsAsync(string? username,int page) {using var c=Connection();return(await c.QueryAsync<DepositLog>("sp_Web_Portal_Admin_Deposits",new{username,page=Math.Max(1,page)},commandType:CommandType.StoredProcedure)).AsList();}
 public async Task<List<DailyCheckInHistoryPoco>> CheckInsAsync(string? username,int page) {using var c=Connection();return(await c.QueryAsync<DailyCheckInHistoryPoco>("sp_Web_Portal_Admin_CheckIns",new{username,page=Math.Max(1,page)},commandType:CommandType.StoredProcedure)).AsList();}
 private SqlConnection Connection() => new(configuration.GetConnectionString("DefaultConnection"));
 public async Task<List<AboutSectionPoco>> AboutAsync(bool admin = false) {
  using var c=Connection();
  return (await c.QueryAsync<AboutSectionPoco>("sp_Web_About_List",new{admin},commandType:CommandType.StoredProcedure)).AsList();
 }
 public async Task SaveAboutAsync(AboutSectionPoco m) {
  using var c=Connection(); await c.ExecuteAsync("sp_Web_About_Admin_Save",m,commandType:CommandType.StoredProcedure);
 }
 public async Task DeleteAboutAsync(int id) {using var c=Connection();await c.ExecuteAsync("sp_Web_About_Admin_Delete",new{id},commandType:CommandType.StoredProcedure);}
 public async Task<List<GachaConfig>> ConfigsAsync() {using var c=Connection();return(await c.QueryAsync<GachaConfig>("sp_Web_Gacha_Configs",commandType:CommandType.StoredProcedure)).AsList();}
 public async Task SaveConfigAsync(GachaConfig m) {using var c=Connection();await c.ExecuteAsync("sp_Web_Gacha_Admin_Config",m,commandType:CommandType.StoredProcedure);}
 public async Task<List<GachaPrize>> PrizesAsync() {using var c=Connection();return(await c.QueryAsync<GachaPrize>("sp_Web_Gacha_Admin_Prizes",commandType:CommandType.StoredProcedure)).AsList();}
 public async Task SavePrizeAsync(GachaPrize m) {using var c=Connection();await c.ExecuteAsync("sp_Web_Gacha_Admin_SavePrize",m,commandType:CommandType.StoredProcedure);}
 public async Task DeletePrizeAsync(int id) {using var c=Connection();await c.ExecuteAsync("sp_Web_Gacha_Admin_DeletePrize",new{id},commandType:CommandType.StoredProcedure);}
 public async Task<List<GachaLog>> PlayAsync(string username,string gameType,int count,string pick,Guid requestId) {
  using var c=Connection();return(await c.QueryAsync<GachaLog>("sp_Web_Gacha_Play",new{username,gameType,count,pick,requestId},commandType:CommandType.StoredProcedure)).AsList();
 }
 public async Task<List<GachaLog>> HistoryAsync(string? username,int page=1) {using var c=Connection();return(await c.QueryAsync<GachaLog>("sp_Web_Gacha_History",new{username,page=Math.Max(1,page)},commandType:CommandType.StoredProcedure)).AsList();}
 public async Task<bool> BeginDeliveryAsync(long id,string username) {using var c=Connection();return await c.ExecuteScalarAsync<int>("sp_Web_Gacha_BeginDelivery",new{id,username},commandType:CommandType.StoredProcedure)==1;}
 public async Task EndDeliveryAsync(long id,bool success) {using var c=Connection();await c.ExecuteAsync("sp_Web_Gacha_EndDelivery",new{id,success},commandType:CommandType.StoredProcedure);}
 public async Task<List<CharacterInfoViewModel>> CharactersAsync(string username) {
  using var c=Connection();var result=(await c.QueryAsync<CharacterInfoViewModel>("sp_Web_Portal_Characters",new{username},commandType:CommandType.StoredProcedure)).AsList();
  var catalog=await new AboutContentRepository(configuration).LoadAsync();
  foreach(var item in result){item.Name=WebPage.Helper.GameCharacterText.DisplayName(item.Name);item.Responsibility=catalog.RoleTitle(item.Faction,item.Responsibility);}
  return result;
 }
 public async Task<List<PortalUser>> UsersAsync(string? search) {using var c=Connection();return(await c.QueryAsync<PortalUser>("sp_Web_Portal_Admin_Users",new{search},commandType:CommandType.StoredProcedure)).AsList();}
 public async Task SaveUserAsync(PortalUser m) {using var c=Connection();await c.ExecuteAsync("sp_Web_Portal_Admin_SaveUser",new{m.Username,m.Email,m.FullName,m.Phone,m.Status},commandType:CommandType.StoredProcedure);}
 public async Task<List<GameRewardRow>> GameRewardsAsync(bool admin=false) {using var c=Connection();return(await c.QueryAsync<GameRewardRow>("sp_Web_Games_Catalog",new{admin},commandType:CommandType.StoredProcedure)).AsList();}
 public async Task<List<GachaConfig>> GamePricesAsync() {using var c=Connection();return(await c.QueryAsync<GachaConfig>("sp_Web_Games_Prices",commandType:CommandType.StoredProcedure)).AsList();}
 public async Task ConfigureGameRewardAsync(string gameType,int id,int weight,bool isActive) {using var c=Connection();await c.ExecuteAsync("sp_Web_Games_Admin_ConfigureReward",new{gameType,id,weight,isActive},commandType:CommandType.StoredProcedure);}
 public async Task<bool> DeleteGameRewardAsync(string gameType,int id) {using var c=Connection();return await c.ExecuteScalarAsync<bool>("sp_Web_Games_Admin_DeleteReward",new{gameType,id},commandType:CommandType.StoredProcedure);}
}
