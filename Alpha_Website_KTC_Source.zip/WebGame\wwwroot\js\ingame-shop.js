/* ES5 + IE11 DOM/XHR only. No wallet state or trusted identity comes from the browser. */
(function () {
    'use strict';
    var closeButtons = document.querySelectorAll('[data-ig-close]');
    var i;
    for (i = 0; i < closeButtons.length; i++) {
        closeButtons[i].addEventListener('click', function () {
            var hint = document.getElementById('igCloseHint');
            if (hint) hint.textContent = 'Nếu cửa sổ chưa đóng, dùng nút X của cửa sổ trong game.';
            try { window.close(); } catch (ignore) { }
        });
    }
    var icons = document.querySelectorAll('[data-ig-icon]');
    function iconFallback() {
        if (this.getAttribute('data-ig-fallback') === '1') return;
        this.setAttribute('data-ig-fallback', '1'); this.src = '/images/shop-item-placeholder.svg';
        if (!this.parentNode.querySelector('small')) { var label = document.createElement('small'); label.textContent = 'Ảnh minh họa'; this.parentNode.appendChild(label); }
    }
    for (i = 0; i < icons.length; i++) { icons[i].addEventListener('error', iconFallback); if (icons[i].complete && !icons[i].naturalWidth) iconFallback.call(icons[i]); }
    var form = document.getElementById('igTransaction'); if (!form) return;
    var modal = document.getElementById('igModal'), dialog = modal.querySelector('.ig-modal');
    var confirm = document.getElementById('igConfirm'), cancel = document.getElementById('igCancel');
    var quantity = document.getElementById('igQuantity'), recipient = document.getElementById('igRecipient');
    var message = document.getElementById('igModalMessage'), notice = document.getElementById('igNotice');
    var active = null, pending = false, opener = null;
    function money(value) { return String(Math.round(Number(value) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
    function setMessage(text, login) {
        message.textContent = text;
        if (login) { var link = document.createElement('a'); link.href = form.getAttribute('data-login-url'); link.textContent = 'Đăng nhập lại cửa hàng'; message.appendChild(link); }
    }
    function updateTotal() { var count = active && active.gift ? 1 : parseInt(quantity.value, 10); document.getElementById('igTotal').textContent = money((active ? active.price : 0) * (count > 0 ? count : 1)); }
    function open(button, gift) {
        opener = button; active = { id: button.getAttribute('data-item-id'), price: parseInt(button.getAttribute('data-item-price'), 10) || 0, gift: gift };
        document.getElementById('igModalTitle').textContent = gift ? 'Tặng vật phẩm' : 'Xác nhận mua';
        document.getElementById('igItemName').textContent = button.getAttribute('data-item-name');
        document.getElementById('igQuantityRow').style.display = gift ? 'none' : 'block';
        document.getElementById('igRecipientRow').style.display = gift ? 'block' : 'none';
        quantity.value = '1'; recipient.value = ''; pending = false; confirm.disabled = false; cancel.disabled = false;
        setMessage(''); updateTotal(); modal.className = 'ig-modal-backdrop ig-open'; modal.setAttribute('aria-hidden', 'false');
        (gift ? recipient : quantity).focus();
    }
    function close() {
        if (pending) return;
        modal.className = 'ig-modal-backdrop'; modal.setAttribute('aria-hidden', 'true'); active = null;
        if (opener && document.documentElement.contains(opener)) opener.focus();
    }
    var buy = document.querySelectorAll('[data-ig-buy]'), gifts = document.querySelectorAll('[data-ig-gift]');
    for (i = 0; i < buy.length; i++) buy[i].addEventListener('click', function () { open(this, false); });
    for (i = 0; i < gifts.length; i++) gifts[i].addEventListener('click', function () { open(this, true); });
    quantity.addEventListener('input', updateTotal); cancel.addEventListener('click', close);
    modal.addEventListener('click', function (event) { if (event.target === modal) close(); });
    document.addEventListener('keydown', function (event) {
        if (!active) return;
        if (event.keyCode === 27) { event.preventDefault(); close(); return; }
        if (event.keyCode !== 9) return;
        var candidates = dialog.querySelectorAll('a,button,input'), focusable = [], j;
        for (j = 0; j < candidates.length; j++) if (!candidates[j].disabled && (candidates[j].offsetWidth || candidates[j].offsetHeight)) focusable.push(candidates[j]);
        if (!focusable.length) { event.preventDefault(); dialog.focus(); return; }
        var first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    });
    confirm.addEventListener('click', function () {
        if (!active || pending) return;
        var count = 1, recipientName = recipient.value.replace(/^\s+|\s+$/g, '');
        if (!active.gift && (!/^\d{1,2}$/.test(quantity.value) || (count = parseInt(quantity.value, 10)) < 1 || count > 99)) { setMessage('Nhập số lượt mua từ 1 đến 99.'); return; }
        if (active.gift && !recipientName) { setMessage('Nhập tài khoản người nhận.'); return; }
        var token = form.querySelector('input[name="__RequestVerificationToken"]');
        if (!token) { setMessage('Phiên xác thực không hợp lệ.', true); return; }
        var body = 'itemId=' + encodeURIComponent(active.id) + '&__RequestVerificationToken=' + encodeURIComponent(token.value);
        body += active.gift ? '&recipientUsername=' + encodeURIComponent(recipientName) : '&quantity=' + encodeURIComponent(count);
        var request = new XMLHttpRequest(), handled = false;
        pending = true; confirm.disabled = true; cancel.disabled = true; setMessage('Đang xác nhận giao dịch…');
        function finish(text, uncertain, login) {
            if (handled) return; handled = true; pending = false; cancel.disabled = false; confirm.disabled = !!uncertain;
            setMessage(text, login);
        }
        request.open('POST', form.getAttribute(active.gift ? 'data-gift-url' : 'data-purchase-url'), true);
        request.timeout = 30000;
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        request.onreadystatechange = function () {
            if (request.readyState !== 4 || handled) return;
            if (request.status === 401 || request.status === 403 || request.status === 400) { finish('Phiên đăng nhập hoặc xác thực đã hết hạn.', true, true); return; }
            if (request.status < 200 || request.status >= 300) { finish('Chưa xác nhận được kết quả. Kiểm tra Lịch sử giao dịch trước khi thử lại.', true, false); return; }
            var result;
            try { result = JSON.parse(request.responseText); }
            catch (invalid) { finish('Không đọc được kết quả. Đăng nhập lại và kiểm tra Lịch sử giao dịch.', true, true); return; }
            if (typeof result.newBalance === 'number') document.getElementById('igBalance').textContent = money(result.newBalance);
            if (!result.success) { finish(result.message || 'Giao dịch chưa thành công.', false, false); return; }
            handled = true; pending = false; cancel.disabled = false; notice.textContent = result.message || 'Giao dịch thành công.'; notice.className = 'ig-notice'; notice.style.display = 'block'; close();
        };
        request.onerror = request.ontimeout = request.onabort = function () { finish('Kết nối gián đoạn. Kiểm tra Lịch sử giao dịch trước khi mua hoặc tặng lại.', true, false); };
        request.send(body);
    });
})();
