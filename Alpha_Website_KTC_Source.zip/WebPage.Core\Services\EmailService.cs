using WebPage.ConfigurationModels;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;

namespace WebPage.Services
{
    public class EmailService : IEmailService
    {
        private readonly SmtpSettings _settings;
        private readonly ILogger<EmailService> _logger;
        private readonly string _domain;

        public EmailService(IOptions<SmtpSettings> settings, IConfiguration configuration, ILogger<EmailService> logger)
        {
            _settings = settings.Value;
            _logger = logger;
            _domain = configuration["MyApplicationSettings:Domain"] ?? "http://localhost:5000";
        }

        public async Task SendVerificationEmailAsync(string toEmail, string username, string token)
        {
            var verifyUrl = $"{_domain.TrimEnd('/')}/Account/VerifyEmail?token={Uri.EscapeDataString(token)}";

            var htmlBody = $@"
<!DOCTYPE html>
<html>
<head>
    <meta charset=""utf-8""/>
    <style>
        body {{ font-family: 'Noto Sans', Arial, sans-serif; background: #0f0f23; color: #ffffff; margin: 0; padding: 20px; }}
        .container {{ max-width: 600px; margin: 0 auto; background: #1a1a2e; border: 1px solid rgba(201,179,137,0.2); border-radius: 8px; padding: 40px; }}
        .logo {{ text-align: center; color: #c9b389; font-size: 24px; font-weight: 700; margin-bottom: 10px; letter-spacing: 0.05em; }}
        .logo-sub {{ text-align: center; color: #888; font-size: 13px; margin-bottom: 30px; }}
        h2 {{ color: #c9b389; margin-bottom: 10px; }}
        .btn {{ display: inline-block; padding: 14px 36px; background: linear-gradient(135deg, #c9b389, #a08a5e); color: #1a1a2e; font-weight: 700; text-decoration: none; border-radius: 6px; margin: 20px 0; font-size: 15px; }}
        .footer {{ margin-top: 30px; font-size: 12px; color: #888; text-align: center; border-top: 1px solid rgba(201,179,137,0.15); padding-top: 20px; }}
    </style>
</head>
<body>
    <div class=""container"">
        <div class=""logo"">Cửu Long Thần Thánh</div>
        <div class=""logo-sub"">Cửu Long Tranh Bá</div>
        <h2>Xác Nhận Email</h2>
        <p>Xin chào <strong>{username}</strong>,</p>
        <p>Cảm ơn bạn đã đăng ký tài khoản. Vui lòng bấm nút bên dưới để xác nhận địa chỉ email của bạn:</p>
        <p style=""text-align: center;"">
            <a href=""{verifyUrl}"" class=""btn"">Xác Nhận Email</a>
        </p>
        <p style=""font-size: 13px; color: #aaa;"">Hoặc copy link sau vào trình duyệt:</p>
        <p style=""font-size: 12px; word-break: break-all; color: #c9b389;"">{verifyUrl}</p>
        <p style=""font-size: 13px; color: #aaa;"">Link này sẽ hết hạn sau 24 giờ.</p>
        <div class=""footer"">
            &copy; Cửu Long Thần Thánh. Email này được gửi tự động, vui lòng không trả lời.
        </div>
    </div>
</body>
</html>";

            await SendEmailAsync(toEmail, "Xác Nhận Email - Cửu Long Thần Thánh", htmlBody);
        }

        public async Task SendEmailAsync(string to, string subject, string htmlBody)
        {
            try
            {
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress(_settings.FromName, _settings.FromEmail));
                message.To.Add(MailboxAddress.Parse(to));
                message.Subject = subject;

                var bodyBuilder = new BodyBuilder
                {
                    HtmlBody = htmlBody
                };
                message.Body = bodyBuilder.ToMessageBody();

                using var client = new SmtpClient();

                var secureSocketOptions = _settings.UseSsl
                    ? SecureSocketOptions.StartTls
                    : SecureSocketOptions.None;

                await client.ConnectAsync(_settings.Host, _settings.Port, secureSocketOptions);

                if (!string.IsNullOrEmpty(_settings.Username))
                {
                    await client.AuthenticateAsync(_settings.Username, _settings.Password);
                }

                await client.SendAsync(message);
                await client.DisconnectAsync(true);

                _logger.LogInformation("Email sent to {To}: {Subject}", to, subject);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send email to {To}: {Subject}", to, subject);
                throw;
            }
        }
    }
}
