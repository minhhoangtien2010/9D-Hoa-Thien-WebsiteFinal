﻿using WebPage.ViewModel;

namespace WebPage.Services
{
    public class LoginResultViewModel
    {
        public bool Succeeded { get; set; }
        public string ErrorMessage { get; set; }
        public UserDataPoco UserData { get; set; } // Thông tin người dùng nếu thành công
        // Thêm các thuộc tính khác nếu cần (ví dụ: RequiresTwoFactor)
    }

    public class RegisterResultViewModel
    {
        public bool Succeeded { get; set; }
        public int ResultCode { get; set; } // Mã trả về từ SP (ví dụ: UserID hoặc mã lỗi)
        public string ErrorMessage { get; set; }
        public UserDataPoco UserData { get; set; } // Thông tin người dùng nếu đăng ký và đăng nhập ngay
    }
    public interface IAccountService
    {
        Task<LoginResultViewModel> LoginAsync(LoginModel model);
        Task<RegisterResultViewModel> RegisterAsync(RegisterModel model, string clientIpAddress);
        Task<bool> IsUsernameAvailableAsync(string username);
        Task<bool> IsEmailAvailableAsync(string email);
        Task LogoutAsync(); // Thêm hàm đăng xuất
    }
}
