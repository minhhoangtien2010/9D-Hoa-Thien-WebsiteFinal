using Microsoft.Extensions.Configuration;

namespace WebPage.Services
{
    public class FeatureService : IFeatureService
    {
        private readonly IConfiguration _configuration;

        public FeatureService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public bool IsEnabled(string featureName)
        {
            return _configuration.GetValue<bool>($"FeatureFlags:Enable{featureName}");
        }
    }
}
