using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace WebPage.Services
{
    public class ShopDeliveryService : IShopDeliveryService
    {
        private readonly string _cisConnectionString;
        private readonly ILogger<ShopDeliveryService> _logger;

        public ShopDeliveryService(IConfiguration configuration, ILogger<ShopDeliveryService> logger)
        {
            _cisConnectionString = configuration.GetConnectionString("CISConnection");
            _logger = logger;
        }

        public async Task<bool> DeliverItemToCashInventoryAsync(string userid, int cashItemId, int count)
        {
            if (count < 1 || cashItemId <= 0) return false;
            if (string.IsNullOrEmpty(_cisConnectionString))
            {
                _logger.LogWarning("CISConnection string not configured. Skipping cash item delivery for memberGuid={MemberGuid}, cashItemId={CashItemId}", userid, cashItemId);
                return false;
            }

            try
            {
                using var connection = new SqlConnection(_cisConnectionString);

                var sql = @"
                DECLARE @i INT=0;
                WHILE @i < @count BEGIN
                INSERT INTO [dbo].[Tbl_Cash_Inven]
                    ([item_code],
                     [item_user_id],
                     [item_server_code],
                     [item_present],
                     [order_input_date],
                     [item_send_id],
                     [item_send_memo])
                VALUES
                    (@cashItemId,
                     @userid,
                     0,
                     0,
                     GETDATE(),
                     NULL,
                     NULL);
                SET @i += 1; END;";

                var parameters = new DynamicParameters();
                parameters.Add("@userid", userid);
                parameters.Add("@cashItemId", cashItemId);
                parameters.Add("@count", count);

                await connection.OpenAsync();
                using var transaction = connection.BeginTransaction();
                await connection.ExecuteAsync(sql, parameters, transaction);
                transaction.Commit();

                _logger.LogInformation("Cash item delivery completed: memberGuid={MemberGuid}, cashItemId={CashItemId}, count={Count}",
                    userid, cashItemId, count);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to deliver cash item: memberGuid={MemberGuid}, cashItemId={CashItemId}, count={Count}",
                    userid, cashItemId, count);
                return false;
            }
        }
    }
}
