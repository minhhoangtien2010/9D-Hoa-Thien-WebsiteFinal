using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using WebPage.ConfigurationModels;
using WebPage.Helper;

namespace WebPage.Services;

public sealed class DepositRequestException(string message) : Exception(message);
public sealed record CreatedDeposit(int TransactionId, string OrderCode, string QrUrl, decimal Amount, DepositReceiver Receiver);

/// <summary>Applies shared receiver settings while retaining the original creation and credit procedures.</summary>
public sealed class DepositCheckoutService(DepositSettingsRepository settings, IGameRepository game,
    IOptions<SePaySettings> options, DepositIpnSecretStore ipnSecrets)
{
    public bool GatewayReady => options.Value.EnableGateway && ipnSecrets.IsConfigured
        && !string.IsNullOrWhiteSpace(options.Value.MerchantId) && !string.IsNullOrWhiteSpace(options.Value.SecretKey);
    public static bool ValidAmount(decimal amount) => amount >= 10000m && amount <= 50000000m && amount == decimal.Truncate(amount);
    public static string QrUrl(DepositReceiver receiver, string content, decimal amount) =>
        "https://qr.sepay.vn/img?acc=" + Uri.EscapeDataString(receiver.AccountNumber)
        + "&bank=" + Uri.EscapeDataString(receiver.BankName)
        + "&amount=" + amount.ToString("0", CultureInfo.InvariantCulture)
        + "&des=" + Uri.EscapeDataString(content) + "&template=" + Uri.EscapeDataString(receiver.QrTemplate);

    public async Task<CreatedDeposit> CreateAsync(string username, decimal amount, bool gateway = false)
    {
        if (!ValidAmount(amount)) throw new DepositRequestException("Nhập số tiền nguyên từ 10.000 đến 50.000.000 đ.");
        var receiver = await settings.GetCurrentAsync();
        if (!receiver.IsVisible) throw new DepositRequestException("Nạp xu đang được quản trị viên tạm ẩn. Hiện chưa nhận đơn nạp mới.");
        if (!receiver.IsEnabled) throw new DepositRequestException("Hệ thống đang tạm dừng tạo đơn nạp mới. Các đơn đã tạo vẫn được đối soát.");
        if (!DepositBankCatalog.IsSupported(receiver.BankName) || string.IsNullOrWhiteSpace(receiver.AccountNumber))
            throw new DepositRequestException("Thông tin nhận tiền chưa sẵn sàng. Vui lòng liên hệ quản trị.");
        if (gateway && (!receiver.EnableGateway || !GatewayReady))
            throw new DepositRequestException("Cổng thanh toán chưa sẵn sàng. Bạn có thể dùng QR chuyển khoản.");
        var id = await game.CreateDepositAsync(username, amount);
        if (id <= 0) throw new DepositRequestException("Không tạo được đơn nạp. Vui lòng thử lại.");
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var suffix = new string(RandomNumberGenerator.GetBytes(4).Select(b => chars[b % chars.Length]).ToArray());
        var code = $"{receiver.OrderPrefix}{id} {suffix}";
        // Never return a QR until its exact receiver and memo are durably captured.
        await settings.CaptureOrderAsync(id, receiver, code, gateway);
        return new(id, code, QrUrl(receiver, code, amount), amount, receiver);
    }

    public async Task<DepositOrderSnapshot?> FindOrderAsync(string? content, bool gateway = false)
    {
        if (string.IsNullOrWhiteSpace(content) || content.Length > 4096) return null;
        var snapshot = await settings.GetOrderForContentAsync(content, gateway);
        if (snapshot is not null) return snapshot;
        var baseline = await settings.GetLegacyReceiverAsync();
        if (string.IsNullOrWhiteSpace(baseline.OrderPrefix)) return null;
        var matches = Regex.Matches(content, @"(?<![A-Z0-9])" + Regex.Escape(baseline.OrderPrefix) + @"([0-9]+)(?![0-9])", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(100));
        var ids = matches.Select(m => int.TryParse(m.Groups[1].Value, out var id) ? id : 0).Where(id => id > 0).Distinct().ToList();
        if (ids.Count != 1) return null;
        // SQL limits legacy lookup to orders created before receiver management was installed.
        var legacy = await settings.GetLegacyOrderAsync(ids[0]);
        if (legacy is not null) legacy.IsGateway = gateway;
        return legacy;
    }

    public static bool MatchesReceiver(DepositOrderSnapshot order, string? bank, string? accountNumber) =>
        DepositBankCatalog.SameBank(order.BankName, bank)
        && !string.IsNullOrWhiteSpace(accountNumber)
        && string.Equals(order.AccountNumber.Trim(), accountNumber.Trim(), StringComparison.OrdinalIgnoreCase);

    public static bool SecretMatches(string? expected, string? provided)
    {
        if (string.IsNullOrWhiteSpace(expected) || string.IsNullOrWhiteSpace(provided) || provided.Length > 4096) return false;
        return CryptographicOperations.FixedTimeEquals(SHA256.HashData(Encoding.UTF8.GetBytes(expected)), SHA256.HashData(Encoding.UTF8.GetBytes(provided)));
    }
    public static int GatewayTransactionKey(string id)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes("SePayGateway:" + id));
        var key = System.Buffers.Binary.BinaryPrimitives.ReadInt32BigEndian(bytes) & int.MaxValue;
        return key > 0 ? key : 1;
    }
}

/// <summary>Dedicated SePay IPN key, independent of the merchant signing key; never rendered back to Admin.</summary>
public sealed class DepositIpnSecretStore(IConfiguration configuration)
{
    private string SecretFile => configuration["SePaySettings:IpnSecretFile"] ?? Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "HoaThienPortal", "sepay-ipn-secret.dpapi");
    public bool IsConfigured => !string.IsNullOrWhiteSpace(Read());
    public string? Read()
    {
        var configured = configuration["SePaySettings:GatewayIpnSecret"];
        if (!string.IsNullOrWhiteSpace(configured)) return configured;
        if (!OperatingSystem.IsWindows()) return null;
        try
        {
            if (!File.Exists(SecretFile)) return null;
            var bytes = ProtectedData.Unprotect(File.ReadAllBytes(SecretFile), null, DataProtectionScope.LocalMachine);
            try { return Encoding.UTF8.GetString(bytes); }
            finally { CryptographicOperations.ZeroMemory(bytes); }
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or CryptographicException) { return null; }
    }
    public void Save(string secret)
    {
        if (!OperatingSystem.IsWindows()) throw new IOException("Máy chủ này cần cấu hình khóa IPN bằng biến môi trường riêng.");
        if (!string.IsNullOrWhiteSpace(configuration["SePaySettings:GatewayIpnSecret"])) throw new IOException("Khóa IPN đang do cấu hình máy chủ quản lý. Cập nhật tại cấu hình máy chủ.");
        var bytes = Encoding.UTF8.GetBytes(secret);
        try
        {
            var directory = Path.GetDirectoryName(SecretFile)!;
            // The shared private directory is created with restricted ACL by the server setup.
            if (!Directory.Exists(directory)) throw new IOException("Chưa có thư mục bí mật máy chủ. Cần thiết lập quyền đọc/ghi cho tiến trình website.");
            var encrypted = ProtectedData.Protect(bytes, null, DataProtectionScope.LocalMachine);
            var temporary = SecretFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try { File.WriteAllBytes(temporary, encrypted); File.Move(temporary, SecretFile, true); }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
        finally { CryptographicOperations.ZeroMemory(bytes); }
    }
}
