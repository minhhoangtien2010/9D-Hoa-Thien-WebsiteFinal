﻿using WebPage.ViewModel;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace WebPage.Services
{
    public class AccountService : IAccountService
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AccountService> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AccountService(
            IUserRepository userRepository,
            IConfiguration configuration,
            ILogger<AccountService> logger,
            IHttpContextAccessor httpContextAccessor)
        {
            _userRepository = userRepository;
            _configuration = configuration;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<LoginResultViewModel> LoginAsync(LoginModel model)
        {
            try
            {
                // sp_Web_Login nhan plain text password va tu hash MD5 trong SP
                var (loginStatus, userData) = await _userRepository.ValidateUserCredentialsAsync(model.UserName, model.Password);

                // Web login: cho phep dang nhap ca khi chua verify email (status -4)
                // Verify email check is delegated to other clients as needed
                if ((loginStatus == 1 || loginStatus == -4) && userData != null && userData.UserID > 0)
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, userData.UserName),
                        new Claim(ClaimTypes.NameIdentifier, userData.UserID.ToString()),
                        new Claim("UserId", userData.UserID.ToString()),
                        new Claim("FullName", userData.FullName ?? ""),
                        new Claim(ClaimTypes.Role, userData.Role ?? "User"),
                    };
                    var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var authProperties = new AuthenticationProperties { };

                    await _httpContextAccessor.HttpContext.SignInAsync(
                        CookieAuthenticationDefaults.AuthenticationScheme,
                        new ClaimsPrincipal(claimsIdentity),
                        authProperties);

                    _logger.LogInformation("User {UserName} logged in successfully (status={Status}).", model.UserName, loginStatus);
                    return new LoginResultViewModel { Succeeded = true, UserData = userData };
                }
                else
                {
                    _logger.LogWarning("Login attempt failed for {UserName}, status={Status}.", model.UserName, loginStatus);
                    string errorMsg = loginStatus switch
                    {
                        -3 => "Tài khoản đã bị khóa!",
                        _ => "Thông tin không chính xác!"
                    };
                    return new LoginResultViewModel { Succeeded = false, ErrorMessage = errorMsg };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login for user {UserName}.", model.UserName);
                return new LoginResultViewModel { Succeeded = false, ErrorMessage = "Lỗi hệ thống, hãy thử lại sau..." };
            }
        }

        public async Task<RegisterResultViewModel> RegisterAsync(RegisterModel model, string clientIpAddress)
        {
            try
            {
                if (await IsUsernameAvailableAsync(model.UserName) == false)
                {
                    return new RegisterResultViewModel { Succeeded = false, ErrorMessage = "Tài khoản đã tồn tại" };
                }
                if (await IsEmailAvailableAsync(model.Email) == false)
                {
                    return new RegisterResultViewModel { Succeeded = false, ErrorMessage = "Email này đã tồn tại, Hãy chọn email khác" };
                }

                // sp_Web_Register nhan plain text password va tu hash MD5 qua pr_Create_Account
                int result = await _userRepository.CreateUserAsync(
                    model.UserName, model.Password, model.Email, model.Phone ?? "", clientIpAddress,
                    fullname: model.FullName, address: model.Address, accountCode: model.AccountCode,
                    question: model.Question, answer: model.Answer, inviteCode: model.InviteCode);

                if (result > 0)
                {
                    // result = member_guid = thanh cong
                    // Tu dong dang nhap sau khi dang ky
                    var loginModel = new LoginModel { UserName = model.UserName, Password = model.Password };
                    var loginResult = await LoginAsync(loginModel);

                    _logger.LogInformation("User {UserName} registered successfully (guid={Guid}).", model.UserName, result);
                    return new RegisterResultViewModel { Succeeded = true, ResultCode = result, UserData = loginResult.UserData };
                }
                else
                {
                    string errorMsg = result switch
                    {
                        -1 => "Tài khoản đã tồn tại",
                        -2 => "Email đã được sử dụng",
                        -3 => "Lỗi tạo tài khoản game. Vui lòng thử lại.",
                        _ => "Dang ky that bai. Ma loi: " + result
                    };
                    return new RegisterResultViewModel { Succeeded = false, ResultCode = result, ErrorMessage = errorMsg };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during registration for user {UserName}.", model.UserName);
                return new RegisterResultViewModel { Succeeded = false, ErrorMessage = "Lỗi hệ thống, hãy thử lại..." };
            }
        }

        public async Task<bool> IsUsernameAvailableAsync(string username)
        {
            return !(await _userRepository.CheckUserExistsAsync(username));
        }

        public async Task<bool> IsEmailAvailableAsync(string email)
        {
            return !(await _userRepository.CheckEmailExistsAsync(email));
        }

        public async Task LogoutAsync()
        {
            await _httpContextAccessor.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            _logger.LogInformation("User logged out.");
        }
    }
}
