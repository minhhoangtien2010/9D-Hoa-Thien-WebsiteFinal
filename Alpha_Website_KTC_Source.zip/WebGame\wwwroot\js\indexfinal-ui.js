/* Presentation only: mark the current route without intercepting links or forms. */
(function () {
    "use strict";
    var path = window.location.pathname.replace(/\/$/, "").toLowerCase() || "/";
    var query = new URLSearchParams(window.location.search);
    var category = (query.get("category") || "").toLowerCase();
    document.querySelectorAll("nav.main a, nav.tabbar a").forEach(function (link) {
        var target = new URL(link.href, window.location.origin);
        var targetPath = target.pathname.replace(/\/$/, "").toLowerCase() || "/";
        var home = targetPath === "/" || targetPath === "/home" || targetPath === "/home/index";
        var current = home ? ["/", "/home", "/home/index"].includes(path) :
            path === targetPath || (targetPath !== "/" && path.indexOf(targetPath + "/") === 0);
        if (targetPath === "/news" || targetPath === "/news/index") {
            current = path.indexOf("/news") === 0 && (target.searchParams.get("category") || "").toLowerCase() === category;
        }
        if (target.hash) current = current && target.hash === window.location.hash;
        if (targetPath === "/account/login" && target.searchParams.has("returnUrl")) {
            current = current && query.get("returnUrl") === target.searchParams.get("returnUrl");
        }
        if (current) link.setAttribute("aria-current", "page");
        else link.removeAttribute("aria-current");
    });
})();
