using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace WebPage.Services
{
    public class SpendingMilestoneService : ISpendingMilestoneService
    {
        private static readonly JsonSerializerOptions JsonOpts = new() { PropertyNameCaseInsensitive = true };

        private readonly IGameRepository _gameRepository;
        private readonly IShopDeliveryService _deliveryService;
        private readonly IFeatureService _featureService;
        private readonly ILogger<SpendingMilestoneService> _logger;

        public SpendingMilestoneService(
            IGameRepository gameRepository,
            IShopDeliveryService deliveryService,
            IFeatureService featureService,
            ILogger<SpendingMilestoneService> logger)
        {
            _gameRepository = gameRepository;
            _deliveryService = deliveryService;
            _featureService = featureService;
            _logger = logger;
        }

        public async Task ProcessAfterPurchaseAsync(string username)
        {
            if (string.IsNullOrEmpty(username)) return;

            // Honor runtime feature flag — turn off per-server via appsettings.json
            if (!_featureService.IsEnabled("SpendingMilestone")) return;

            try
            {
                var grants = await _gameRepository.TryGrantSpendingMilestonesAsync(username);
                if (grants.Count == 0) return;

                foreach (var g in grants)
                {
                    _logger.LogInformation(
                        "Spending milestone granted: user={User} milestone={Name}({Id}) coins={Coins} claim={ClaimId}",
                        username, g.MilestoneName, g.MilestoneID, g.RewardCoins, g.ClaimID);

                    var deliveryStatus = "Delivered";
                    string deliveryNote = null;

                    if (!string.IsNullOrWhiteSpace(g.RewardItems))
                    {
                        try
                        {
                            var items = JsonSerializer.Deserialize<List<GiftcodeRewardItem>>(g.RewardItems, JsonOpts);
                            if (items != null)
                            {
                                int failed = 0;
                                foreach (var item in items)
                                {
                                    var ok = await _deliveryService.DeliverItemToCashInventoryAsync(
                                        username, item.CashItemId, item.Quantity);
                                    if (!ok) failed++;
                                }

                                if (failed > 0)
                                {
                                    deliveryStatus = "Failed";
                                    deliveryNote = $"{failed}/{items.Count} item(s) failed to deliver to cash inventory";
                                    _logger.LogWarning(
                                        "Milestone item delivery partial failure: user={User} milestone={Id} failed={Failed}/{Total}",
                                        username, g.MilestoneID, failed, items.Count);
                                }
                            }
                        }
                        catch (JsonException jex)
                        {
                            deliveryStatus = "Failed";
                            deliveryNote = "RewardItems JSON parse error: " + jex.Message;
                            _logger.LogError(jex,
                                "Milestone RewardItems JSON invalid: user={User} milestone={Id}",
                                username, g.MilestoneID);
                        }
                    }

                    await _gameRepository.UpdateSpendingClaimStatusAsync(g.ClaimID, deliveryStatus, deliveryNote);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ProcessAfterPurchaseAsync failed for user={User}", username);
            }
        }
    }
}
