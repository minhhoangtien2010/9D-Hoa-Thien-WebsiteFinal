namespace WebPage.Services
{
    /// <summary>
    /// Orchestrates spending-milestone auto-grant after a successful shop purchase.
    /// No-op when feature flag "SpendingMilestone" is disabled.
    /// </summary>
    public interface ISpendingMilestoneService
    {
        /// <summary>
        /// Scan active milestones for the user, grant any newly-reached rewards, and deliver items
        /// via IShopDeliveryService. Idempotent (safe to call multiple times).
        /// </summary>
        Task ProcessAfterPurchaseAsync(string username);
    }
}
