using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebPage.Services;
using WebPage.ViewModel;

namespace WebPage.Controllers;

/// <summary>Small server-rendered shop for MSHTML hosts. Financial POSTs remain on the original Shop controller.</summary>
[Authorize]
[Route("InGame")]
[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public sealed class InGameController(IGameRepository game, IFeatureService features, IUserRepository users, IAccountService accounts) : Controller
{
    [HttpGet("")]
    public IActionResult Index() => RedirectToAction(nameof(Shop));

    private async Task<bool> IsActiveAccountAsync()
    {
        if (User.Identity?.Name is not { Length: > 0 } username) return false;
        var account = await users.GetUserByUsernameAsync(username);
        if (account?.IsActive == true) return true;
        await accounts.LogoutAsync();
        return false;
    }

    [HttpGet("Shop")]
    public async Task<IActionResult> Shop(int? categoryId, int page = 1)
    {
        if (!features.IsEnabled("Shop")) return NotFound();
        if (!await IsActiveAccountAsync()) return Challenge();
        Response.Headers["X-UA-Compatible"] = "IE=edge";
        page = Math.Clamp(page, 1, 10000);
        if (categoryId <= 0) categoryId = null;
        var categories = game.GetShopCategoriesAsync();
        var catalog = game.GetShopItemsAsync(categoryId, page, 12);
        var balance = game.GetUserBalanceAsync(User.Identity!.Name!);
        await Task.WhenAll(categories, catalog, balance);
        var (items, totalCount) = await catalog;
        return View(new InGameShopViewModel
        {
            Categories = await categories, Items = items, Balance = await balance, CategoryId = categoryId,
            CurrentPage = page, TotalCount = totalCount, TotalPages = (int)Math.Ceiling(totalCount / 12m)
        });
    }

    [HttpGet("History")]
    public async Task<IActionResult> History(int page = 1)
    {
        if (!features.IsEnabled("Shop")) return NotFound();
        if (!await IsActiveAccountAsync()) return Challenge();
        Response.Headers["X-UA-Compatible"] = "IE=edge";
        page = Math.Clamp(page, 1, 10000);
        var (items, totalCount) = await game.GetShopPurchaseHistoryAsync(User.Identity!.Name!, page, 15);
        return View(new InGameHistoryViewModel { Items = items, CurrentPage = page, TotalPages = (int)Math.Ceiling(totalCount / 15m) });
    }

    [HttpPost("Logout"), ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await accounts.LogoutAsync();
        return RedirectToAction("Login", "Account", new { area = "", returnUrl = Url.Action(nameof(Shop)) });
    }
}
