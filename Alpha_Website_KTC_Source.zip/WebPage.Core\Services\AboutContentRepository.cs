using System.Data;
using System.Globalization;
using System.Xml.Linq;
using Dapper;
using Microsoft.Data.SqlClient;
using WebPage.Helper;

namespace WebPage.Services;

public sealed record AboutContentField(string FieldKey, string GroupKey, string GroupName, string Label,
    string Value, string Kind, int SortOrder)
{
    public AboutContentField() : this("", "", "", "", "", "short", 0) { }
    public string Version { get; init; } = "";
    public DateTime? UpdatedAt { get; init; }
    public string? UpdatedBy { get; init; }
}

public sealed record AboutFactionDefinition(string Key, string GameName, string Dao, string Accent);
public sealed record AboutFaction(string Key, string GameName, string Name, string Dao, string Accent,
    string Description, string Join, IReadOnlyList<string> Weapons, string Image, string Portrait,
    string ImageFemale, string PortraitFemale, IReadOnlyList<string> Lines);
public sealed record AboutWorld(string Name, string Description, IReadOnlyList<string> Places);
public sealed record AboutFeature(string Symbol, string Title, string Description);
public sealed class AboutContentHistoryEntry
{
    public long HistoryId { get; set; }
    public string FieldKey { get; set; } = "";
    public string Label { get; set; } = "";
    public string OldValue { get; set; } = "";
    public string NewValue { get; set; } = "";
    public string ChangedBy { get; set; } = "";
    public DateTime ChangedAt { get; set; }
}

/// <summary>One SQL snapshot per request; direct SQL changes are visible on the next request.</summary>
public sealed class AboutContentRepository(IConfiguration configuration)
{
    private Task<AboutContentDocument>? _document;
    private SqlConnection Connection() => new(configuration.GetConnectionString("DefaultConnection"));
    public Task<AboutContentDocument> LoadAsync() => _document ??= ReadAsync();
    public async Task<List<AboutContentHistoryEntry>> HistoryAsync(string? fieldKey, int page)
    {
        using var connection = Connection();
        return (await connection.QueryAsync<AboutContentHistoryEntry>("sp_Web_About_Admin_ContentHistory", new
        {
            FieldKey = string.IsNullOrWhiteSpace(fieldKey) ? null : fieldKey, Page = Math.Max(1, page)
        }, commandType: CommandType.StoredProcedure)).AsList();
    }
    private async Task<AboutContentDocument> ReadAsync()
    {
        using var connection = Connection();
        var fields = (await connection.QueryAsync<AboutContentField>("sp_Web_About_Content", commandType: CommandType.StoredProcedure)).AsList();
        return new AboutContentDocument(fields);
    }
    public async Task SaveAsync(IEnumerable<AboutContentValueInput> fields, string updatedBy)
    {
        using var connection = Connection();
        await connection.ExecuteAsync("sp_Web_About_Admin_ContentSave", new
        {
            FieldsXml = new XElement("fields", fields.Select(f => new XElement("field", new XAttribute("key", f.FieldKey),
                new XAttribute("version", f.Version), new XElement("value", f.Value ?? "")))).ToString(SaveOptions.DisableFormatting),
            UpdatedBy = updatedBy
        }, commandType: CommandType.StoredProcedure);
        _document = null;
    }
}

public sealed class AboutContentDocument
{
    public IReadOnlyList<AboutContentField> Fields { get; }
    private readonly IReadOnlyDictionary<string, AboutContentField> _values;
    private static readonly IReadOnlyDictionary<string, string> FactionKeys = AboutContentDefaults.Factions.ToDictionary(f => f.GameName, f => f.Key);
    public AboutContentDocument(IEnumerable<AboutContentField> fields)
    {
        // Missing rows still display the original page; existing SQL values, including blanks, win.
        var values = AboutContentDefaults.Fields.ToDictionary(f => f.FieldKey, StringComparer.Ordinal);
        foreach (var field in fields) values[field.FieldKey] = field;
        Fields = values.Values.OrderBy(f => f.SortOrder).ToList();
        _values = values;
    }
    public string Text(string key, string fallback = "") => _values.TryGetValue(key, out var field) ? field.Value : fallback;
    public bool Enabled(string sectionKey) => Text(sectionKey + ".visible", "1") == "1";
    public IReadOnlyList<string> Lines(string key) => Text(key).Split(new[] { '\r', '\n' }, StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
    public IReadOnlyList<string> RolesFor(string faction)
    {
        var defaults = GameDisplayCatalog.RolesFor(faction);
        return FactionKeys.TryGetValue(faction, out var key)
            ? Enumerable.Range(0, defaults.Count).Select(i => Text($"role.{key}.{i}", defaults[i])).ToList()
            : defaults;
    }
    public string RoleTitle(string? faction, string? responsibility)
    {
        var original = GameDisplayCatalog.RoleTitle(faction, responsibility);
        var defaults = GameDisplayCatalog.RolesFor(faction ?? "");
        for (var index = 0; index < defaults.Count; index++)
            if (defaults[index] == original) return RolesFor(faction ?? "")[index];
        return original;
    }
    public IReadOnlyList<CultivationRealm> Realms() => GameDisplayCatalog.Realms
        .Select((realm, index) => new CultivationRealm(Text($"realm.{index + 1}.name", realm.Name), realm.Start, realm.End)).ToList();
    public string CultivationTitle(string? level)
    {
        if (!int.TryParse(level, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number)) return "—";
        if (number == 0) return "Chưa nhập môn";
        return Realms().FirstOrDefault(realm => number >= realm.Start && number <= realm.End)?.Name ?? "—";
    }
    public IReadOnlyList<AboutFaction> Factions() => AboutContentDefaults.Factions.Select(f => new AboutFaction(
        f.Key, f.GameName, Text($"faction.{f.Key}.name", f.GameName), f.Dao, f.Accent,
        Text($"faction.{f.Key}.description"), Text($"faction.{f.Key}.join"), Lines($"faction.{f.Key}.weapons"),
        Text($"faction.{f.Key}.image"), Text($"faction.{f.Key}.portrait"), Text($"faction.{f.Key}.imageFemale"),
        Text($"faction.{f.Key}.portraitFemale"), RolesFor(f.GameName))).ToList();
    public IReadOnlyList<AboutWorld> Worlds() => Enumerable.Range(1, 5)
        .Select(index => new AboutWorld(Text($"world.{index}.name"), Text($"world.{index}.description"), Lines($"world.{index}.places"))).ToList();
    public IReadOnlyList<AboutFeature> Features() => Enumerable.Range(1, 6)
        .Select(index => new AboutFeature(Text($"feature.{index}.symbol"), Text($"feature.{index}.title"), Text($"feature.{index}.description"))).ToList();
}

public sealed class AboutContentValueInput
{
    public string FieldKey { get; set; } = "";
    public string? Value { get; set; }
    public string Version { get; set; } = "";
}
public sealed class AboutContentEditModel
{
    public string GroupKey { get; set; } = "presentation";
    public List<AboutContentValueInput> Fields { get; set; } = new();
}
public sealed record AboutImageEditorModel(AboutContentEditModel Model, int Index, AboutContentField Field);
