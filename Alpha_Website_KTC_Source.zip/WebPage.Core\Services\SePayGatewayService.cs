using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Serialization;
using WebPage.ConfigurationModels;
using Microsoft.Extensions.Options;

namespace WebPage.Services
{
    public class SePayGatewayService
    {
        private readonly SePaySettings _settings;

        public SePayGatewayService(IOptions<SePaySettings> settings)
        {
            _settings = settings.Value;
        }

        public SePayCheckoutForm BuildCheckoutForm(
            decimal amount,
            string invoiceNumber,
            string description,
            string customerId,
            string successUrl,
            string errorUrl,
            string cancelUrl,
            string? paymentMethod = null)
        {
            var fields = new Dictionary<string, string>
            {
                ["merchant"] = _settings.MerchantId,
                ["currency"] = "VND",
                ["order_amount"] = ((int)amount).ToString(),
                ["operation"] = "PURCHASE",
                ["order_description"] = description,
                ["order_invoice_number"] = invoiceNumber,
                ["customer_id"] = customerId,
                ["success_url"] = successUrl,
                ["error_url"] = errorUrl,
                ["cancel_url"] = cancelUrl
            };

            if (!string.IsNullOrEmpty(paymentMethod))
                fields["payment_method"] = paymentMethod;

            var signFieldOrder = new[]
            {
                "merchant", "operation", "payment_method", "order_amount", "currency",
                "order_invoice_number", "order_description", "customer_id",
                "success_url", "error_url", "cancel_url"
            };

            var signParts = new List<string>();
            foreach (var field in signFieldOrder)
            {
                if (fields.TryGetValue(field, out var value))
                    signParts.Add($"{field}={value}");
            }
            var signString = string.Join(",", signParts);

            var signature = ComputeHmacSha256(signString, _settings.SecretKey);
            fields["signature"] = signature;

            return new SePayCheckoutForm
            {
                ActionUrl = _settings.CheckoutUrl,
                Fields = fields
            };
        }

        private static string ComputeHmacSha256(string data, string secretKey)
        {
            var keyBytes = Encoding.UTF8.GetBytes(secretKey);
            var dataBytes = Encoding.UTF8.GetBytes(data);

            using var hmac = new HMACSHA256(keyBytes);
            var hashBytes = hmac.ComputeHash(dataBytes);
            return Convert.ToBase64String(hashBytes);
        }
    }

    public class SePayCheckoutForm
    {
        public string ActionUrl { get; set; } = string.Empty;
        public Dictionary<string, string> Fields { get; set; } = new();
    }

    public class SePayGatewayIpnPayload
    {
        [JsonPropertyName("timestamp")]
        public long Timestamp { get; set; }

        [JsonPropertyName("notification_type")]
        public string NotificationType { get; set; } = string.Empty;

        [JsonPropertyName("order")]
        public SePayGatewayOrder? Order { get; set; }

        [JsonPropertyName("transaction")]
        public SePayGatewayTransaction? Transaction { get; set; }
    }

    public class SePayGatewayOrder
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;

        [JsonPropertyName("order_id")]
        public string OrderId { get; set; } = string.Empty;

        [JsonPropertyName("order_status")]
        public string OrderStatus { get; set; } = string.Empty;

        [JsonPropertyName("order_currency")]
        public string OrderCurrency { get; set; } = string.Empty;

        [JsonPropertyName("order_amount")]
        public string OrderAmount { get; set; } = string.Empty;

        [JsonPropertyName("order_invoice_number")]
        public string OrderInvoiceNumber { get; set; } = string.Empty;

        [JsonPropertyName("order_description")]
        public string OrderDescription { get; set; } = string.Empty;

        [JsonPropertyName("ip_address")]
        public string? IpAddress { get; set; }
    }

    public class SePayGatewayTransaction
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;

        [JsonPropertyName("payment_method")]
        public string PaymentMethod { get; set; } = string.Empty;

        [JsonPropertyName("transaction_id")]
        public string TransactionId { get; set; } = string.Empty;

        [JsonPropertyName("transaction_type")]
        public string TransactionType { get; set; } = string.Empty;

        [JsonPropertyName("transaction_date")]
        public string TransactionDate { get; set; } = string.Empty;

        [JsonPropertyName("transaction_status")]
        public string TransactionStatus { get; set; } = string.Empty;

        [JsonPropertyName("transaction_amount")]
        public string TransactionAmount { get; set; } = string.Empty;

        [JsonPropertyName("transaction_currency")]
        public string TransactionCurrency { get; set; } = string.Empty;
    }
}
