using Microsoft.Extensions.FileProviders;
using System.Reflection;

namespace WebPage.Services;

public record ShopImage(string Url, bool IsPlaceholder);

/// <summary>Resolve legacy icon URLs without changing the shop catalog in SQL.</summary>
public class ShopImageService(IWebHostEnvironment environment, PublicMediaStorage media)
{
    public const string Placeholder = "/images/shop-item-placeholder.svg";
    private static readonly Lazy<IFileProvider?> ServerAssets = new(() =>
    {
        try
        {
            var assembly = Assembly.GetEntryAssembly();
            return assembly == null ? null : new ManifestEmbeddedFileProvider(assembly, "wwwroot");
        }
        catch { return null; }
    });

    public ShopImage Resolve(string? iconPath)
    {
        if (string.IsNullOrWhiteSpace(iconPath)) return new(Placeholder, true);
        var path = iconPath.Trim().Replace('\\', '/');
        if (Uri.TryCreate(path, UriKind.Absolute, out var remote) && remote.Scheme is "http" or "https")
            return new(path, false);
        path = "/" + path.TrimStart('~', '/');
        if (path.StartsWith("/uploads/", StringComparison.OrdinalIgnoreCase))
            return media.Exists(path) ? new(path, false) : new(Placeholder, true);
        if (path.Split('/').Contains("..") || !path.StartsWith("/images/", StringComparison.OrdinalIgnoreCase))
            return new(Placeholder, true);
        if (path.StartsWith("/images/shop/", StringComparison.OrdinalIgnoreCase))
            path = "/images/Shop/" + path[13..];
        var filePath = path.Split('?', '#')[0];
        var relativePath = filePath.TrimStart('/');
        if (filePath.StartsWith("/images/Shop/", StringComparison.OrdinalIgnoreCase))
        {
            var preserved = Path.GetFullPath(Path.Combine(media.RootPath, "legacy", "Shop", filePath[13..]));
            var expectedRoot = Path.Combine(media.RootPath, "legacy", "Shop") + Path.DirectorySeparatorChar;
            if (preserved.StartsWith(expectedRoot, StringComparison.OrdinalIgnoreCase) && File.Exists(preserved))
                return new(path, false);
        }
        return (environment.WebRootFileProvider.GetFileInfo(relativePath).Exists || ServerAssets.Value?.GetFileInfo(relativePath).Exists == true)
            ? new(path, false) : new(Placeholder, true);
    }
}
