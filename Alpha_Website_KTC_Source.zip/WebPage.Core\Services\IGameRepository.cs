namespace WebPage.Services
{
    // ============================================================
    // Data POCOs cho cac bang web
    // ============================================================

    public class NewsPoco
    {
        public int NewsID { get; set; }
        public string Title { get; set; }
        public string? Excerpt { get; set; }
        public string? Content { get; set; }
        public string Category { get; set; }
        public string ThumbnailFit { get; set; } = "cover";
        public int ThumbnailPositionX { get; set; } = 50;
        public int ThumbnailPositionY { get; set; } = 20;
        public string ThumbnailAspect { get; set; } = "wide";
        public string? ThumbnailUrl { get; set; }
        public string? AuthorName { get; set; }
        public bool IsPublished { get; set; }
        public bool IsFeatured { get; set; }
        public int ViewCount { get; set; }
        public DateTime PublishedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class RankingPoco
    {
        public int RankID { get; set; }
        public int Rank { get; set; }
        public string CharacterName { get; set; }
        public int Level { get; set; }
        public int Faction { get; set; }
        public int Responsibility { get; set; }
        public long Jin { get; set; }
        public string ClassGrade { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class TopPlayerPoco
    {
        public int? Gender { get; set; }
        public int Rank { get; set; }
        public string CharacterName { get; set; }
        public int Level { get; set; }
        public int Faction { get; set; }
        public int Class { get; set; }
        public string GuildName { get; set; }
        public string CaptainName { get; set; }
    }

    public class TopRichestPoco
    {
        public int Rank { get; set; }
        public string CharacterName { get; set; }
        public long Balance { get; set; }
    }

    public class TopOnlinePoco
    {
        public int? Gender { get; set; }
        public int Rank { get; set; }
        public string CharacterName { get; set; }
        public long PlayTime { get; set; }
        public int Faction { get; set; }
        public int Class { get; set; }
    }

    public class TopInfamyPoco
    {
        public int? Gender { get; set; }
        public int Rank { get; set; }
        public string CharacterName { get; set; }
        public long Gong { get; set; }
        public int Faction { get; set; }
        public int Class { get; set; }
    }

    public class TopHonorPoco
    {
        public int? Gender { get; set; }
        public int Rank { get; set; }
        public string CharacterName { get; set; }
        public long Honor { get; set; }
        public int Faction { get; set; }
        public int Class { get; set; }
    }

    public class FactionPoco
    {
        public int FactionID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string LoreContent { get; set; }
        public string ImageUrl { get; set; }
        public string IconUrl { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    public class ServerConfigPoco
    {
        public int ConfigID { get; set; }
        public string ConfigKey { get; set; }
        public string ConfigValue { get; set; }
        public string Description { get; set; }
        public DateTime UpdatedDate { get; set; }
    }

    public class DepositBonusPoco
    {
        public int BonusId { get; set; }
        public decimal MinAmount { get; set; }
        public int BonusPercent { get; set; }
        public decimal? MaxBonus { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class TransactionPoco
    {
        public int TransactionID { get; set; }
        public int UserID { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public decimal? Balance { get; set; }
        public string Status { get; set; }
        public string PaymentMethod { get; set; }
        public string TransactionRef { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class GiftcodePoco
    {
        public int GiftcodeID { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }
        public int MaxUses { get; set; }
        public int CurrentUses { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class GiftcodeRedeemResult
    {
        public int ResultCode { get; set; }
        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }
    }

    public class GiftcodeRewardItem
    {
        public int CashItemId { get; set; }
        public int Quantity { get; set; } = 1;
    }

    public class DailyCheckInRewardRulePoco
    {
        public int RewardRuleId { get; set; }
        public int DayNumber { get; set; }
        public int RewardCoins { get; set; }
        public bool IsActive { get; set; } = true;
        public int SortOrder { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class DailyCheckInHistoryPoco
    {
        public int Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public DateTime CheckInDate { get; set; }
        public int StreakDay { get; set; }
        public int RewardCoins { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class DailyCheckInStatePoco
    {
        public string Username { get; set; } = string.Empty;
        public int CurrentStreak { get; set; }
        public int TodayRewardCoins { get; set; }
        public int NextRewardCoins { get; set; }
        public int TotalClaimed { get; set; }
        public int Balance { get; set; }
        public DateTime? LastCheckInDate { get; set; }
        public bool CheckedInToday { get; set; }
        public bool CanCheckIn => !CheckedInToday;
        public string Message { get; set; } = string.Empty;
        public List<DailyCheckInHistoryPoco> RecentHistory { get; set; } = new();
    }

    public class DailyCheckInClaimResult
    {
        public int ResultCode { get; set; }
        public int RewardCoins { get; set; }
        public int StreakDay { get; set; }
        public int NewBalance { get; set; }
        public DateTime CheckInDate { get; set; }
        public string Message { get; set; } = string.Empty;
        public bool CheckedInToday { get; set; }
    }

    // ============================================================
    // Deposit Milestone POCOs
    // ============================================================

    public class DepositMilestonePoco
    {
        public int MilestoneID { get; set; }
        public string MilestoneName { get; set; }
        public decimal ThresholdAmount { get; set; }
        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }    // JSON: [{"cashItemId":123,"quantity":1}]
        public int RewardSpins { get; set; }       // vé Vòng Quay May Mắn tặng kèm
        public string Description { get; set; }

        // Cấu hình kỳ — cửa sổ tính tổng nạp
        public string PeriodType { get; set; }              // 'Lifetime' | 'Daily' | 'Weekly' | 'Monthly' | 'DateRange'
        public byte? WeekStartDay { get; set; }             // 1=Thứ 2..7=CN (khi PeriodType='Weekly')
        public DateTime? PeriodStartDate { get; set; }      // khi PeriodType='DateRange'
        public DateTime? PeriodEndDate { get; set; }
        public bool CountHistorical { get; set; } = true;   // false = chỉ tính nạp sau khi tạo mốc

        // Lặp lại CẢ CHUỖI: mọi mốc cùng kỳ là một chuỗi, nhận tuần tự, nhận hết
        // mốc chốt thì chuỗi reset. IsRepeatable/MaxClaims mang nghĩa cấp chuỗi
        // (SP lấy: repeatable nếu CÓ mốc nào bật; MaxClaims = max trong chuỗi).
        public bool IsRepeatable { get; set; }
        public int MaxClaims { get; set; }                  // 0 = vô hạn số chu kỳ

        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        // Trạng thái CHUỖI của user trong kỳ hiện hành (sp_Web_GetDepositMilestones tính sẵn)
        public string PeriodKey { get; set; }
        public DateTime PeriodRangeStart { get; set; }
        public DateTime PeriodRangeEnd { get; set; }
        public int LadderPos { get; set; }                  // 1 = mốc thấp nhất của chuỗi
        public decimal AnchorThreshold { get; set; }        // ngưỡng mốc chốt (cao nhất)
        public int CyclesCompleted { get; set; }            // số chu kỳ đã hoàn thành
        public int CurrentCycle { get; set; }               // chu kỳ đang chạy (1-based)
        public decimal EffectiveTotal { get; set; }         // tổng nạp trong kỳ, đã trừ chu kỳ đã xong
        public bool LadderFinished { get; set; }            // chuỗi đã hết chu kỳ cho phép
        public bool ClaimedThisCycle { get; set; }          // đã nhận mốc này trong chu kỳ hiện tại
        public bool PrevClaimed { get; set; }               // mốc ngay dưới đã nhận trong chu kỳ này
        public bool ReachedThreshold { get; set; }          // EffectiveTotal >= ThresholdAmount
        public bool ClaimableNow { get; set; }              // bấm nhận được ngay
        public DateTime? LastClaimedDate { get; set; }

        // Dùng cho trang admin
        public int TotalClaimedCount { get; set; }

        /// <summary>Bị khoá vì chưa nhận mốc thấp hơn trong chuỗi (dù đã đủ tiền).</summary>
        public bool LockedBySequence => !ClaimableNow && !ClaimedThisCycle && !LadderFinished && !PrevClaimed;

        /// <summary>Số tiền đã tích trong chu kỳ đang chạy, dùng cho thanh tiến độ của mốc này.</summary>
        public decimal CycleProgress
        {
            get
            {
                if (ThresholdAmount <= 0) return 0m;
                if (ClaimedThisCycle) return ThresholdAmount;       // đã nhận → đầy
                var left = EffectiveTotal;
                if (left < 0) return 0m;
                return left > ThresholdAmount ? ThresholdAmount : left;
            }
        }

        public int CyclePercent => ThresholdAmount <= 0
            ? 0
            : (int)Math.Min(100m, CycleProgress * 100m / ThresholdAmount);
    }

    public class DepositMilestoneClaimResult
    {
        public int ResultCode { get; set; }
        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }
        public int RewardSpins { get; set; }
        public int ClaimID { get; set; }
        public int ClaimIndex { get; set; }
    }

    public class DepositMilestoneClaimPoco
    {
        public int ClaimID { get; set; }
        public int MilestoneID { get; set; }
        public string PeriodKey { get; set; }
        public int ClaimIndex { get; set; }
        public decimal DepositAmount { get; set; }
        public int RewardCoins { get; set; }
        public int RewardSpins { get; set; }
        public string DeliveryStatus { get; set; }      // 'Pending' | 'Delivered' | 'Failed'
        public string DeliveryNote { get; set; }
        public DateTime ClaimedDate { get; set; }

        // Joined từ định nghĩa mốc
        public string MilestoneName { get; set; }
        public decimal ThresholdAmount { get; set; }
        public string PeriodType { get; set; }
        public bool IsRepeatable { get; set; }
        public string RewardItems { get; set; }
        public string Description { get; set; }
    }

    // ============================================================
    // Spending Milestone POCOs (Mốc tiêu phí — tích lũy mua shop)
    // ============================================================

    public class SpendingMilestonePoco
    {
        public int MilestoneID { get; set; }
        public string MilestoneName { get; set; }
        public decimal ThresholdAmount { get; set; }

        // Period configuration
        public string PeriodType { get; set; }                // 'Lifetime' | 'Monthly' | 'Weekly' | 'DateRange'
        public byte? WeekStartDay { get; set; }               // 1=Mon..7=Sun (when PeriodType='Weekly')
        public DateTime? PeriodStartDate { get; set; }        // when PeriodType='DateRange'
        public DateTime? PeriodEndDate { get; set; }          // when PeriodType='DateRange'
        public bool CountHistoricalPurchases { get; set; }    // false = only purchases after CreatedDate count

        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }               // JSON: [{"cashItemId":123,"quantity":1}]
        public string Description { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class SpendingMilestoneClaimPoco
    {
        public int ClaimID { get; set; }
        public int MilestoneID { get; set; }
        public string PeriodKey { get; set; }
        public decimal SpendingAmount { get; set; }
        public DateTime ClaimedDate { get; set; }
        public string DeliveryStatus { get; set; }            // 'Pending' | 'Delivered' | 'Failed'
        public string DeliveryNote { get; set; }

        // Joined from milestone definition
        public string MilestoneName { get; set; }
        public decimal ThresholdAmount { get; set; }
        public string PeriodType { get; set; }
        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }
        public string Description { get; set; }
    }

    /// <summary>View-model for displaying milestone progress on user page.</summary>
    public class SpendingMilestoneProgressItem
    {
        public SpendingMilestonePoco Milestone { get; set; }
        public string PeriodKey { get; set; }                 // computed period key for current cycle
        public DateTime PeriodRangeStart { get; set; }        // computed range start
        public DateTime PeriodRangeEnd { get; set; }          // computed range end
        public decimal CurrentSpending { get; set; }
        public bool ThresholdReached => CurrentSpending >= Milestone.ThresholdAmount;
        public bool ClaimedInCurrentPeriod { get; set; }
        public DateTime? ClaimedDate { get; set; }
        public string DeliveryStatus { get; set; }
    }

    public class SpendingMilestoneGrantResult
    {
        public int MilestoneID { get; set; }
        public int ClaimID { get; set; }
        public string MilestoneName { get; set; }
        public int RewardCoins { get; set; }
        public string RewardItems { get; set; }               // JSON
    }

    // ============================================================
    // Boss Spawn Timer POCOs
    // ============================================================

    public class BossSpawnTimerPoco
    {
        public int BossID { get; set; }
        public string MapName { get; set; }
        public string BossName { get; set; }
        public int Level { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public string SpawnTimes { get; set; }    // Comma-separated: "05:00,10:00,15:00"
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    // ============================================================
    // Weekly Activities POCOs
    // ============================================================

    public class WeeklyActivityPoco
    {
        public int ActivityID { get; set; }
        public string DayName { get; set; }
        public int DayIndex { get; set; }
        public string ActivityName { get; set; }
        public string ActivityType { get; set; }  // "Event" or "Boss"
        public string Level { get; set; }
        public string Maps { get; set; }
        public string SpawnTimes { get; set; }    // Comma-separated: "12:00,20:00"
        public string Description { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    // ============================================================
    // Weapon Refining POCOs
    // ============================================================

    public class WeaponRefiningLevelPoco
    {
        public int RefineID { get; set; }
        public string Level { get; set; }         // "+1", "+2", ...
        public string Rate { get; set; }          // "100%", "95%", ...
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    // ============================================================
    // Cloth Refining POCOs
    // ============================================================

    public class ClothRefiningLevelPoco
    {
        public int RefineID { get; set; }
        public string Level { get; set; }         // "+1", "+2", ...
        public string Rate { get; set; }          // "100%", "95%", ...
        public string Description { get; set; } = "";  // Item description
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    // ============================================================
    // Map Info POCOs
    // ============================================================

    public class MapInfoItemPoco
    {
        public int MapID { get; set; }
        public string Name { get; set; }
        public string ExpRate { get; set; }
        public string DropRate { get; set; }
        public string FireRate { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    // ============================================================
    // Feature Categories & Guides POCOs
    // ============================================================

    public class FeatureCategoryPoco
    {
        public int CategoryID { get; set; }
        public string Name { get; set; }
        public string Slug { get; set; }
        public string Description { get; set; }
        public string IconUrl { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public int GuideCount { get; set; }
    }

    public class FeatureGuidePoco
    {
        public int GuideID { get; set; }
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string CategorySlug { get; set; }
        public string Title { get; set; }
        public string Slug { get; set; }
        public string Excerpt { get; set; }
        public string Content { get; set; }
        public string ThumbnailUrl { get; set; }
        public string AuthorName { get; set; }
        public bool IsPublished { get; set; }
        public int SortOrder { get; set; }
        public int ViewCount { get; set; }
        public DateTime PublishedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    // ============================================================
    // Server Info Items POCOs
    // ============================================================

    public class ServerInfoItemPoco
    {
        public int ItemID { get; set; }
        public string Icon { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string LinkUrl { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    // ============================================================
    // Shop POCOs
    // ============================================================

    public class ShopCategoryPoco
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class ShopItemPoco
    {
        public int ItemId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string ItemName { get; set; }
        public string Description { get; set; }
        public string IconPath { get; set; }
        public int OriginalPrice { get; set; }
        public int CurrentPrice { get; set; }
        public int CashItemId { get; set; }
        public int CashItemCount { get; set; }
        public int MaxPurchasePerDay { get; set; }
        public bool IsActive { get; set; }
        public bool IsFeatured { get; set; }
        public int DisplayOrder { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class ShopPurchaseResult
    {
        public int ResultCode { get; set; }
        public int NewBalance { get; set; }
        public int PurchaseId { get; set; }
    }

    public class ShopPurchasePoco
    {
        public int PurchaseId { get; set; }
        public string Username { get; set; }
        public string MemberGuid { get; set; }
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public string PurchaseType { get; set; }
        public string RecipientUsername { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    // ============================================================
    // Gift Box (Mở Hộp Quà) POCOs
    // ============================================================

    public class GiftBoxConfigPoco
    {
        public int ConfigId { get; set; }
        public string EventName { get; set; }
        public string Description { get; set; }
        public int CostType { get; set; }      // 0 = Miễn phí, 1 = Coin
        public int CostAmount { get; set; }
        public bool AllowReplay { get; set; }   // mở xong vòng cuối thì chơi lại từ đầu
        public bool IsActive { get; set; }
        public int RoundCount { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class GiftBoxRoundPoco
    {
        public int RoundId { get; set; }
        public int ConfigId { get; set; }
        public int RoundNumber { get; set; }
        public int BoxCount { get; set; }
        public int CostAmount { get; set; }     // chi phí mở hộp đầu tiên của vòng (Coin)
        public int CostStep { get; set; }       // số Coin tăng thêm sau mỗi hộp đã mở
        public int AdvanceMode { get; set; }    // 0 = cần chìa khóa, 1 = mở hộp bất kỳ là qua vòng
        public int GiftCount { get; set; }
        public int AdvanceCount { get; set; }   // số quà "chìa khóa" (nên = 1)
        public DateTime CreatedDate { get; set; }
    }

    public class GiftBoxGiftPoco
    {
        public int Weight { get; set; } = 1;
        public int GiftId { get; set; }
        public int RoundId { get; set; }
        public string GiftName { get; set; }
        public string IconPath { get; set; }
        public int RewardType { get; set; }     // 1 = Item (CIS), 2 = Coin
        public int CashItemId { get; set; }
        public int CashItemCount { get; set; }
        public int CoinAmount { get; set; }
        public bool IsAdvance { get; set; }      // hộp chìa khóa (qua vòng)
        public bool IsActive { get; set; }
        public int DisplayOrder { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    // Một hộp trên bàn chơi của user. Quà chỉ hiển thị khi hộp đã mở.
    public class GiftBoxBoxPoco
    {
        public int BoxIndex { get; set; }
        public bool IsOpened { get; set; }
        public bool IsAdvance { get; set; }
        public string GiftName { get; set; }
        public string IconPath { get; set; }
        public int RewardType { get; set; }
        public int CoinAmount { get; set; }
        public int CashItemCount { get; set; }
    }

    // Dùng nội bộ để đọc result set tiến độ trong sp_Web_GiftBox_GetState
    public class GiftBoxProgressRow
    {
        public int CurrentRound { get; set; }
        public string Status { get; set; }
        public int RoundOrdinal { get; set; }   // số thứ tự vòng (1-based) để hiển thị
        public int NextCost { get; set; }       // chi phí mở hộp tiếp theo (Coin)
        public int CostStep { get; set; }       // mức tăng mỗi lần mở
        public int AdvanceMode { get; set; }    // 0 = cần chìa khóa, 1 = mở hộp bất kỳ
    }

    public class GiftBoxStatePoco
    {
        public GiftBoxConfigPoco Config { get; set; }   // null nếu không có sự kiện đang bật
        public int CurrentRound { get; set; }
        public int RoundOrdinal { get; set; }
        public int NextCost { get; set; }
        public int CostStep { get; set; }
        public int AdvanceMode { get; set; }
        public string Status { get; set; }
        public List<GiftBoxBoxPoco> Boxes { get; set; } = new List<GiftBoxBoxPoco>();
        public int Balance { get; set; }
        public bool HasActiveEvent => Config != null;
        public bool IsCompleted => string.Equals(Status, "Completed", StringComparison.OrdinalIgnoreCase);
    }

    public class GiftBoxOpenResult
    {
        public int ResultCode { get; set; }
        public int GiftId { get; set; }
        public string GiftName { get; set; }
        public string IconPath { get; set; }
        public int RewardType { get; set; }
        public int CashItemId { get; set; }
        public int CashItemCount { get; set; }
        public int CoinAmount { get; set; }
        public bool IsAdvance { get; set; }
        public int NewBalance { get; set; }
        public int NextRound { get; set; }
        public bool IsLastRound { get; set; }
        public int NewRoundBoxCount { get; set; }
        public int NextCost { get; set; }       // chi phí mở hộp tiếp theo sau lần mở này
        public bool Replayed { get; set; }      // true = vừa hoàn thành vòng cuối và được chơi lại từ đầu
    }

    // ============================================================
    // Lucky Wheel POCOs (Vòng Quay May Mắn)
    // ============================================================

    public static class LuckyWheelRewardType
    {
        public const int Item = 1;        // vật phẩm in-game, giao sang CIS_DB ở tầng C#
        public const int Coin = 2;        // Coin web, cộng trong SP
        public const int SpinTicket = 3;  // vé quay thêm
        public const int Nothing = 4;     // "Chúc may mắn"
    }

    public static class LuckyWheelCostType
    {
        public const int Free = 0;
        public const int Ticket = 1;
        public const int Coin = 2;
    }

    public class LuckyWheelConfigPoco
    {
        public int WheelId { get; set; }
        public string WheelName { get; set; }
        public string Description { get; set; }
        public int CostCoin { get; set; }            // Coin trừ mỗi lượt khi hết free + hết vé
        public int FreeSpinsPerDay { get; set; }
        public int MaxSpinsPerDay { get; set; }      // 0 = vô hạn
        public int MaxSpinsPerRequest { get; set; }
        public int SpinCooldownSeconds { get; set; }
        public bool ShowOdds { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        // Chỉ có ở trang admin
        public int PrizeCount { get; set; }
        public int SpinCount { get; set; }
    }

    public class LuckyWheelPrizePoco
    {
        public int PrizeId { get; set; }
        public int WheelId { get; set; }
        public string PrizeName { get; set; }
        public string IconPath { get; set; }
        public string SliceColor { get; set; }
        public int RewardType { get; set; }          // xem LuckyWheelRewardType
        public int CashItemId { get; set; }
        public int CashItemCount { get; set; } = 1;
        public int CoinAmount { get; set; }
        public int SpinAmount { get; set; }
        public int Weight { get; set; } = 1;
        public int StockTotal { get; set; }          // 0 = vô hạn
        public int StockRemaining { get; set; }
        public bool IsJackpot { get; set; }
        public bool IsActive { get; set; }
        public int DisplayOrder { get; set; }
        public DateTime CreatedDate { get; set; }
        // Tính sẵn trong SP
        public bool SoldOut { get; set; }
        public decimal OddsPercent { get; set; }
    }

    public class LuckyWheelUserStatePoco
    {
        public int Tickets { get; set; }
        public int Balance { get; set; }
        public int FreeRemaining { get; set; }
        public int DaySpinCount { get; set; }
        public int DayRemaining { get; set; }        // -1 = vô hạn
        public int TotalSpins { get; set; }
    }

    public class LuckyWheelSpinLogPoco
    {
        public int LogId { get; set; }
        public string Username { get; set; }
        public int MemberGuid { get; set; }
        public int WheelId { get; set; }
        public int PrizeId { get; set; }
        public string PrizeName { get; set; }
        public string IconPath { get; set; }
        public int RewardType { get; set; }
        public int CashItemId { get; set; }
        public int CashItemCount { get; set; }
        public int CoinAmount { get; set; }
        public int SpinAmount { get; set; }
        public int CostType { get; set; }
        public int CostAmount { get; set; }
        public bool IsJackpot { get; set; }
        public string IpAddress { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class LuckyWheelStatePoco
    {
        public LuckyWheelConfigPoco Config { get; set; }
        public List<LuckyWheelPrizePoco> Prizes { get; set; } = new List<LuckyWheelPrizePoco>();
        public LuckyWheelUserStatePoco UserState { get; set; } = new LuckyWheelUserStatePoco();
        public List<LuckyWheelSpinLogPoco> MyHistory { get; set; } = new List<LuckyWheelSpinLogPoco>();
        public List<LuckyWheelSpinLogPoco> JackpotFeed { get; set; } = new List<LuckyWheelSpinLogPoco>();
        public bool HasActiveWheel => Config != null && Config.WheelId > 0;
    }

    /// <summary>Một lượt quay đã thực hiện (1 dòng trong result set của sp_Web_LuckyWheel_Spin).</summary>
    public class LuckyWheelSpinEntry
    {
        public int Seq { get; set; }
        public int PrizeId { get; set; }
        public string PrizeName { get; set; }
        public string IconPath { get; set; }
        public int RewardType { get; set; }
        public int CashItemId { get; set; }
        public int CashItemCount { get; set; }
        public int CoinAmount { get; set; }
        public int SpinAmount { get; set; }
        public int CostType { get; set; }
        public int CostAmount { get; set; }
        public bool IsJackpot { get; set; }
    }

    public class LuckyWheelSpinResult
    {
        public int ResultCode { get; set; }
        public int SpinsDone { get; set; }
        public int NewBalance { get; set; }
        public int NewTickets { get; set; }
        public int FreeRemaining { get; set; }
        public int DayRemaining { get; set; }
        public List<LuckyWheelSpinEntry> Spins { get; set; } = new List<LuckyWheelSpinEntry>();
    }

    // ============================================================
    // Interface
    // ============================================================

    public interface IGameRepository
    {
        // --- News ---
        Task<List<NewsPoco>> GetLatestNewsAsync(int top, string category = null);
        Task<(List<NewsPoco> Items, int TotalCount)> GetNewsListAsync(string category, int page, int pageSize);
        Task<NewsPoco> GetNewsDetailAsync(int newsId);
        Task<int> InsertNewsAsync(NewsPoco news);
        Task<int> UpdateNewsAsync(NewsPoco news);
        Task<int> DeleteNewsAsync(int newsId);

        // --- Rankings ---
        Task<List<RankingPoco>> GetRankingsAsync(int top = 100, string faction = null);
        Task<List<TopPlayerPoco>> GetTopPlayersAsync(int top = 100, int? faction = null);
        Task<List<TopRichestPoco>> GetTopRichestAsync(int top = 100);
        Task<List<TopOnlinePoco>> GetTopOnlineAsync(int top = 100, int? faction = null);
        Task<List<TopInfamyPoco>> GetTopInfamyAsync(int top = 100, int? faction = null);
        Task<List<TopHonorPoco>> GetTopHonorAsync(int top = 100, int? faction = null);

        // --- Factions ---
        Task<List<FactionPoco>> GetFactionsAsync();

        // --- Deposit (SePay) ---
        Task<int> CreateDepositAsync(string username, decimal amount);
        Task<int> CompleteDepositAsync(int transactionId, int sepayId, string referenceCode, decimal transferAmount);
        Task<TransactionPoco> GetTransactionStatusAsync(int transactionId);
        Task<List<DepositBonusPoco>> GetActiveBonusTiersAsync();

        // --- Giftcodes (user) ---
        Task<GiftcodeRedeemResult> RedeemGiftcodeAsync(string username, string code);

        // --- Giftcodes (admin) ---
        Task<(List<GiftcodePoco> Items, int TotalCount)> GetGiftcodesAsync(int page, int pageSize);
        Task<GiftcodePoco?> GetGiftcodeByIdAsync(int giftcodeId);
        Task<int> CreateGiftcodeAsync(GiftcodePoco giftcode);
        Task<int> UpdateGiftcodeAsync(GiftcodePoco giftcode);
        Task<int> ToggleGiftcodeAsync(int giftcodeId);

        // --- Server Config ---
        Task<Dictionary<string, string>> GetServerConfigAsync(string key = null);
        Task<int> UpsertServerConfigAsync(string key, string value, string description = null);

        // Live online player count from Tbl_ND_GameConnect (cur_state != 0)
        Task<int> GetActivePlayerCountAsync();

        // --- Boss Spawn Timers ---
        Task<List<BossSpawnTimerPoco>> GetBossSpawnTimersAsync();
        Task<List<BossSpawnTimerPoco>> GetAllBossSpawnTimersAsync();
        Task<BossSpawnTimerPoco> GetBossSpawnTimerByIdAsync(int bossId);
        Task<int> InsertBossSpawnTimerAsync(BossSpawnTimerPoco item);
        Task<int> UpdateBossSpawnTimerAsync(BossSpawnTimerPoco item);
        Task<int> DeleteBossSpawnTimerAsync(int bossId);

        // --- Weekly Activities ---
        Task<List<WeeklyActivityPoco>> GetWeeklyActivitiesAsync();
        Task<List<WeeklyActivityPoco>> GetAllWeeklyActivitiesAsync();
        Task<WeeklyActivityPoco> GetWeeklyActivityByIdAsync(int activityId);
        Task<int> InsertWeeklyActivityAsync(WeeklyActivityPoco item);
        Task<int> UpdateWeeklyActivityAsync(WeeklyActivityPoco item);
        Task<int> DeleteWeeklyActivityAsync(int activityId);

        // --- Weapon Refining Levels ---
        Task<List<WeaponRefiningLevelPoco>> GetWeaponRefiningLevelsAsync();
        Task<List<WeaponRefiningLevelPoco>> GetAllWeaponRefiningLevelsAsync();
        Task<WeaponRefiningLevelPoco> GetWeaponRefiningLevelByIdAsync(int refineId);
        Task<int> InsertWeaponRefiningLevelAsync(WeaponRefiningLevelPoco item);
        Task<int> UpdateWeaponRefiningLevelAsync(WeaponRefiningLevelPoco item);
        Task<int> DeleteWeaponRefiningLevelAsync(int refineId);

        // --- Cloth Refining Levels ---
        Task<List<ClothRefiningLevelPoco>> GetClothRefiningLevelsAsync();
        Task<List<ClothRefiningLevelPoco>> GetAllClothRefiningLevelsAsync();
        Task<ClothRefiningLevelPoco> GetClothRefiningLevelByIdAsync(int refineId);
        Task<int> InsertClothRefiningLevelAsync(ClothRefiningLevelPoco item);
        Task<int> UpdateClothRefiningLevelAsync(ClothRefiningLevelPoco item);
        Task<int> DeleteClothRefiningLevelAsync(int refineId);

        // --- Map Info Items ---
        Task<List<MapInfoItemPoco>> GetMapInfoItemsAsync();
        Task<List<MapInfoItemPoco>> GetAllMapInfoItemsAsync();
        Task<MapInfoItemPoco> GetMapInfoItemByIdAsync(int mapId);
        Task<int> InsertMapInfoItemAsync(MapInfoItemPoco item);
        Task<int> UpdateMapInfoItemAsync(MapInfoItemPoco item);
        Task<int> DeleteMapInfoItemAsync(int mapId);

        // --- Factions (admin) ---
        Task<List<FactionPoco>> GetAllFactionsAsync();
        Task<FactionPoco> GetFactionByIdAsync(int factionId);
        Task<int> InsertFactionAsync(FactionPoco item);
        Task<int> UpdateFactionAsync(FactionPoco item);
        Task<int> DeleteFactionAsync(int factionId);

        // --- Server Info Items ---
        Task<List<ServerInfoItemPoco>> GetServerInfoItemsAsync();
        Task<List<ServerInfoItemPoco>> GetAllServerInfoItemsAsync();
        Task<ServerInfoItemPoco> GetServerInfoItemByIdAsync(int itemId);
        Task<int> InsertServerInfoItemAsync(ServerInfoItemPoco item);
        Task<int> UpdateServerInfoItemAsync(ServerInfoItemPoco item);
        Task<int> DeleteServerInfoItemAsync(int itemId);

        // --- Feature Categories ---
        Task<List<FeatureCategoryPoco>> GetFeatureCategoriesAsync();
        Task<List<FeatureCategoryPoco>> GetAllFeatureCategoriesAsync();
        Task<FeatureCategoryPoco> GetFeatureCategoryBySlugAsync(string slug);
        Task<FeatureCategoryPoco> GetFeatureCategoryByIdAsync(int categoryId);
        Task<int> InsertFeatureCategoryAsync(FeatureCategoryPoco category);
        Task<int> UpdateFeatureCategoryAsync(FeatureCategoryPoco category);
        Task<int> DeleteFeatureCategoryAsync(int categoryId);

        // --- Feature Guides ---
        Task<(List<FeatureGuidePoco> Items, int TotalCount)> GetFeatureGuidesAsync(int? categoryId, int page, int pageSize);
        Task<(List<FeatureGuidePoco> Items, int TotalCount)> GetAllFeatureGuidesAsync(int? categoryId, int page, int pageSize);
        Task<FeatureGuidePoco> GetFeatureGuideDetailAsync(int guideId);
        Task<FeatureGuidePoco> GetFeatureGuideBySlugAsync(string slug);
        Task<FeatureGuidePoco> GetFeatureGuideForEditAsync(int guideId);
        Task<int> InsertFeatureGuideAsync(FeatureGuidePoco guide);
        Task<int> UpdateFeatureGuideAsync(FeatureGuidePoco guide);
        Task<int> DeleteFeatureGuideAsync(int guideId);
        Task<List<FeatureGuidePoco>> GetGuidesByCategoryAsync(int categoryId);

        // --- Deposit Milestones (user) ---
        Task<(List<DepositMilestonePoco> Items, decimal TotalDeposited)> GetDepositMilestonesAsync(string username);
        Task<DepositMilestoneClaimResult> ClaimDepositMilestoneAsync(string username, int milestoneId);
        Task<List<DepositMilestoneClaimPoco>> GetUserDepositClaimsAsync(string username, int top = 30);
        Task UpdateDepositClaimStatusAsync(int claimId, string status, string note = null);

        // --- Deposit Milestones (admin) ---
        Task<(List<DepositMilestonePoco> Items, int TotalCount)> GetAllDepositMilestonesAsync(int page, int pageSize);
        Task<DepositMilestonePoco> GetDepositMilestoneByIdAsync(int milestoneId);
        Task<int> CreateDepositMilestoneAsync(DepositMilestonePoco milestone);
        Task<int> UpdateDepositMilestoneAsync(DepositMilestonePoco milestone);
        Task<int> ToggleDepositMilestoneAsync(int milestoneId);
        Task<int> DeleteDepositMilestoneAsync(int milestoneId);

        // --- Spending Milestone (user) ---
        Task<List<SpendingMilestonePoco>> GetActiveSpendingMilestonesAsync();
        Task<decimal> GetUserSpendingInRangeAsync(string username, DateTime rangeStart, DateTime rangeEnd);
        Task<List<SpendingMilestoneClaimPoco>> GetUserSpendingClaimsAsync(string username);
        /// <summary>Atomic insert; returns inserted ClaimID or 0 if already claimed for this period, -1 on error.</summary>
        Task<(int ResultCode, int ClaimID)> TryInsertSpendingClaimAsync(int milestoneId, string username, string periodKey, decimal spendingAmount, int rewardCoins);
        Task UpdateSpendingClaimStatusAsync(int claimId, string status, string note = null);
        /// <summary>Orchestrator: scan all active milestones for this user, grant rewards for any newly-reached milestones, deliver items via IShopDeliveryService.</summary>
        Task<List<SpendingMilestoneGrantResult>> TryGrantSpendingMilestonesAsync(string username);

        // --- Spending Milestone (admin) ---
        Task<(List<SpendingMilestonePoco> Items, int TotalCount)> GetAllSpendingMilestonesAsync(int page, int pageSize);
        Task<SpendingMilestonePoco> GetSpendingMilestoneByIdAsync(int milestoneId);
        Task<int> CreateSpendingMilestoneAsync(SpendingMilestonePoco milestone);
        Task<int> UpdateSpendingMilestoneAsync(SpendingMilestonePoco milestone);
        Task<int> ToggleSpendingMilestoneAsync(int milestoneId);

        // --- Daily Check-in ---
        Task<DailyCheckInStatePoco> GetDailyCheckInStateAsync(string username);
        Task<DailyCheckInClaimResult> ClaimDailyCheckInAsync(string username);

        // --- Daily Check-in (admin config) ---
        Task<List<DailyCheckInRewardRulePoco>> GetDailyCheckInRewardRulesAsync();
        Task<DailyCheckInRewardRulePoco> GetDailyCheckInRewardRuleByIdAsync(int ruleId);
        Task<int> CreateDailyCheckInRewardRuleAsync(DailyCheckInRewardRulePoco rule);
        Task<int> UpdateDailyCheckInRewardRuleAsync(DailyCheckInRewardRulePoco rule);
        Task<int> ToggleDailyCheckInRewardRuleAsync(int ruleId);
        Task<int> DeleteDailyCheckInRewardRuleAsync(int ruleId);

        // --- Shop (user) ---
        Task<List<ShopCategoryPoco>> GetShopCategoriesAsync();
        Task<(List<ShopItemPoco> Items, int TotalCount)> GetShopItemsAsync(int? categoryId, int page, int pageSize);
        Task<ShopItemPoco> GetShopItemByIdAsync(int itemId);
        Task<ShopPurchaseResult> PurchaseShopItemAsync(string username, int itemId, int quantity, string ipAddress);
        Task<ShopPurchaseResult> GiftShopItemAsync(string username, int itemId, string recipientUsername, string ipAddress);
        Task<(List<ShopPurchasePoco> Items, int TotalCount)> GetShopPurchaseHistoryAsync(string username, int page, int pageSize);
        Task<int> GetShopDailyPurchaseCountAsync(string username, int itemId);
        Task<bool> CheckUserExistsAsync(string username);
        Task<int> GetUserBalanceAsync(string username);

        // --- Shop (admin) ---
        Task<List<ShopItemPoco>> GetAllShopItemsAsync();
        Task<List<ShopCategoryPoco>> GetAllShopCategoriesAsync();
        Task<int> InsertShopItemAsync(ShopItemPoco item);
        Task<int> UpdateShopItemAsync(ShopItemPoco item);
        Task<int> DeleteShopItemAsync(int itemId);
        Task<int> InsertShopCategoryAsync(ShopCategoryPoco category);
        Task<int> UpdateShopCategoryAsync(ShopCategoryPoco category);
        Task<ShopCategoryPoco> GetShopCategoryByIdAsync(int categoryId);
        Task<(int ResultCode, int NewBalance)> AdminAddCoinsAsync(string adminUsername, string targetUsername, int amount, string reason);

        // --- Gift Box (user) ---
        Task<GiftBoxConfigPoco> GetGiftBoxActiveConfigAsync();
        Task<GiftBoxStatePoco> GetGiftBoxStateAsync(string username);
        Task<GiftBoxOpenResult> OpenGiftBoxAsync(string username, int boxIndex, string ipAddress);

        // --- Gift Box (admin) ---
        Task<List<GiftBoxConfigPoco>> GetGiftBoxConfigsAsync();
        Task<GiftBoxConfigPoco> GetGiftBoxConfigByIdAsync(int configId);
        Task<int> InsertGiftBoxConfigAsync(GiftBoxConfigPoco config);
        Task<int> UpdateGiftBoxConfigAsync(GiftBoxConfigPoco config);
        Task<int> DeleteGiftBoxConfigAsync(int configId);
        Task<int> SetGiftBoxActiveAsync(int configId);
        Task<int> ResetGiftBoxAsync(int configId);
        Task<List<GiftBoxRoundPoco>> GetGiftBoxRoundsAsync(int configId);
        Task<GiftBoxRoundPoco> GetGiftBoxRoundByIdAsync(int roundId);
        Task<int> InsertGiftBoxRoundAsync(int configId, int roundNumber, int boxCount, int costAmount, int costStep, int advanceMode);
        Task<int> UpdateGiftBoxRoundAsync(int roundId, int roundNumber, int boxCount, int costAmount, int costStep, int advanceMode);
        Task<int> DeleteGiftBoxRoundAsync(int roundId);
        Task<List<GiftBoxGiftPoco>> GetGiftBoxGiftsAsync(int roundId);
        Task<GiftBoxGiftPoco> GetGiftBoxGiftByIdAsync(int giftId);
        Task<int> InsertGiftBoxGiftAsync(GiftBoxGiftPoco gift);
        Task<int> UpdateGiftBoxGiftAsync(GiftBoxGiftPoco gift);
        Task<int> DeleteGiftBoxGiftAsync(int giftId);

        // --- Lucky Wheel (user) ---
        Task<LuckyWheelStatePoco> GetLuckyWheelStateAsync(string username);
        Task<LuckyWheelSpinResult> SpinLuckyWheelAsync(string username, int spinCount, string ipAddress);
        Task<int> GrantLuckyWheelTicketsAsync(string username, int amount, string reason, int refId = 0);
        Task<int> GetLuckyWheelTicketsAsync(string username);

        // --- Lucky Wheel (admin) ---
        Task<List<LuckyWheelConfigPoco>> GetLuckyWheelConfigsAsync();
        Task<LuckyWheelConfigPoco> GetLuckyWheelConfigByIdAsync(int wheelId);
        Task<int> InsertLuckyWheelConfigAsync(LuckyWheelConfigPoco config);
        Task<int> UpdateLuckyWheelConfigAsync(LuckyWheelConfigPoco config);
        Task<int> DeleteLuckyWheelConfigAsync(int wheelId);
        Task<int> SetLuckyWheelActiveAsync(int wheelId);
        Task<int> ResetLuckyWheelDailyAsync(int wheelId);
        Task<List<LuckyWheelPrizePoco>> GetLuckyWheelPrizesAsync(int wheelId);
        Task<LuckyWheelPrizePoco> GetLuckyWheelPrizeByIdAsync(int prizeId);
        Task<int> InsertLuckyWheelPrizeAsync(LuckyWheelPrizePoco prize);
        Task<int> UpdateLuckyWheelPrizeAsync(LuckyWheelPrizePoco prize);
        Task<int> DeleteLuckyWheelPrizeAsync(int prizeId);
        Task<int> RefillLuckyWheelStockAsync(int prizeId);
        Task<(List<LuckyWheelSpinLogPoco> Items, int TotalCount)> GetLuckyWheelSpinLogsAsync(string username, int wheelId, int page, int pageSize);
    }
}
