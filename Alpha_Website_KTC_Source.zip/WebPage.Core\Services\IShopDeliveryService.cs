namespace WebPage.Services
{
    public interface IShopDeliveryService
    {
        /// <summary>
        /// Deliver a purchased cash item to the player's cash inventory in CIS_DB.
        /// Returns true if delivery succeeded.
        /// </summary>
        Task<bool> DeliverItemToCashInventoryAsync(string userid, int cashItemId, int count);
    }
}
