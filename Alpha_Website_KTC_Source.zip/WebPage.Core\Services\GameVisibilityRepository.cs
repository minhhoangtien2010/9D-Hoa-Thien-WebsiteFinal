using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace WebPage.Services;

public sealed class GameVisibility
{
    public string GameType { get; set; } = "";
    public bool IsVisible { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
    public byte[] Version { get; set; } = [];
    public string VersionToken => Convert.ToBase64String(Version);
}

/// <summary>Visibility is shared by public lists and all website play endpoints, independent of reward activation.</summary>
public sealed class GameVisibilityRepository(IConfiguration configuration)
{
    private SqlConnection Connection() => new(configuration.GetConnectionString("DefaultConnection"));
    public async Task<List<GameVisibility>> ListAsync()
    {
        using var c = Connection();
        return (await c.QueryAsync<GameVisibility>("sp_Web_Games_Visibility", commandType: CommandType.StoredProcedure)).AsList();
    }
    public async Task<bool> IsVisibleAsync(string game)
    {
        using var c = Connection();
        return await c.ExecuteScalarAsync<bool>("sp_Web_Games_Visible", new { gameType = game == "chest10" ? "chest" : game }, commandType: CommandType.StoredProcedure);
    }
    public async Task SaveAsync(string game, bool isVisible, string actor, byte[]? expectedVersion = null)
    {
        using var c = Connection();
        await c.ExecuteAsync("sp_Web_Games_Admin_Visibility", new { gameType = game, isVisible, actor, expectedVersion }, commandType: CommandType.StoredProcedure);
    }
}

/// <summary>Protects legacy direct game routes as well as the unified Gacha controller.</summary>
public sealed class GameVisibilityFilter(GameVisibilityRepository visibility) : IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var controller = (context.ActionDescriptor as ControllerActionDescriptor)?.ControllerName;
        var type = controller switch { "LuckyWheel" => "wheel", "GiftBox" => "card", _ => null };
        if (type is not null && !await visibility.IsVisibleAsync(type))
        {
            context.Result = HttpMethods.IsGet(context.HttpContext.Request.Method)
                ? new NotFoundResult()
                : new JsonResult(new { success = false, message = "Trò chơi đang được quản trị viên tạm ẩn." }) { StatusCode = StatusCodes.Status404NotFound };
            return;
        }
        await next();
    }
}
