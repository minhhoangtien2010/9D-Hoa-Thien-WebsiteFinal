using WebPage;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.FileProviders.Physical;

var builder = WebApplication.CreateBuilder(args);

// Register all core services (shared across all servers)
builder.Services.AddCoreServices(builder.Configuration);

var app = builder.Build();
var uploadedMedia = app.Services.GetRequiredService<WebPage.Services.PublicMediaStorage>();
uploadedMedia.PreserveLegacyImages();
app.UseStaticFiles(new StaticFileOptions
{
    RequestPath = "/uploads",
    FileProvider = new PhysicalFileProvider(uploadedMedia.RootPath)
});
foreach (var category in new[] { "News", "Shop", "GiftBox", "LuckyWheel" })
{
    app.UseStaticFiles(new StaticFileOptions
    {
        RequestPath = "/images/" + category,
        FileProvider = new PhysicalFileProvider(Path.Combine(uploadedMedia.RootPath, "legacy", category))
    });
}

// ============================================================
// SSL DCV (.well-known) — MUST run BEFORE ConfigureCoreMiddleware.
// Default PhysicalFileProvider excludes dot-prefixed folders (ExclusionFilters.Sensitive)
// so we need a dedicated FileProvider with ExclusionFilters.None that runs on plain HTTP.
// ============================================================
var wellKnownPath = Path.Combine(builder.Environment.ContentRootPath, "wwwroot", ".well-known");
Directory.CreateDirectory(Path.Combine(wellKnownPath, "pki-validation"));
Directory.CreateDirectory(Path.Combine(wellKnownPath, "acme-challenge"));
app.UseStaticFiles(new StaticFileOptions
{
    RequestPath = "/.well-known",
    FileProvider = new PhysicalFileProvider(wellKnownPath, ExclusionFilters.None),
    ServeUnknownFileTypes = true,
    DefaultContentType = "text/plain"
});

// Configure core middleware pipeline
app.ConfigureCoreMiddleware();

// Server-specific: Serve ThanhLong's own embedded static files (CSS/JS/images)
// In production (after publish), wwwroot is removed and files are served from embedded DLL resources
var serverAssembly = typeof(Program).Assembly;
try
{
    var embeddedProvider = new ManifestEmbeddedFileProvider(serverAssembly, "wwwroot");
    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = embeddedProvider
    });
}
catch
{
    // Embedded resources not available (development mode with physical files)
}

// Server-specific: Serve game patch files (PATCH folder)
// Admin drops patch files into {WebRoot}/PATCH/ND1/{file} — served at
// http://<domain>/PATCH/ND1/{file}. Folder auto-created + preserved after publish.
var patchPath = Path.Combine(
    builder.Environment.WebRootPath ?? Path.Combine(builder.Environment.ContentRootPath, "wwwroot"),
    "PATCH");
Directory.CreateDirectory(Path.Combine(patchPath, "ND1"));
app.UseStaticFiles(new StaticFileOptions
{
    RequestPath = "/PATCH",
    FileProvider = new PhysicalFileProvider(patchPath),
    ServeUnknownFileTypes = true,
    DefaultContentType = "application/octet-stream"
});

app.Run();
