using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;

namespace WebPage.Services;

public sealed class NewsCategoryRepository(IConfiguration configuration)
{
    public async Task<HashSet<string>> PublishedAsync()
    {
        using var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        var categories = await connection.QueryAsync<string>("sp_Web_News_Categories", commandType: CommandType.StoredProcedure);
        return new HashSet<string>(categories, StringComparer.OrdinalIgnoreCase);
    }
}
