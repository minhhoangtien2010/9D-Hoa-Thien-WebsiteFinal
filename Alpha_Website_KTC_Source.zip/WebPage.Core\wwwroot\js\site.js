/**
 * Cuu Long Huyet Kiem — Main Site JavaScript
 */

(function () {
    'use strict';

    /* ============================================================
       1. SCROLL REVEAL — .reveal / .reveal-left / .reveal-right / .stagger
       Adds class "in" when element enters viewport.
    ============================================================ */
    function initReveal() {
        var els = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .stagger');
        if (!els.length) return;

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08, rootMargin: '0px 0px -60px 0px' });

        els.forEach(function (el) { observer.observe(el); });
    }

    /* ============================================================
       2. LEGACY SCROLL ANIMATIONS — .fade-in-up → adds "visible"
    ============================================================ */
    function initFadeInUp() {
        var elements = document.querySelectorAll('.fade-in-up');
        if (!elements.length) return;

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

        elements.forEach(function (el) { observer.observe(el); });
    }

    /* ============================================================
       3. SMOOTH SCROLL — anchor links
    ============================================================ */
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
            anchor.addEventListener('click', function (e) {
                var targetId = this.getAttribute('href');
                if (targetId === '#') return;

                var target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    var navBar = document.querySelector('.navbar');
                    var navHeight = navBar ? navBar.offsetHeight : 0;
                    var targetPos = target.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
                    window.scrollTo({ top: targetPos, behavior: 'smooth' });
                }
            });
        });
    }

    /* ============================================================
       4. SCROLL TO TOP BUTTON
    ============================================================ */
    function initScrollToTop() {
        var btn = document.getElementById('scrollToTop');
        if (!btn) return;

        window.addEventListener('scroll', function () {
            btn.classList.toggle('visible', window.pageYOffset > 600);
        }, { passive: true });

        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ============================================================
       5. YOUTUBE LAZY LOAD
    ============================================================ */
    function initYouTubeLazyLoad() {
        var wrappers = document.querySelectorAll('.hero-video-lazy');
        wrappers.forEach(function (wrapper) {
            wrapper.addEventListener('click', function () {
                var videoId = wrapper.getAttribute('data-video-id');
                if (!videoId) return;

                var iframe = document.createElement('iframe');
                iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1&rel=0';
                iframe.title = 'YouTube Video';
                iframe.setAttribute('frameborder', '0');
                iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');
                iframe.setAttribute('allowfullscreen', '');

                wrapper.innerHTML = '';
                wrapper.appendChild(iframe);
                wrapper.classList.remove('hero-video-lazy');
            });
        });
    }

    /* ============================================================
       INIT
    ============================================================ */
    document.addEventListener('DOMContentLoaded', function () {
        initReveal();
        initFadeInUp();
        initSmoothScroll();
        initScrollToTop();
        initYouTubeLazyLoad();
    });
})();
