using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;

namespace WebPage.Services;

/// <summary>Serializes callbacks while retaining the original deposit credit and bonus calculation.</summary>
public sealed class DepositConfirmationRepository(IConfiguration configuration)
{
    public async Task<int> ConfirmAsync(int transactionId, int sepayId, string referenceCode, decimal amount)
    {
        using var connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        var parameters = new DynamicParameters();
        parameters.Add("@transaction_id", transactionId);
        parameters.Add("@sepay_id", sepayId);
        parameters.Add("@reference_code", referenceCode);
        parameters.Add("@transfer_amount", amount);
        parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
        await connection.ExecuteAsync("sp_Web_Deposit_Confirm", parameters, commandType: CommandType.StoredProcedure);
        return parameters.Get<int>("@result");
    }
}
