namespace WebPage.Models
{
    public class NewsItem
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Excerpt { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty; // "news", "event", "community"
        public string ThumbnailFit { get; set; } = "cover";
        public int ThumbnailPositionX { get; set; } = 50;
        public int ThumbnailPositionY { get; set; } = 20;
        public string ThumbnailAspect { get; set; } = "wide";
        public string ThumbnailUrl { get; set; } = string.Empty;
        public DateTime PublishedDate { get; set; }
        public string Url { get; set; } = string.Empty;
    }
}
