using WebPage.Services;

namespace WebPage.ViewModel;

public sealed class InGameShopViewModel
{
    public IReadOnlyList<ShopCategoryPoco> Categories { get; init; } = Array.Empty<ShopCategoryPoco>();
    public IReadOnlyList<ShopItemPoco> Items { get; init; } = Array.Empty<ShopItemPoco>();
    public int Balance { get; init; }
    public int? CategoryId { get; init; }
    public int CurrentPage { get; init; } = 1;
    public int TotalPages { get; init; }
    public int TotalCount { get; init; }
}

public sealed class InGameHistoryViewModel
{
    public IReadOnlyList<ShopPurchasePoco> Items { get; init; } = Array.Empty<ShopPurchasePoco>();
    public int CurrentPage { get; init; } = 1;
    public int TotalPages { get; init; }
}
