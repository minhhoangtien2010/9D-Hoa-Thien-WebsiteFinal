namespace WebPage.Services
{
    public interface IEmailService
    {
        /// <summary>
        /// Sends a verification email with a link to verify the user's email address.
        /// </summary>
        Task SendVerificationEmailAsync(string toEmail, string username, string token);

        /// <summary>
        /// Sends a generic email.
        /// </summary>
        Task SendEmailAsync(string to, string subject, string htmlBody);
    }
}
