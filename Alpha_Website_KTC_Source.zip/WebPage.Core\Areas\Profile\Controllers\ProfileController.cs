using WebPage.ViewModel;
using WebPage.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace WebPage.Areas.Profile.Controllers
{
    [Area("Profile")]
    [Authorize]
    public class ProfileController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly IGameRepository _gameRepository;

        public ProfileController(IUserRepository userRepository, IGameRepository gameRepository)
        {
            _userRepository = userRepository;
            _gameRepository = gameRepository;
        }

        public async Task<IActionResult> Index([FromServices] PortalRepository portal)
        {
            var username = User.Identity?.Name;
            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login", "Account", new { area = "" });

            var userData = await _userRepository.GetUserByUsernameAsync(username);
            var dailyCheckIn = await _gameRepository.GetDailyCheckInStateAsync(username);

            var model = new ProfileViewModel
            {
                UserName = userData?.UserName ?? username,
                FullName = userData?.FullName ?? User.FindFirst("FullName")?.Value ?? "",
                Email = userData?.Email ?? "",
                Phone = userData?.Phone ?? "",
                MemberSince = userData?.TimeCre ?? DateTime.Now,
                Balance = await _gameRepository.GetUserBalanceAsync(username),
                Characters = await portal.CharactersAsync(username),
                DailyCheckIn = dailyCheckIn
            };
            return View(model);
        }

        public async Task<IActionResult> Characters([FromServices] PortalRepository portal)
        {
            return View(await portal.CharactersAsync(User.Identity!.Name!));
        }

        public async Task<IActionResult> GachaHistory([FromServices] PortalRepository portal, int page = 1)
        {
            ViewBag.CurrentPage = Math.Max(1,page);
            return View(await portal.HistoryAsync(User.Identity!.Name!,page));
        }
    }
}
