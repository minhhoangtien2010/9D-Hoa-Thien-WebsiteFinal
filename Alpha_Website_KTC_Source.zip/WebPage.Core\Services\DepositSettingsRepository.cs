using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;

namespace WebPage.Services;

/// <summary>Public receiver details only. Provider keys and Telegram tokens remain server secrets.</summary>
public class DepositReceiver
{
    public int ReceiverId { get; set; } = 1;
    public string BankName { get; set; } = "";
    public string AccountNumber { get; set; } = "";
    public string AccountName { get; set; } = "";
    public string OrderPrefix { get; set; } = "";
    public string QrTemplate { get; set; } = "compact";
    public bool IsEnabled { get; set; } = true;
    public bool IsVisible { get; set; }
    public bool EnableGateway { get; set; }
    public byte[] Version { get; set; } = [];
    public string VersionToken
    {
        get => Convert.ToBase64String(Version);
        set => Version = string.IsNullOrWhiteSpace(value) ? [] : Convert.FromBase64String(value);
    }
    public DateTime UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

public sealed class DepositReceiverRevision : DepositReceiver
{
    public long RevisionId { get; set; }
    public string ChangeSource { get; set; } = "";
    public string? SqlLogin { get; set; }
    public bool IsInitial { get; set; }
}

public sealed class DepositOrderSnapshot : DepositReceiver
{
    public int TransactionId { get; set; }
    public string OrderCode { get; set; } = "";
    public bool IsGateway { get; set; }
    public bool IsLegacy { get; set; }
    public DateTime CreatedAt { get; set; }
    public string Username { get; set; } = "";
    public decimal Amount { get; set; }
    public string Status { get; set; } = "";
    public DateTime? CompletedAt { get; set; }
}

public sealed class DepositConfigNotification : DepositReceiver
{
    public long NotificationId { get; set; }
    public long RevisionId { get; set; }
    public string? ChatId { get; set; }
    public string Status { get; set; } = "";
    public int Attempts { get; set; }
    public string? LastError { get; set; }
    public DateTime? SentAt { get; set; }
}

/// <summary>SQL is the single receiver source. All orders retain the exact details used to create their QR.</summary>
public sealed class DepositSettingsRepository(IConfiguration configuration)
{
    private SqlConnection Connection() => new(configuration.GetConnectionString("DefaultConnection"));

    public async Task<DepositReceiver> GetCurrentAsync()
    {
        using var c = Connection();
        return await c.QuerySingleAsync<DepositReceiver>("sp_Web_Deposit_Receiver", commandType: CommandType.StoredProcedure);
    }

    public async Task<List<DepositReceiverRevision>> HistoryAsync(int page = 1)
    {
        using var c = Connection();
        return (await c.QueryAsync<DepositReceiverRevision>("sp_Web_Deposit_Admin_ReceiverHistory", new { page = Math.Max(1, page) }, commandType: CommandType.StoredProcedure)).AsList();
    }

    public async Task<DepositReceiver> GetLegacyReceiverAsync()
    {
        using var c = Connection();
        return await c.QuerySingleAsync<DepositReceiver>("sp_Web_Deposit_LegacyReceiver", commandType: CommandType.StoredProcedure);
    }

    public async Task<DepositOrderSnapshot?> GetLegacyOrderAsync(int transactionId)
    {
        using var c = Connection();
        return await c.QuerySingleOrDefaultAsync<DepositOrderSnapshot>("sp_Web_Deposit_LegacyOrder", new { transactionId }, commandType: CommandType.StoredProcedure);
    }

    public async Task<DepositReceiver> SaveAsync(DepositReceiver model, string actor)
    {
        using var c = Connection();
        return await c.QuerySingleAsync<DepositReceiver>("sp_Web_Deposit_Admin_SaveReceiver", new
        {
            model.BankName, model.AccountNumber, model.AccountName, model.OrderPrefix,
            model.QrTemplate, model.IsEnabled, model.EnableGateway, model.IsVisible,
            expectedVersion = model.Version, actor
        }, commandType: CommandType.StoredProcedure);
    }

    public async Task CaptureOrderAsync(int transactionId, DepositReceiver receiver, string orderCode, bool isGateway = false)
    {
        using var c = Connection();
        await c.ExecuteAsync("sp_Web_Deposit_CaptureOrder", new { transactionId, receiverVersion = receiver.Version, orderCode, isGateway }, commandType: CommandType.StoredProcedure);
    }

    public async Task<DepositOrderSnapshot?> GetOrderAsync(int transactionId)
    {
        using var c = Connection();
        return await c.QuerySingleOrDefaultAsync<DepositOrderSnapshot>("sp_Web_Deposit_Order", new { transactionId }, commandType: CommandType.StoredProcedure);
    }

    public async Task<DepositOrderSnapshot?> GetOrderForContentAsync(string content, bool isGateway = false)
    {
        using var c = Connection();
        return await c.QuerySingleOrDefaultAsync<DepositOrderSnapshot>("sp_Web_Deposit_OrderForContent", new { content, isGateway }, commandType: CommandType.StoredProcedure);
    }

    public async Task<DepositConfigNotification?> ClaimNotificationAsync(Guid leaseId, CancellationToken token = default)
    {
        using var c = Connection();
        return await c.QuerySingleOrDefaultAsync<DepositConfigNotification>(new CommandDefinition("sp_Web_Deposit_ClaimNotification", new { leaseId }, commandType: CommandType.StoredProcedure, cancellationToken: token));
    }

    public async Task FinishNotificationAsync(long id, Guid leaseId, string status, TelegramCall result)
    {
        using var c = Connection();
        await c.ExecuteAsync("sp_Web_Deposit_FinishNotification", new { id, leaseId, status, messageId = result.MessageId, error = result.Success ? null : result.Message, retryAfter = result.RetryAfter }, commandType: CommandType.StoredProcedure);
    }

    public async Task<List<DepositConfigNotification>> NotificationsAsync(int page = 1)
    {
        using var c = Connection();
        return (await c.QueryAsync<DepositConfigNotification>("sp_Web_Deposit_Admin_Notifications", new { page = Math.Max(1, page) }, commandType: CommandType.StoredProcedure)).AsList();
    }

    public async Task RetryNotificationAsync(long id, string actor)
    {
        using var c = Connection();
        await c.ExecuteAsync("sp_Web_Deposit_Admin_RetryNotification", new { id, actor }, commandType: CommandType.StoredProcedure);
    }
}
