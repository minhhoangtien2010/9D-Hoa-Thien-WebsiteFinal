using System.ComponentModel.DataAnnotations;
using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;

namespace WebPage.Services;

public sealed class CharacterRenamePrice
{
    public int PriceId { get; set; }
    [Required, StringLength(120)] public string Name { get; set; } = "Đổi tên nhân vật";
    [Range(1, 1000000)] public int Price { get; set; } = 200;
    public bool IsEnabled { get; set; } = true;
    public bool IsCurrent { get; set; }
    public bool IsArchived { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string UpdatedBy { get; set; } = "";
    public string? Version { get; set; }
}
public sealed class RenameCharacter
{
    public int CharacterId { get; set; }
    public string Name { get; set; } = "";
    public int Faction { get; set; }
    public int Responsibility { get; set; }
    public int Sex { get; set; }
    public bool IsOnline { get; set; }
    public bool CanRename { get; set; }
}
public sealed class CharacterRenameRequest
{
    public Guid RequestId { get; set; }
    public string Username { get; set; } = "";
    public int MemberGuid { get; set; }
    public int CharacterId { get; set; }
    public string OldName { get; set; } = "";
    public string NewName { get; set; } = "";
    public int PriceId { get; set; }
    public int QuotedPrice { get; set; }
    public int ChargedPrice { get; set; }
    public string Status { get; set; } = "WaitingForServer";
    public DateTime CreatedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string UpdatedBy { get; set; } = "";
    public string AdminNote { get; set; } = "";
    public DateTime? CompletedAt { get; set; }
    public DateTime? LoginAllowedAt { get; set; }
    public int? PurchaseId { get; set; }
    public string Version { get; set; } = "";
    public string StatusLabel => Status switch
    {
        "WaitingForServer" => "Chờ xử lý · Chưa thu phí",
        "Cancelled" => "Đã hủy", "Rejected" => "Đã từ chối", "Expired" => "Hết hạn", "Applied" => "Đã đổi tên", _ => Status
    };
}
public sealed class CharacterRenameAudit
{
    public long AuditId { get; set; }
    public Guid? RequestId { get; set; }
    public int? PriceId { get; set; }
    public string Action { get; set; } = "";
    public string Actor { get; set; } = "";
    public string Details { get; set; } = "";
    public DateTime CreatedAt { get; set; }
}
public sealed class CharacterRenameState
{
    public CharacterRenamePrice? Pricing { get; set; }
    public List<RenameCharacter> Characters { get; set; } = [];
    public List<CharacterRenameRequest> Requests { get; set; } = [];
    public decimal Balance { get; set; }
    public Guid NextRequestId { get; set; } = Guid.NewGuid();
}

/// <summary>Actual paid renames require a verified completed logout; game and wallet changes share one SQL transaction.</summary>
public sealed class CharacterRenameRepository(IConfiguration configuration)
{
    private SqlConnection Connection() => new(configuration.GetConnectionString("DefaultConnection"));
    public async Task<CharacterRenameState> StateAsync(string username)
    {
        using var connection = Connection();
        using var result = await connection.QueryMultipleAsync("sp_Web_Rename_State", new { Username = username }, commandType: CommandType.StoredProcedure);
        return new CharacterRenameState
        {
            Pricing = await result.ReadSingleOrDefaultAsync<CharacterRenamePrice>(),
            Characters = (await result.ReadAsync<RenameCharacter>()).AsList(),
            Requests = (await result.ReadAsync<CharacterRenameRequest>()).AsList(),
            Balance = await result.ReadSingleAsync<decimal>()
        };
    }
    public async Task RequestAsync(string username, int characterId, string newName, Guid requestId, int priceId, string priceVersion, string? ipAddress)
    {
        using var connection = Connection();
        await connection.ExecuteAsync("sp_Web_Rename_Request", new { Username = username, CharacterId = characterId, NewName = newName,
            RequestId = requestId, PriceId = priceId, PriceVersion = priceVersion, IPAddress = ipAddress ?? "" }, commandType: CommandType.StoredProcedure);
    }
    public async Task<CharacterRenameRequest> ApplyAsync(string username, int characterId, string newName, Guid requestId, int priceId, string priceVersion, string? ipAddress)
    {
        using var connection = Connection();
        return await connection.QuerySingleAsync<CharacterRenameRequest>("sp_Web_Rename_Apply", new { Username = username, CharacterId = characterId, NewName = newName,
            RequestId = requestId, PriceId = priceId, PriceVersion = priceVersion, IPAddress = ipAddress ?? "" }, commandType: CommandType.StoredProcedure);
    }
    public async Task CancelAsync(string username, Guid requestId)
    {
        using var connection = Connection();
        await connection.ExecuteAsync("sp_Web_Rename_Cancel", new { Username = username, RequestId = requestId }, commandType: CommandType.StoredProcedure);
    }
    public async Task<List<CharacterRenamePrice>> PricingAsync()
    {
        using var connection = Connection();
        return (await connection.QueryAsync<CharacterRenamePrice>("sp_Web_Rename_Admin_Pricing", commandType: CommandType.StoredProcedure)).AsList();
    }
    public async Task SavePriceAsync(CharacterRenamePrice price, string actor)
    {
        using var connection = Connection();
        await connection.ExecuteAsync("sp_Web_Rename_Admin_SavePrice", new { price.PriceId, price.Name, price.Price, price.IsEnabled,
            price.IsCurrent, price.Version, Actor = actor }, commandType: CommandType.StoredProcedure);
    }
    public async Task ArchivePriceAsync(int priceId, string version, string actor)
    {
        using var connection = Connection();
        await connection.ExecuteAsync("sp_Web_Rename_Admin_ArchivePrice", new { PriceId = priceId, Version = version, Actor = actor }, commandType: CommandType.StoredProcedure);
    }
    public async Task<List<CharacterRenameRequest>> RequestsAsync(string? username, int page)
    {
        using var connection = Connection();
        return (await connection.QueryAsync<CharacterRenameRequest>("sp_Web_Rename_Admin_Requests", new { Username = string.IsNullOrWhiteSpace(username) ? null : username, Page = Math.Max(1, page) }, commandType: CommandType.StoredProcedure)).AsList();
    }
    public async Task RejectAsync(Guid requestId, string version, string note, string actor)
    {
        using var connection = Connection();
        await connection.ExecuteAsync("sp_Web_Rename_Admin_Reject", new { RequestId = requestId, Version = version, Note = note, Actor = actor }, commandType: CommandType.StoredProcedure);
    }
    public async Task<List<CharacterRenameAudit>> AuditAsync(int page)
    {
        using var connection = Connection();
        return (await connection.QueryAsync<CharacterRenameAudit>("sp_Web_Rename_Admin_Audit", new { Page = Math.Max(1, page) }, commandType: CommandType.StoredProcedure)).AsList();
    }
}
