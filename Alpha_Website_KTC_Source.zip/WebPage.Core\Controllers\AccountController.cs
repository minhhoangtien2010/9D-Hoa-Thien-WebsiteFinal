using WebPage.ConfigurationModels;
using WebPage.Services;
using WebPage.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;

namespace WebPage.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountService _accountService;
        private readonly IUserRepository _userRepository;
        private readonly IEmailService _emailService;
        private readonly ILogger<AccountController> _logger;
        private readonly IStringLocalizer<SharedResource> _localizer;
        private readonly MyApplicationSettings _appSettings;

        public AccountController(
            IAccountService accountService,
            IUserRepository userRepository,
            IEmailService emailService,
            ILogger<AccountController> logger,
            IStringLocalizer<SharedResource> localizer,
            IOptions<MyApplicationSettings> appSettings)
        {
            _accountService = accountService;
            _userRepository = userRepository;
            _emailService = emailService;
            _logger = logger;
            _localizer = localizer;
            _appSettings = appSettings.Value;
        }

        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Register()
        {
            ViewBag.Question = GetSecurityQuestions("");
            return View(new RegisterModel());
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterModel model)
        {
            _logger.LogInformation("=== Register POST called === UserName={UserName}, Email={Email}", model.UserName, model.Email);

            ViewBag.Question = GetSecurityQuestions(model.Question);

            // Validate captcha trước
            if (!CaptchaController.ValidateCaptcha(HttpContext, model.Scode))
            {
                ModelState.AddModelError(nameof(model.Scode), _localizer["Register_CaptchaInvalid"].Value);
                _logger.LogWarning("Captcha validation failed for user {UserName}", model.UserName);
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Where(x => x.Value.Errors.Count > 0)
                    .ToDictionary(x => x.Key, x => x.Value.Errors.Select(e => e.ErrorMessage).ToList());
                _logger.LogWarning("ModelState invalid: {Errors}", string.Join(" | ", errors.Select(e => $"{e.Key}: {string.Join(", ", e.Value)}")));

                // DEBUG: luu errors vao ViewBag de hien thi tren trang
                ViewBag.DebugErrors = errors;
                return View(model);
            }

            // Lấy IP client
            var clientIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            _logger.LogInformation("Calling RegisterAsync for {UserName} from IP {IP}", model.UserName, clientIp);

            var result = await _accountService.RegisterAsync(model, clientIp);

            if (result.Succeeded)
            {
                _logger.LogInformation("User {UserName} registered successfully (guid={Guid}).", model.UserName, result.ResultCode);

                if (_appSettings.RequireEmailVerification)
                {
                    // Gui email xac nhan - email_verified = 0, phai verify moi dang nhap Launcher
                    try
                    {
                        var token = Guid.NewGuid().ToString("N");
                        var expiry = DateTime.UtcNow.AddHours(24);
                        await _userRepository.SetEmailVerifyTokenAsync(model.UserName, token, expiry);
                        await _emailService.SendVerificationEmailAsync(model.Email, model.UserName, token);
                        _logger.LogInformation("Verification email sent to {Email} for user {UserName}", model.Email, model.UserName);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to send verification email to {Email}", model.Email);
                        // Don't block registration if email fails
                    }
                }
                else
                {
                    // Khong can verify - tu dong set email_verified = 1
                    try
                    {
                        await _userRepository.SetEmailVerifiedAsync(model.UserName);
                        _logger.LogInformation("Email verification skipped, auto-verified for user {UserName}", model.UserName);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to auto-verify email for user {UserName}", model.UserName);
                    }
                }

                return RedirectToAction("Index", "Profile", new { area = "Profile" });
            }

            _logger.LogWarning("Registration failed for {UserName}: {Error}", model.UserName, result.ErrorMessage);
            ModelState.AddModelError(string.Empty, result.ErrorMessage ?? "Dang ky that bai.");
            return View(model);
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            var model = new LoginModel { ReturnUrl = SafeLoginReturnUrl(returnUrl) };
            ModelState.Remove(nameof(LoginModel.ReturnUrl));
            return LoginView(model);
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginModel model, string? returnUrl = null)
        {
            model.ReturnUrl = SafeLoginReturnUrl(model.ReturnUrl ?? returnUrl);
            // Do not echo an untrusted attempted return URL back into the hidden field after failure.
            ModelState.Remove(nameof(model.ReturnUrl));

            if (ModelState.IsValid)
            {
                var result = await _accountService.LoginAsync(model);
                if (result.Succeeded)
                {
                    return RedirectToLocal(model.ReturnUrl);
                }
                ModelState.AddModelError(string.Empty, result.ErrorMessage ?? "Dang nhap that bai.");
            }
            return LoginView(model);
        }

        private string SafeLoginReturnUrl(string? returnUrl) => !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? returnUrl : Url.Action("Index", "Profile", new { area = "Profile" }) ?? "/Profile";

        private IActionResult LoginView(LoginModel model)
        {
            ViewData["ReturnUrl"] = model.ReturnUrl;
            var destination = model.ReturnUrl?.TrimStart('~');
            if (destination is not null && (destination.Equals("/InGame", StringComparison.OrdinalIgnoreCase)
                || destination.StartsWith("/InGame/", StringComparison.OrdinalIgnoreCase))
                || WebPage.Helper.LegacyGameBrowser.IsMshtml(Request) && WebPage.Helper.LegacyGameBrowser.IsLegacyShopDestination(model.ReturnUrl))
            {
                Response.Headers["X-UA-Compatible"] = "IE=edge";
                Response.Headers["Cache-Control"] = "no-store";
                return View("~/Views/InGame/Login.cshtml", model);
            }
            return View("Login", model);
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await _accountService.LogoutAsync();
            return RedirectToAction("Index", "Home", new { area = "" });
        }

        [HttpPost, ActionName("Logout"), ValidateAntiForgeryToken]
        public async Task<IActionResult> LogoutPost()
        {
            await _accountService.LogoutAsync();
            return RedirectToAction("Index", "Home", new { area = "" });
        }

        // AJAX — kiểm tra username có sẵn chưa
        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> CheckUsername(string username)
        {
            if (string.IsNullOrWhiteSpace(username))
                return Json(new { available = false });

            var available = await _accountService.IsUsernameAvailableAsync(username);
            return Json(new { available });
        }

        // AJAX — kiểm tra email có sẵn chưa
        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> CheckEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return Json(new { available = false });

            var available = await _accountService.IsEmailAvailableAsync(email);
            return Json(new { available });
        }

        // ============================================================
        // Email Verification
        // ============================================================

        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> VerifyEmail(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                ViewBag.Success = false;
                ViewBag.Message = _localizer["Email_InvalidToken"].Value;
                return View();
            }

            var result = await _userRepository.VerifyEmailAsync(token);

            switch (result)
            {
                case 1:
                    ViewBag.Success = true;
                    ViewBag.Message = _localizer["Email_Verified"].Value;
                    break;
                case -2:
                    ViewBag.Success = false;
                    ViewBag.Message = _localizer["Email_TokenExpired"].Value;
                    break;
                default:
                    ViewBag.Success = false;
                    ViewBag.Message = _localizer["Email_InvalidToken"].Value;
                    break;
            }

            return View();
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResendVerification()
        {
            var username = User.Identity?.Name;
            if (string.IsNullOrEmpty(username))
                return RedirectToAction("Login");

            try
            {
                var userData = await _userRepository.GetUserByUsernameAsync(username);
                if (userData == null || string.IsNullOrEmpty(userData.Email))
                {
                    TempData["Error"] = _localizer["Email_NoEmail"].Value;
                    return RedirectToAction("Index", "Settings", new { area = "Profile" });
                }

                var token = Guid.NewGuid().ToString("N");
                var expiry = DateTime.UtcNow.AddHours(24);
                await _userRepository.SetEmailVerifyTokenAsync(username, token, expiry);
                await _emailService.SendVerificationEmailAsync(userData.Email, username, token);

                TempData["Success"] = _localizer["Email_Resent"].Value;
                _logger.LogInformation("Verification email resent to {Email} for user {UserName}", userData.Email, username);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to resend verification email for {UserName}", username);
                TempData["Error"] = _localizer["Email_SendFailed"].Value;
            }

            return RedirectToAction("Index", "Settings", new { area = "Profile" });
        }

        private ActionResult RedirectToLocal(string? returnUrl)
        {
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return LocalRedirect(returnUrl);
            }
            return base.RedirectToAction("Index", "Home");
        }

        private List<SelectListItem> GetSecurityQuestions(string selectedValue)
        {
            var questions = new List<SelectListItem>
            {
                new SelectListItem { Value = "q1", Text = _localizer["Question_FavoriteColor"].Value, Selected = ("q1" == selectedValue) },
                new SelectListItem { Value = "q2", Text = _localizer["Question_FirstPet"].Value, Selected = ("q2" == selectedValue) },
                new SelectListItem { Value = "q3", Text = _localizer["Question_PrimarySchool"].Value, Selected = ("q3" == selectedValue) },
                new SelectListItem { Value = "q4", Text = _localizer["Question_ChildhoodFriend"].Value, Selected = ("q4" == selectedValue) }
            };

            return questions;
        }
    }
}
