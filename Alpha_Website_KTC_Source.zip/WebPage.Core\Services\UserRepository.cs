using WebPage.ViewModel;
using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace WebPage.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly string _connectionString;

        public UserRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            if (string.IsNullOrEmpty(_connectionString))
            {
                throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            }
        }

        public async Task<(int LoginStatus, UserDataPoco? UserData)> ValidateUserCredentialsAsync(string username, string plainPassword)
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            var loginParams = new DynamicParameters();
            loginParams.Add("@member_id", username);
            loginParams.Add("@member_pwd", plainPassword);
            loginParams.Add("@return", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_Login", loginParams, commandType: CommandType.StoredProcedure);
            int loginStatus = loginParams.Get<int>("@return");

            // Lay user data khi login thanh cong (1) hoac chua verify email (-4)
            // Web login cho phep bo qua verify, Launcher se tu check rieng
            if (loginStatus == 1 || loginStatus == -4)
            {
                var detailParams = new DynamicParameters();
                detailParams.Add("@username", username);

                var userData = await connection.QueryFirstOrDefaultAsync<UserDataPoco>(
                    "sp_Web_Portal_UserDetails", detailParams, commandType: CommandType.StoredProcedure);
                return (loginStatus, userData);
            }
            return (loginStatus, null);
        }

        public async Task<int> CreateUserAsync(string username, string plainPassword, string email, string phone, string clientIpAddress,
            string fullname = null, string address = null, string accountCode = null,
            string question = null, string answer = null, string inviteCode = null)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);
            parameters.Add("@password", plainPassword);
            parameters.Add("@email", email);
            parameters.Add("@phone", phone);
            parameters.Add("@ip", clientIpAddress);
            parameters.Add("@fullname", fullname);
            parameters.Add("@address", address);
            parameters.Add("@account_code", accountCode);
            parameters.Add("@question", question);
            parameters.Add("@answer", answer);
            parameters.Add("@invite_code", inviteCode);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_Register", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<bool> CheckUserExistsAsync(string username)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);

            var result = await connection.QueryFirstOrDefaultAsync(
                "sp_Web_CheckUser", parameters, commandType: CommandType.StoredProcedure);
            return result != null;
        }

        public async Task<bool> CheckEmailExistsAsync(string email)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@email", email);

            var result = await connection.QueryFirstOrDefaultAsync(
                "sp_Web_CheckEmail", parameters, commandType: CommandType.StoredProcedure);
            return result != null;
        }

        public async Task<int> ChangePasswordAsync(string username, string oldPlainPassword, string newPlainPassword)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);
            parameters.Add("@old_password", oldPlainPassword);
            parameters.Add("@new_password", newPlainPassword);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_ChangePassword", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<UserDataPoco> GetUserByUsernameAsync(string username)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);

            return await connection.QueryFirstOrDefaultAsync<UserDataPoco>(
                "sp_Web_Portal_UserDetails", parameters, commandType: CommandType.StoredProcedure);
        }

        // ============================================================
        // EMAIL VERIFICATION
        // ============================================================

        public async Task<int> SetEmailVerifyTokenAsync(string username, string token, DateTime expiry)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);
            parameters.Add("@token", token);
            parameters.Add("@expiry", expiry);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_SetEmailVerifyToken", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> VerifyEmailAsync(string token)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@token", token);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_VerifyEmail", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> UpdateEmailAsync(string username, string newEmail, string token, DateTime expiry)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);
            parameters.Add("@new_email", newEmail);
            parameters.Add("@token", token);
            parameters.Add("@expiry", expiry);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_UpdateEmail", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<bool> IsEmailVerifiedAsync(string username)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);

                var result = await connection.QueryFirstOrDefaultAsync<dynamic>(
                    "sp_Web_IsEmailVerified", parameters, commandType: CommandType.StoredProcedure);

                return result?.IsVerified == true;
            }
            catch
            {
                return false;
            }
        }

        public async Task SetEmailVerifiedAsync(string username)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);

            await connection.ExecuteAsync("sp_Web_AutoVerifyEmail", parameters, commandType: CommandType.StoredProcedure);
        }

    }
}
