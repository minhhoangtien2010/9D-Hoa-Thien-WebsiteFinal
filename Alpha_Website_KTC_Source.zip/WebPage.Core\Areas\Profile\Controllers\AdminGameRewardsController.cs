using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using WebPage.Services;

namespace WebPage.Areas.Profile.Controllers;

public partial class AdminController {
 private static bool IsManagedGame(string? game)=>game is "wheel" or "card" or "chest" or "box" or "lotto";

 public async Task<IActionResult> GameRewards([FromServices] PortalRepository portal,[FromServices] GameVisibilityRepository visibility,string game="wheel") {
  if(!IsManagedGame(game))return BadRequest();
  var model=new GameRewardsAdminModel{GameType=game,Visibility=await visibility.ListAsync(),Rewards=await portal.GameRewardsAsync(true),Configs=await portal.ConfigsAsync(),Wheels=await _gameRepository.GetLuckyWheelConfigsAsync(),Cards=await _gameRepository.GetGiftBoxConfigsAsync()};
  foreach(var config in model.Cards)model.CardRounds.AddRange(await _gameRepository.GetGiftBoxRoundsAsync(config.ConfigId));
  return View(model);
 }

 [HttpPost,ValidateAntiForgeryToken]
 public async Task<IActionResult> GameVisibilitySave([FromServices] GameVisibilityRepository visibility,string game,bool isVisible,string? versionToken) {
  if(!IsManagedGame(game))return BadRequest();
  byte[] version=[];
  try {version=Convert.FromBase64String(versionToken??"");}catch(FormatException){}
  if(version.Length!=8){TempData["Error"]="Phiên bản hiển thị không hợp lệ. Tải lại trang trước khi lưu.";return RedirectToAction(nameof(GameRewards),new{game});}
  try {await visibility.SaveAsync(game,isVisible,User.Identity!.Name!,version);TempData["Success"]=isVisible?"Đã hiện trò chơi trên Trang chủ và Tiên Duyên Các.":"Đã ẩn trò chơi và chặn lượt chơi mới trên website. Phần thưởng, giá và lịch sử được giữ nguyên.";}
  catch(SqlException ex) when(ex.Number==51311){TempData["Error"]="Hiển thị trò chơi đã thay đổi ở phiên khác hoặc SQL. Tải lại và kiểm tra trước khi lưu.";}
  return RedirectToAction(nameof(GameRewards),new{game});
 }

 [HttpPost,ValidateAntiForgeryToken]
 public async Task<IActionResult> GameRewardConfigure([FromServices] PortalRepository portal,string game,int id,int weight,bool isActive) {
  if(!IsManagedGame(game)||id<1||weight<0||weight>1000000)return BadRequest();
  try {await portal.ConfigureGameRewardAsync(game,id,weight,isActive);TempData["Success"]="Đã lưu trạng thái và trọng số. Tỷ lệ được tính lại từ dữ liệu SQL hiện có.";}
  catch(SqlException ex) when(ex.Number>=50000&&ex.Number<50100){TempData["Error"]=ex.Message;}
  return RedirectToAction(nameof(GameRewards),new{game});
 }

 [HttpPost,ValidateAntiForgeryToken]
 public async Task<IActionResult> GameRewardDelete([FromServices] PortalRepository portal,string game,int id) {
  if(!IsManagedGame(game)||id<1)return BadRequest();
  var archived=await portal.DeleteGameRewardAsync(game,id);
  TempData["Success"]=archived?"Phần thưởng đã có trong lịch sử hoặc bàn chơi: đã ẩn và đặt trọng số 0 để giữ dữ liệu đối soát.":"Đã xóa phần thưởng. Lịch sử nhận quà trước đây được giữ nguyên.";
  return RedirectToAction(nameof(GameRewards),new{game});
 }
}
