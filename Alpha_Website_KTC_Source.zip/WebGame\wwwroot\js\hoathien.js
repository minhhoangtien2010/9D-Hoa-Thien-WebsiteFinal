/* Shared presentation helpers. Account, payment and game state are server owned. */
(() => {
 "use strict";
 let toastTimer;
 window.toast = message => {const target=document.getElementById('toast');if(!target)return;target.textContent=String(message);target.classList.add('on');clearTimeout(toastTimer);toastTimer=setTimeout(()=>target.classList.remove('on'),2600);};
 const balance=document.getElementById('hdrXu');
 if(balance)fetch('/Gacha/Status',{credentials:'same-origin',headers:{Accept:'application/json'}}).then(r=>r.ok&&!r.redirected?r.json():null).then(data=>{if(data?.isLoggedIn)balance.textContent=Number(data.balance||0).toLocaleString('vi-VN')+' xu';}).catch(()=>{});
  (function ambient() {
    var cv = document.createElement("canvas"); cv.id = "amb"; cv.setAttribute("aria-hidden", "true"); document.body.appendChild(cv);
    var mq = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)"); if (mq && mq.matches) { cv.style.display = "none"; return; }
    var ctx = cv.getContext("2d"), P = [], W = 0, H = 0, raf = 0, N = window.innerWidth < 700 ? 12 : 30;
    function size() { W = cv.width = window.innerWidth; H = cv.height = window.innerHeight; }
    function mk(init) { var petal = Math.random() < 0.55; return { p: petal, x: Math.random() * W, y: init ? Math.random() * H : (petal ? -14 : H + 10), r: petal ? 3 + Math.random() * 3 : 0.8 + Math.random() * 1.8, v: petal ? 0.35 + Math.random() * 0.6 : 0.2 + Math.random() * 0.5, s: Math.random() * 6.28, a: 0.25 + Math.random() * 0.5, t: Math.random() * 6.28 }; }
    size(); for (var i = 0; i < N; i++) P.push(mk(true));
    window.addEventListener("resize", size);
    function loop() {
      ctx.clearRect(0, 0, W, H);
      for (var i = 0; i < P.length; i++) {
        var o = P[i]; o.s += 0.015; o.t += 0.03; o.x += Math.sin(o.s) * (o.p ? 0.9 : 0.35) + (o.p ? 0.25 : 0);
        o.y += o.p ? o.v : -o.v;
        if (o.y > H + 16 || o.y < -16 || o.x > W + 20) P[i] = mk(false);
        if (o.p) { ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(o.t); ctx.scale(1, 0.6 + 0.4 * Math.sin(o.t * 1.3)); ctx.fillStyle = "rgba(255,170,190," + (o.a * 0.7).toFixed(2) + ")"; ctx.beginPath(); ctx.ellipse(0, 0, o.r, o.r * 0.55, 0, 0, 6.28); ctx.fill(); ctx.restore(); }
        else { var g = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, o.r * 4); g.addColorStop(0, "rgba(255,214,120," + o.a.toFixed(2) + ")"); g.addColorStop(1, "rgba(255,214,120,0)"); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(o.x, o.y, o.r * 4, 0, 6.28); ctx.fill(); }
      }
      raf = requestAnimationFrame(loop);
    }
    loop();
    document.addEventListener("visibilitychange", function () { cancelAnimationFrame(raf); if (!document.hidden) loop(); });
  })();
})();
