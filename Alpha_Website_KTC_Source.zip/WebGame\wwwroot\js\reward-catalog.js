(() => {
    const containers = [...document.querySelectorAll('[data-reward-shop-selector]')];
    if (!containers.length) return;
    let items = [], loading, catalogReady = false;
    const load = () => loading ||= (catalogReady = false, fetch('/Profile/Admin/RewardCatalog', {cache:'no-store'}).then(r => {if(!r.ok)throw Error();return r.json();}).then(data => {if(!Array.isArray(data))throw Error();items=data;catalogReady=true;return items;}).finally(() => loading = null));
    for (const box of containers) {
        const select = box.querySelector('[data-reward-select]'), search = box.querySelector('[data-reward-search]'), form = box.closest('form');
        const status = box.querySelector('[data-reward-status]');
        const validation = box.querySelector('[data-reward-validation]'), preview = box.querySelector('.reward-selector-preview');
        const cashId = form?.elements.namedItem('CashItemId'), rewardType = form?.elements.namedItem('RewardType');
        function validate() {
            if (!validation) return;
            const type = rewardType ? Number(rewardType.value) : null, id = Number(cashId?.value || 0);
            validation.className = 'muted';
            if ((type !== null && type !== 1) || (type === null && id === 0)) {
                validation.textContent = 'Phần thưởng hiện không dùng vật phẩm game; không cần đối chiếu ID với Kỳ Trân Các.';
                preview.hidden = true; return;
            }
            if (!catalogReady) {validation.textContent = 'Chưa đối chiếu được ID với danh mục hiện tại. Tải lại danh mục trước khi kiểm tra.';preview.hidden=true;return;}
            const matches = items.filter(item => Number(item.cashItemId) === id && id > 0);
            if (!matches.length) {
                validation.className = 'account-error';
                validation.textContent = id > 0 ? 'ID '+id+' chưa có trong Kỳ Trân Các; kiểm tra ID game trước khi lưu.' : 'Nhập CashItemId hợp lệ hoặc chọn vật phẩm từ Kỳ Trân Các trước khi lưu phần thưởng vật phẩm.';
                preview.hidden = true; return;
            }
            validation.className = 'account-success';
            validation.textContent = 'ID '+id+' khớp Kỳ Trân Các: '+[...new Set(matches.map(item=>item.itemName))].join('; ')+(matches.every(item=>!item.isActive)?' (hiện đang ẩn ở Shop).':'.');
            const selected = matches.find(item=>String(item.itemId)===select.value) || matches[0];
            box.querySelector('[data-reward-icon]').src = selected.icon;
            box.querySelector('[data-reward-title]').textContent = selected.itemName;
            box.querySelector('[data-reward-details]').textContent = 'CashItemId: '+id+' · Danh mục hiện tại: '+(selected.categoryName||'Kỳ Trân Các');
            preview.hidden = false;
        }
        function options() {
            const current = select.value, query = search.value.trim().toLocaleLowerCase('vi');
            select.replaceChildren(new Option('— Chọn vật phẩm —', ''));
            items.filter(x => !query || (x.itemName+' '+x.cashItemId).toLocaleLowerCase('vi').includes(query)).forEach(item => select.add(new Option(item.itemName+' · ID '+item.cashItemId+(item.isActive?'':' · Đang ẩn ở Shop'), String(item.itemId))));
            if ([...select.options].some(x => x.value === current)) select.value = current;
        }
        function set(name, value) {const field=form?.elements.namedItem(name);if(field&&field instanceof HTMLElement){field.value=value;field.dispatchEvent(new Event('change',{bubbles:true}));}}
        async function refresh(){try{await load();options();status.textContent=items.length+' vật phẩm được đọc trực tiếp từ dữ liệu Kỳ Trân Các.';}catch{status.textContent='Chưa tải được danh mục. Bạn có thể thử lại hoặc nhập ID trực tiếp.';}finally{validate();}}
        select.addEventListener('change', () => {
            const item = items.find(x => String(x.itemId) === select.value);if(!item)return;
            set('CashItemId',item.cashItemId);set('CashItemCount',Math.max(1,item.cashItemCount||1));set('ItemCount',Math.max(1,item.cashItemCount||1));
            for(const name of ['PrizeName','GiftName','Name'])set(name,item.itemName);
            set('RewardType','1');
            const image=box.querySelector('[data-reward-icon]');image.src=item.icon;
            box.querySelector('[data-reward-title]').textContent=item.itemName;
            box.querySelector('[data-reward-details]').textContent='CashItemId: '+item.cashItemId+' · Số lượng: '+Math.max(1,item.cashItemCount||1)+' · '+(item.categoryName||'Kỳ Trân Các');
            box.querySelector('.reward-selector-preview').hidden=false;
            status.textContent='Đã điền thông tin. Kiểm tra trọng số, số lượng và lưu phần thưởng để áp dụng.';
            validate();
        });
        for (const field of [cashId,rewardType]) if(field) {field.addEventListener('change',validate);field.addEventListener('input',validate);}
        search.addEventListener('input',options);box.querySelector('[data-reward-refresh]').addEventListener('click',refresh);refresh();
    }
})();
