using Microsoft.AspNetCore.Mvc;
using WebPage.Services;

namespace WebPage.Areas.Profile.Controllers;

public partial class AdminController
{
    [HttpGet]
    public async Task<IActionResult> RewardCatalog([FromServices] ShopImageService images)
    {
        Response.Headers.CacheControl = "no-store";
        var items = await _gameRepository.GetAllShopItemsAsync();
        return Json(items.Where(x => x.CashItemId > 0).Select(x => new
        {
            x.ItemId, x.ItemName, x.CategoryName, x.CashItemId, x.CashItemCount, x.IsActive,
            icon = images.Resolve(x.IconPath).Url
        }));
    }
}
