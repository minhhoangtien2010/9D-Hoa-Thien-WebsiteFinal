(() => {
    const headerBalance = document.getElementById('hdrXu');
    if (headerBalance) fetch('/Gacha/Status', {credentials:'same-origin',headers:{Accept:'application/json'}})
        .then(response => response.ok && !response.redirected ? response.json() : null)
        .then(data => {if (data?.isLoggedIn) headerBalance.textContent = Number(data.balance || 0).toLocaleString('vi-VN') + ' xu';})
        .catch(() => {});
    document.addEventListener('error', event => {
        const image = event.target;
        if (!(image instanceof HTMLImageElement) || !image.hasAttribute('data-shop-image') || image.dataset.replaced) return;
        image.dataset.replaced = 'true';
        image.src = image.dataset.fallbackSrc || '/images/shop-item-placeholder.svg';
    }, true);

    const success = document.querySelector('[data-checkin-success]');
    if (success) {
        success.focus({preventScroll:true});
        success.querySelector('[data-dismiss-checkin]')?.addEventListener('click', () => {
            success.hidden = true;
            document.querySelector('[data-checkin-form] button')?.focus();
        });
    }
    document.querySelector('[data-checkin-form]')?.addEventListener('submit', event => {
        const button = event.currentTarget.querySelector('button');
        button.disabled = true;
        button.textContent = 'Đang nhận thưởng…';
    });

    const sidebar = document.getElementById('profileMenu'), toggle = document.getElementById('sidebarToggle');
    if (!sidebar || !toggle) return;
    toggle.setAttribute('aria-controls', 'profileMenu');
    const backdrop = document.createElement('div');
    backdrop.className = 'profile-menu-backdrop';
    backdrop.hidden = true;
    document.body.append(backdrop);
    const mobile = () => matchMedia('(max-width:1023px)').matches;
    const close = () => {if(sidebar.classList.contains('sidebar-open'))toggle.click();toggle.focus({preventScroll:true});};
    sidebar.querySelector('[data-menu-close]')?.addEventListener('click', close);
    backdrop.addEventListener('click', close);
    const sync = () => {
        const open = mobile() && sidebar.classList.contains('sidebar-open');
        backdrop.hidden = !open;
        document.body.classList.toggle('profile-menu-open', open);
        if (open) sidebar.querySelector('[data-menu-close]')?.focus({preventScroll:true});
    };
    new MutationObserver(sync).observe(sidebar, {attributes:true, attributeFilter:['class']});
    addEventListener('resize', sync);
    document.addEventListener('keydown', event => {
        if (!mobile() || !sidebar.classList.contains('sidebar-open')) return;
        if (event.key === 'Escape') {event.preventDefault();close();}
        if (event.key === 'Tab') {
            const controls = [...sidebar.querySelectorAll('button,a,summary')].filter(x=>x.getClientRects().length);
            if (event.shiftKey && document.activeElement===controls[0]) {event.preventDefault();controls.at(-1)?.focus();}
            else if (!event.shiftKey && document.activeElement===controls.at(-1)) {event.preventDefault();controls[0]?.focus();}
        }
    });
})();
