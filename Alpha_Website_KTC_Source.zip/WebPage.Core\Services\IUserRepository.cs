using WebPage.ViewModel;

namespace WebPage.Services
{
    public class UserDataPoco
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string realPwdForOtpUpdate { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public DateTime TimeCre { get; set; }
        public string AccountCode { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
    }

    public interface IUserRepository
    {
        /// <summary>
        /// Xac thuc dang nhap — sp_Web_Login (MD5 hash trong SP).
        /// Truyen plain text password, SP tu hash MD5.
        /// Returns: (LoginStatus, UserData?)
        ///   1 = thanh cong, 0 = sai mat khau, -3 = bi khoa, -4 = email chua xac nhan
        /// </summary>
        Task<(int LoginStatus, UserDataPoco? UserData)> ValidateUserCredentialsAsync(string username, string plainPassword);

        /// <summary>
        /// Dang ky tai khoan — sp_Web_Register.
        /// Truyen plain text password, SP goi pr_Create_Account (MD5 hash).
        /// Luu day du thong tin: fullname, address, account_code, question, answer, invite_code.
        /// </summary>
        Task<int> CreateUserAsync(string username, string plainPassword, string email, string phone, string clientIpAddress,
            string fullname = null, string address = null, string accountCode = null,
            string question = null, string answer = null, string inviteCode = null);

        /// <summary>
        /// Kiem tra username da ton tai chua — sp_Web_CheckUser.
        /// </summary>
        Task<bool> CheckUserExistsAsync(string username);

        /// <summary>
        /// Kiem tra email da ton tai chua — sp_Web_CheckEmail.
        /// </summary>
        Task<bool> CheckEmailExistsAsync(string email);

        /// <summary>
        /// Doi mat khau — sp_Web_ChangePassword.
        /// Truyen plain text passwords, SP tu hash MD5.
        /// </summary>
        /// <returns>1 = thanh cong, -1 = user khong ton tai, -2 = mat khau cu sai</returns>
        Task<int> ChangePasswordAsync(string username, string oldPlainPassword, string newPlainPassword);

        /// <summary>
        /// Lay thong tin chi tiet user theo username — sp_Web_GetUserDetails.
        /// </summary>
        Task<UserDataPoco> GetUserByUsernameAsync(string username);

        // --- Email Verification ---

        /// <summary>
        /// Luu token xac nhan email — sp_Web_SetEmailVerifyToken.
        /// </summary>
        Task<int> SetEmailVerifyTokenAsync(string username, string token, DateTime expiry);

        /// <summary>
        /// Xac nhan email bang token — sp_Web_VerifyEmail.
        /// </summary>
        /// <returns>1 = thanh cong, -1 = token khong tim thay, -2 = token het han</returns>
        Task<int> VerifyEmailAsync(string token);

        /// <summary>
        /// Cap nhat email moi + gui verification — sp_Web_UpdateEmail.
        /// </summary>
        /// <returns>1 = thanh cong, -1 = user khong ton tai, -2 = email da duoc su dung</returns>
        Task<int> UpdateEmailAsync(string username, string newEmail, string token, DateTime expiry);

        /// <summary>
        /// Kiem tra email da duoc xac nhan chua — sp_Web_IsEmailVerified.
        /// </summary>
        Task<bool> IsEmailVerifiedAsync(string username);

        /// <summary>
        /// Tu dong set email_verified = 1 (bo qua verify) — sp_Web_AutoVerifyEmail.
        /// Dung khi RequireEmailVerification = false.
        /// </summary>
        Task SetEmailVerifiedAsync(string username);
    }
}
