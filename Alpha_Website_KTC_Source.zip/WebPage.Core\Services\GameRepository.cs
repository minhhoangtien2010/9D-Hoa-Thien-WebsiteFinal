using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace WebPage.Services
{
    public class GameRepository : IGameRepository
    {
        private readonly string _connectionString;
        private readonly ILogger<GameRepository> _logger;
        private static readonly int[] DailyCheckInRewards = { 50, 80, 120, 180, 250, 400, 650 };

        public GameRepository(IConfiguration configuration, ILogger<GameRepository> logger)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _logger = logger;
            if (string.IsNullOrEmpty(_connectionString))
            {
                throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            }
        }

        // ============================================================
        // NEWS
        // ============================================================

        public async Task<List<NewsPoco>> GetLatestNewsAsync(int top, string category = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);
                parameters.Add("@category", category);

                var result = await connection.QueryAsync<NewsPoco>(
                    "sp_GetLatestNews", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLatestNewsAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<NewsPoco>();
            }
        }

        public async Task<(List<NewsPoco> Items, int TotalCount)> GetNewsListAsync(string category, int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@category", category);
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<NewsPoco>(
                    "sp_GetNewsList", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetNewsListAsync failed — SP may not exist yet.");
                return (new List<NewsPoco>(), 0);
            }
        }

        public async Task<NewsPoco> GetNewsDetailAsync(int newsId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@newsId", newsId);

                return await connection.QueryFirstOrDefaultAsync<NewsPoco>(
                    "sp_GetNewsDetail", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetNewsDetailAsync failed for newsId={NewsId}", newsId);
                return null;
            }
        }

        public async Task<int> InsertNewsAsync(NewsPoco news)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@title", news.Title);
            parameters.Add("@excerpt", news.Excerpt);
            parameters.Add("@content", news.Content);
            parameters.Add("@category", news.Category);
            parameters.Add("@thumbnailUrl", news.ThumbnailUrl);
            parameters.Add("@authorName", news.AuthorName);
            parameters.Add("@isFeatured", news.IsFeatured);
            parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_InsertNews", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@newId");
        }

        public async Task<int> UpdateNewsAsync(NewsPoco news)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@newsId", news.NewsID);
            parameters.Add("@title", news.Title);
            parameters.Add("@excerpt", news.Excerpt);
            parameters.Add("@content", news.Content);
            parameters.Add("@category", news.Category);
            parameters.Add("@thumbnailUrl", news.ThumbnailUrl);
            parameters.Add("@isFeatured", news.IsFeatured);
            parameters.Add("@isPublished", news.IsPublished);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_UpdateNews", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> DeleteNewsAsync(int newsId)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@newsId", newsId);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_DeleteNews", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        // ============================================================
        // RANKINGS
        // ============================================================

        public async Task<List<RankingPoco>> GetRankingsAsync(int top = 100, string faction = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);
                parameters.Add("@faction", faction);

                var result = await connection.QueryAsync<RankingPoco>(
                    "sp_GetRankings", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetRankingsAsync failed — SP may not exist yet.");
                return new List<RankingPoco>();
            }
        }

        public async Task<List<TopPlayerPoco>> GetTopPlayersAsync(int top = 100, int? faction = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);
                parameters.Add("@faction", faction);

                var result = await connection.QueryAsync<TopPlayerPoco>(
                    "sp_Web_GetTopPlayers", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetTopPlayersAsync failed");
                return new List<TopPlayerPoco>();
            }
        }

        public async Task<List<TopRichestPoco>> GetTopRichestAsync(int top = 100)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);

                var result = await connection.QueryAsync<TopRichestPoco>(
                    "sp_Web_GetTopRichest", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetTopRichestAsync failed");
                return new List<TopRichestPoco>();
            }
        }

        public async Task<List<TopOnlinePoco>> GetTopOnlineAsync(int top = 100, int? faction = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);
                parameters.Add("@faction", faction);

                var result = await connection.QueryAsync<TopOnlinePoco>(
                    "sp_Web_GetTopOnline", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetTopOnlineAsync failed");
                return new List<TopOnlinePoco>();
            }
        }

        public async Task<List<TopInfamyPoco>> GetTopInfamyAsync(int top = 100, int? faction = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);
                parameters.Add("@faction", faction);

                var result = await connection.QueryAsync<TopInfamyPoco>(
                    "sp_Web_GetTopInfamy", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetTopInfamyAsync failed");
                return new List<TopInfamyPoco>();
            }
        }

        public async Task<List<TopHonorPoco>> GetTopHonorAsync(int top = 100, int? faction = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@top", top);
                parameters.Add("@faction", faction);

                var result = await connection.QueryAsync<TopHonorPoco>(
                    "sp_Web_GetTopHonor", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetTopHonorAsync failed");
                return new List<TopHonorPoco>();
            }
        }

        // ============================================================
        // FACTIONS
        // ============================================================

        public async Task<List<FactionPoco>> GetFactionsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<FactionPoco>(
                    "sp_GetFactions", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFactionsAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<FactionPoco>();
            }
        }

        // ============================================================
        // BOSS SPAWN TIMERS
        // ============================================================

        public async Task<List<BossSpawnTimerPoco>> GetBossSpawnTimersAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<BossSpawnTimerPoco>(
                    "sp_GetBossSpawnTimers", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetBossSpawnTimersAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<BossSpawnTimerPoco>();
            }
        }

        // ============================================================
        // SERVER INFO ITEMS
        // ============================================================

        public async Task<List<ServerInfoItemPoco>> GetServerInfoItemsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ServerInfoItemPoco>(
                    "sp_GetServerInfoItems", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetServerInfoItemsAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<ServerInfoItemPoco>();
            }
        }

        public async Task<List<ServerInfoItemPoco>> GetAllServerInfoItemsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ServerInfoItemPoco>(
                    "sp_GetAllServerInfoItems", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllServerInfoItemsAsync failed");
                return new List<ServerInfoItemPoco>();
            }
        }

        public async Task<ServerInfoItemPoco> GetServerInfoItemByIdAsync(int itemId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<ServerInfoItemPoco>(
                    "sp_GetServerInfoItemById",
                    new { ItemID = itemId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetServerInfoItemByIdAsync failed for ID={Id}", itemId);
                return null;
            }
        }

        public async Task<int> InsertServerInfoItemAsync(ServerInfoItemPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertServerInfoItem",
                    new { item.Icon, item.Title, item.Description, item.LinkUrl, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertServerInfoItemAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateServerInfoItemAsync(ServerInfoItemPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateServerInfoItem",
                    new { item.ItemID, item.Icon, item.Title, item.Description, item.LinkUrl, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateServerInfoItemAsync failed for ID={Id}", item.ItemID);
                return 0;
            }
        }

        public async Task<int> DeleteServerInfoItemAsync(int itemId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteServerInfoItem",
                    new { ItemID = itemId },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteServerInfoItemAsync failed for ID={Id}", itemId);
                return 0;
            }
        }

        // ============================================================
        // BOSS SPAWN TIMERS (admin CRUD)
        // ============================================================

        public async Task<List<BossSpawnTimerPoco>> GetAllBossSpawnTimersAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<BossSpawnTimerPoco>(
                    "sp_GetAllBossSpawnTimers", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllBossSpawnTimersAsync failed");
                return new List<BossSpawnTimerPoco>();
            }
        }

        public async Task<BossSpawnTimerPoco> GetBossSpawnTimerByIdAsync(int bossId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<BossSpawnTimerPoco>(
                    "sp_GetBossSpawnTimerById", new { BossID = bossId }, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetBossSpawnTimerByIdAsync failed for ID={Id}", bossId);
                return null;
            }
        }

        public async Task<int> InsertBossSpawnTimerAsync(BossSpawnTimerPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertBossSpawnTimer",
                    new { item.MapName, item.BossName, item.Level, item.Description, item.ImageUrl, item.SpawnTimes, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertBossSpawnTimerAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateBossSpawnTimerAsync(BossSpawnTimerPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateBossSpawnTimer",
                    new { item.BossID, item.MapName, item.BossName, item.Level, item.Description, item.ImageUrl, item.SpawnTimes, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateBossSpawnTimerAsync failed for ID={Id}", item.BossID);
                return 0;
            }
        }

        public async Task<int> DeleteBossSpawnTimerAsync(int bossId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteBossSpawnTimer", new { BossID = bossId }, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteBossSpawnTimerAsync failed for ID={Id}", bossId);
                return 0;
            }
        }

        // ============================================================
        // WEEKLY ACTIVITIES
        // ============================================================

        public async Task<List<WeeklyActivityPoco>> GetWeeklyActivitiesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<WeeklyActivityPoco>(
                    "sp_GetWeeklyActivities", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetWeeklyActivitiesAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<WeeklyActivityPoco>();
            }
        }

        public async Task<List<WeeklyActivityPoco>> GetAllWeeklyActivitiesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<WeeklyActivityPoco>(
                    "sp_GetAllWeeklyActivities", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllWeeklyActivitiesAsync failed");
                return new List<WeeklyActivityPoco>();
            }
        }

        public async Task<WeeklyActivityPoco> GetWeeklyActivityByIdAsync(int activityId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<WeeklyActivityPoco>(
                    "sp_GetWeeklyActivityById", new { ActivityID = activityId }, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetWeeklyActivityByIdAsync failed for ID={Id}", activityId);
                return null;
            }
        }

        public async Task<int> InsertWeeklyActivityAsync(WeeklyActivityPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertWeeklyActivity",
                    new { item.DayName, item.DayIndex, item.ActivityName, item.ActivityType, item.Level, item.Maps, item.SpawnTimes, item.Description, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertWeeklyActivityAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateWeeklyActivityAsync(WeeklyActivityPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateWeeklyActivity",
                    new { item.ActivityID, item.DayName, item.DayIndex, item.ActivityName, item.ActivityType, item.Level, item.Maps, item.SpawnTimes, item.Description, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateWeeklyActivityAsync failed for ID={Id}", item.ActivityID);
                return 0;
            }
        }

        public async Task<int> DeleteWeeklyActivityAsync(int activityId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteWeeklyActivity", new { ActivityID = activityId }, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteWeeklyActivityAsync failed for ID={Id}", activityId);
                return 0;
            }
        }

        // ============================================================
        // WEAPON REFINING LEVELS
        // ============================================================

        public async Task<List<WeaponRefiningLevelPoco>> GetWeaponRefiningLevelsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<WeaponRefiningLevelPoco>(
                    "sp_GetWeaponRefiningLevels", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetWeaponRefiningLevelsAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<WeaponRefiningLevelPoco>();
            }
        }

        public async Task<List<WeaponRefiningLevelPoco>> GetAllWeaponRefiningLevelsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<WeaponRefiningLevelPoco>(
                    "sp_GetAllWeaponRefiningLevels", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllWeaponRefiningLevelsAsync failed");
                return new List<WeaponRefiningLevelPoco>();
            }
        }

        public async Task<WeaponRefiningLevelPoco> GetWeaponRefiningLevelByIdAsync(int refineId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<WeaponRefiningLevelPoco>(
                    "sp_GetWeaponRefiningLevelById", new { RefineID = refineId }, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetWeaponRefiningLevelByIdAsync failed for ID={Id}", refineId);
                return null;
            }
        }

        public async Task<int> InsertWeaponRefiningLevelAsync(WeaponRefiningLevelPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertWeaponRefiningLevel",
                    new { item.Level, item.Rate, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertWeaponRefiningLevelAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateWeaponRefiningLevelAsync(WeaponRefiningLevelPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateWeaponRefiningLevel",
                    new { item.RefineID, item.Level, item.Rate, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateWeaponRefiningLevelAsync failed for ID={Id}", item.RefineID);
                return 0;
            }
        }

        public async Task<int> DeleteWeaponRefiningLevelAsync(int refineId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteWeaponRefiningLevel", new { RefineID = refineId }, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteWeaponRefiningLevelAsync failed for ID={Id}", refineId);
                return 0;
            }
        }

        // ============================================================
        // CLOTH REFINING LEVELS
        // ============================================================

        public async Task<List<ClothRefiningLevelPoco>> GetClothRefiningLevelsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ClothRefiningLevelPoco>(
                    "sp_GetClothRefiningLevels", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetClothRefiningLevelsAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<ClothRefiningLevelPoco>();
            }
        }

        public async Task<List<ClothRefiningLevelPoco>> GetAllClothRefiningLevelsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ClothRefiningLevelPoco>(
                    "sp_GetAllClothRefiningLevels", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllClothRefiningLevelsAsync failed");
                return new List<ClothRefiningLevelPoco>();
            }
        }

        public async Task<ClothRefiningLevelPoco> GetClothRefiningLevelByIdAsync(int refineId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<ClothRefiningLevelPoco>(
                    "sp_GetClothRefiningLevelById", new { RefineID = refineId }, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetClothRefiningLevelByIdAsync failed for ID={Id}", refineId);
                return null;
            }
        }

        public async Task<int> InsertClothRefiningLevelAsync(ClothRefiningLevelPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertClothRefiningLevel",
                    new { item.Level, item.Rate, item.Description, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertClothRefiningLevelAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateClothRefiningLevelAsync(ClothRefiningLevelPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateClothRefiningLevel",
                    new { item.RefineID, item.Level, item.Rate, item.Description, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateClothRefiningLevelAsync failed for ID={Id}", item.RefineID);
                return 0;
            }
        }

        public async Task<int> DeleteClothRefiningLevelAsync(int refineId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteClothRefiningLevel", new { RefineID = refineId }, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteClothRefiningLevelAsync failed for ID={Id}", refineId);
                return 0;
            }
        }

        // ============================================================
        // MAP INFO ITEMS
        // ============================================================

        public async Task<List<MapInfoItemPoco>> GetMapInfoItemsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<MapInfoItemPoco>(
                    "sp_GetMapInfoItems", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetMapInfoItemsAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<MapInfoItemPoco>();
            }
        }

        public async Task<List<MapInfoItemPoco>> GetAllMapInfoItemsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<MapInfoItemPoco>(
                    "sp_GetAllMapInfoItems", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllMapInfoItemsAsync failed");
                return new List<MapInfoItemPoco>();
            }
        }

        public async Task<MapInfoItemPoco> GetMapInfoItemByIdAsync(int mapId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<MapInfoItemPoco>(
                    "sp_GetMapInfoItemById", new { MapID = mapId }, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetMapInfoItemByIdAsync failed for ID={Id}", mapId);
                return null;
            }
        }

        public async Task<int> InsertMapInfoItemAsync(MapInfoItemPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertMapInfoItem",
                    new { item.Name, item.ExpRate, item.DropRate, item.FireRate, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertMapInfoItemAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateMapInfoItemAsync(MapInfoItemPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateMapInfoItem",
                    new { item.MapID, item.Name, item.ExpRate, item.DropRate, item.FireRate, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateMapInfoItemAsync failed for ID={Id}", item.MapID);
                return 0;
            }
        }

        public async Task<int> DeleteMapInfoItemAsync(int mapId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteMapInfoItem", new { MapID = mapId }, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteMapInfoItemAsync failed for ID={Id}", mapId);
                return 0;
            }
        }

        // ============================================================
        // FACTIONS (admin CRUD)
        // ============================================================

        public async Task<List<FactionPoco>> GetAllFactionsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<FactionPoco>(
                    "sp_GetAllFactions", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllFactionsAsync failed");
                return new List<FactionPoco>();
            }
        }

        public async Task<FactionPoco> GetFactionByIdAsync(int factionId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<FactionPoco>(
                    "sp_GetFactionById", new { FactionID = factionId }, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetFactionByIdAsync failed for ID={Id}", factionId);
                return null;
            }
        }

        public async Task<int> InsertFactionAsync(FactionPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_InsertFaction",
                    new { item.Name, item.Description, item.LoreContent, item.ImageUrl, item.IconUrl, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertFactionAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateFactionAsync(FactionPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_UpdateFaction",
                    new { item.FactionID, item.Name, item.Description, item.LoreContent, item.ImageUrl, item.IconUrl, item.SortOrder, item.IsActive },
                    commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateFactionAsync failed for ID={Id}", item.FactionID);
                return 0;
            }
        }

        public async Task<int> DeleteFactionAsync(int factionId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_DeleteFaction", new { FactionID = factionId }, commandType: CommandType.StoredProcedure);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteFactionAsync failed for ID={Id}", factionId);
                return 0;
            }
        }

        // ============================================================
        // GIFTCODES
        // ============================================================

        public async Task<GiftcodeRedeemResult> RedeemGiftcodeAsync(string username, string code)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);
            parameters.Add("@code", code);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@reward_coins", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@reward_items", dbType: DbType.String, size: 4000, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_RedeemGiftcode", parameters, commandType: CommandType.StoredProcedure);

            return new GiftcodeRedeemResult
            {
                ResultCode = parameters.Get<int>("@result"),
                RewardCoins = parameters.Get<int>("@reward_coins"),
                RewardItems = parameters.Get<string>("@reward_items")
            };
        }

        public async Task<(List<GiftcodePoco> Items, int TotalCount)> GetGiftcodesAsync(int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<GiftcodePoco>(
                    "sp_Admin_GetGiftcodes", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftcodesAsync failed");
                return (new List<GiftcodePoco>(), 0);
            }
        }

        public async Task<GiftcodePoco?> GetGiftcodeByIdAsync(int giftcodeId)
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryFirstOrDefaultAsync<GiftcodePoco>(
                "sp_Admin_GetGiftcodeById",
                new { giftcode_id = giftcodeId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<int> CreateGiftcodeAsync(GiftcodePoco giftcode)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@code", giftcode.Code);
            parameters.Add("@description", giftcode.Description);
            parameters.Add("@reward_coins", giftcode.RewardCoins);
            parameters.Add("@reward_items", giftcode.RewardItems);
            parameters.Add("@max_uses", giftcode.MaxUses);
            parameters.Add("@expiry_date", giftcode.ExpiryDate);
            parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Admin_CreateGiftcode", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@newId");
        }

        public async Task<int> UpdateGiftcodeAsync(GiftcodePoco giftcode)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@giftcode_id", giftcode.GiftcodeID);
            parameters.Add("@description", giftcode.Description);
            parameters.Add("@reward_coins", giftcode.RewardCoins);
            parameters.Add("@reward_items", giftcode.RewardItems);
            parameters.Add("@max_uses", giftcode.MaxUses);
            parameters.Add("@expiry_date", giftcode.ExpiryDate);
            parameters.Add("@is_active", giftcode.IsActive);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Admin_UpdateGiftcode", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> ToggleGiftcodeAsync(int giftcodeId)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@giftcode_id", giftcodeId);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Admin_ToggleGiftcode", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        // ============================================================
        // DEPOSIT MILESTONES
        // ============================================================

        public async Task<(List<DepositMilestonePoco> Items, decimal TotalDeposited)> GetDepositMilestonesAsync(string username)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@total_deposited", dbType: DbType.Decimal, direction: ParameterDirection.Output, precision: 18, scale: 0);

                var items = await connection.QueryAsync<DepositMilestonePoco>(
                    "sp_Web_GetDepositMilestones", parameters, commandType: CommandType.StoredProcedure);
                decimal totalDeposited = parameters.Get<decimal>("@total_deposited");

                return (items.AsList(), totalDeposited);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetDepositMilestonesAsync failed — SP may not exist yet");
                return (new List<DepositMilestonePoco>(), 0);
            }
        }

        public async Task<DepositMilestoneClaimResult> ClaimDepositMilestoneAsync(string username, int milestoneId)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@username", username);
            parameters.Add("@milestone_id", milestoneId);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@reward_coins", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@reward_items", dbType: DbType.String, size: 4000, direction: ParameterDirection.Output);
            parameters.Add("@reward_spins", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@claim_id", dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@claim_index", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Web_ClaimDepositMilestone", parameters, commandType: CommandType.StoredProcedure);

            return new DepositMilestoneClaimResult
            {
                ResultCode = parameters.Get<int>("@result"),
                RewardCoins = parameters.Get<int>("@reward_coins"),
                RewardItems = parameters.Get<string>("@reward_items"),
                RewardSpins = parameters.Get<int>("@reward_spins"),
                ClaimID = parameters.Get<int>("@claim_id"),
                ClaimIndex = parameters.Get<int>("@claim_index")
            };
        }

        public async Task<List<DepositMilestoneClaimPoco>> GetUserDepositClaimsAsync(string username, int top = 30)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var rows = await connection.QueryAsync<DepositMilestoneClaimPoco>(
                    "sp_Web_GetUserDepositClaims",
                    new { username, top },
                    commandType: CommandType.StoredProcedure);
                return rows.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetUserDepositClaimsAsync failed for user={Username}", username);
                return new List<DepositMilestoneClaimPoco>();
            }
        }

        public async Task UpdateDepositClaimStatusAsync(int claimId, string status, string note = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@claim_id", claimId);
                parameters.Add("@status", status);
                parameters.Add("@note", note);

                await connection.ExecuteAsync("sp_Web_UpdateDepositClaimStatus", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "UpdateDepositClaimStatusAsync failed for claim={ClaimId}", claimId);
            }
        }

        public async Task<(List<DepositMilestonePoco> Items, int TotalCount)> GetAllDepositMilestonesAsync(int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<DepositMilestonePoco>(
                    "sp_Admin_GetDepositMilestones", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllDepositMilestonesAsync failed");
                return (new List<DepositMilestonePoco>(), 0);
            }
        }

        public async Task<DepositMilestonePoco> GetDepositMilestoneByIdAsync(int milestoneId)
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryFirstOrDefaultAsync<DepositMilestonePoco>(
                "sp_Admin_GetDepositMilestoneById",
                new { milestone_id = milestoneId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<int> CreateDepositMilestoneAsync(DepositMilestonePoco milestone)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@milestone_name", milestone.MilestoneName);
            parameters.Add("@threshold_amount", milestone.ThresholdAmount);
            parameters.Add("@reward_coins", milestone.RewardCoins);
            parameters.Add("@reward_items", milestone.RewardItems);
            parameters.Add("@reward_spins", milestone.RewardSpins);
            parameters.Add("@description", milestone.Description);
            parameters.Add("@period_type", milestone.PeriodType ?? "Lifetime");
            parameters.Add("@week_start_day", milestone.WeekStartDay);
            parameters.Add("@period_start_date", milestone.PeriodStartDate);
            parameters.Add("@period_end_date", milestone.PeriodEndDate);
            parameters.Add("@is_repeatable", milestone.IsRepeatable);
            parameters.Add("@max_claims", milestone.MaxClaims);
            parameters.Add("@count_historical", milestone.CountHistorical);
            parameters.Add("@sort_order", milestone.SortOrder);
            parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Admin_CreateDepositMilestone", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@newId");
        }

        public async Task<int> UpdateDepositMilestoneAsync(DepositMilestonePoco milestone)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@milestone_id", milestone.MilestoneID);
            parameters.Add("@milestone_name", milestone.MilestoneName);
            parameters.Add("@threshold_amount", milestone.ThresholdAmount);
            parameters.Add("@reward_coins", milestone.RewardCoins);
            parameters.Add("@reward_items", milestone.RewardItems);
            parameters.Add("@reward_spins", milestone.RewardSpins);
            parameters.Add("@description", milestone.Description);
            parameters.Add("@period_type", milestone.PeriodType ?? "Lifetime");
            parameters.Add("@week_start_day", milestone.WeekStartDay);
            parameters.Add("@period_start_date", milestone.PeriodStartDate);
            parameters.Add("@period_end_date", milestone.PeriodEndDate);
            parameters.Add("@is_repeatable", milestone.IsRepeatable);
            parameters.Add("@max_claims", milestone.MaxClaims);
            parameters.Add("@count_historical", milestone.CountHistorical);
            parameters.Add("@sort_order", milestone.SortOrder);
            parameters.Add("@is_active", milestone.IsActive);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Admin_UpdateDepositMilestone", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> ToggleDepositMilestoneAsync(int milestoneId)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@milestone_id", milestoneId);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_Admin_ToggleDepositMilestone", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> DeleteDepositMilestoneAsync(int milestoneId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                await connection.ExecuteAsync(
                    "sp_Admin_DeleteDepositMilestone",
                    new { milestone_id = milestoneId },
                    commandType: CommandType.StoredProcedure);
                return 1;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteDepositMilestoneAsync failed for id={Id}", milestoneId);
                return -1;
            }
        }

        // ============================================================
        // SERVER CONFIG
        // ============================================================

        public async Task<Dictionary<string, string>> GetServerConfigAsync(string key = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@key", key);

                var configs = await connection.QueryAsync<ServerConfigPoco>(
                    "sp_GetServerConfig", parameters, commandType: CommandType.StoredProcedure);

                var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var config in configs)
                {
                    if (!string.IsNullOrEmpty(config.ConfigKey))
                        dict[config.ConfigKey] = config.ConfigValue ?? "";
                }
                return dict;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetServerConfigAsync failed — SP may not exist yet.");
                return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            }
        }

        // Live online player count from NineDragons_Account.dbo.Tbl_ND_GameConnect
        // (counts rows where cur_state != 0 — i.e. currently logged in)
        public async Task<int> GetActivePlayerCountAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var count = await connection.ExecuteScalarAsync<int>(
                    "SELECT COUNT(*) FROM [dbo].[Tbl_ND_GameConnect] WHERE [cur_state] <> 0");
                return count;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetActivePlayerCountAsync failed — table Tbl_ND_GameConnect may not be reachable.");
                return 0;
            }
        }

        public async Task<int> UpsertServerConfigAsync(string key, string value, string description = null)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@key", key);
            parameters.Add("@value", value);
            parameters.Add("@description", description);

            return await connection.ExecuteAsync("sp_UpsertServerConfig", parameters, commandType: CommandType.StoredProcedure);
        }

        // ============================================================
        // FEATURE CATEGORIES
        // ============================================================

        public async Task<List<FeatureCategoryPoco>> GetFeatureCategoriesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<FeatureCategoryPoco>(
                    "sp_GetFeatureCategories", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureCategoriesAsync failed — SP may not exist yet. Run Database/setup-all.sql");
                return new List<FeatureCategoryPoco>();
            }
        }

        public async Task<List<FeatureCategoryPoco>> GetAllFeatureCategoriesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<FeatureCategoryPoco>(
                    "sp_GetAllFeatureCategories", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllFeatureCategoriesAsync failed");
                return new List<FeatureCategoryPoco>();
            }
        }

        public async Task<FeatureCategoryPoco> GetFeatureCategoryBySlugAsync(string slug)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@slug", slug);

                return await connection.QueryFirstOrDefaultAsync<FeatureCategoryPoco>(
                    "sp_GetFeatureCategoryBySlug", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureCategoryBySlugAsync failed for slug={Slug}", slug);
                return null;
            }
        }

        public async Task<FeatureCategoryPoco> GetFeatureCategoryByIdAsync(int categoryId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", categoryId);

                return await connection.QueryFirstOrDefaultAsync<FeatureCategoryPoco>(
                    "sp_GetFeatureCategoryById", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureCategoryByIdAsync failed for id={Id}", categoryId);
                return null;
            }
        }

        public async Task<int> InsertFeatureCategoryAsync(FeatureCategoryPoco category)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@name", category.Name);
            parameters.Add("@slug", category.Slug);
            parameters.Add("@description", category.Description);
            parameters.Add("@iconUrl", category.IconUrl);
            parameters.Add("@sortOrder", category.SortOrder);
            parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_InsertFeatureCategory", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@newId");
        }

        public async Task<int> UpdateFeatureCategoryAsync(FeatureCategoryPoco category)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@categoryId", category.CategoryID);
            parameters.Add("@name", category.Name);
            parameters.Add("@slug", category.Slug);
            parameters.Add("@description", category.Description);
            parameters.Add("@iconUrl", category.IconUrl);
            parameters.Add("@sortOrder", category.SortOrder);
            parameters.Add("@isActive", category.IsActive);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_UpdateFeatureCategory", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> DeleteFeatureCategoryAsync(int categoryId)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@categoryId", categoryId);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_DeleteFeatureCategory", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        // ============================================================
        // FEATURE GUIDES
        // ============================================================

        public async Task<(List<FeatureGuidePoco> Items, int TotalCount)> GetFeatureGuidesAsync(int? categoryId, int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", categoryId);
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<FeatureGuidePoco>(
                    "sp_GetFeatureGuides", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureGuidesAsync failed");
                return (new List<FeatureGuidePoco>(), 0);
            }
        }

        public async Task<(List<FeatureGuidePoco> Items, int TotalCount)> GetAllFeatureGuidesAsync(int? categoryId, int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", categoryId);
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<FeatureGuidePoco>(
                    "sp_GetAllFeatureGuides", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllFeatureGuidesAsync failed");
                return (new List<FeatureGuidePoco>(), 0);
            }
        }

        public async Task<FeatureGuidePoco> GetFeatureGuideDetailAsync(int guideId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@guideId", guideId);

                return await connection.QueryFirstOrDefaultAsync<FeatureGuidePoco>(
                    "sp_GetFeatureGuideDetail", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureGuideDetailAsync failed for guideId={GuideId}", guideId);
                return null;
            }
        }

        public async Task<FeatureGuidePoco> GetFeatureGuideBySlugAsync(string slug)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@slug", slug);

                return await connection.QueryFirstOrDefaultAsync<FeatureGuidePoco>(
                    "sp_GetFeatureGuideBySlug", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureGuideBySlugAsync failed for slug={Slug}", slug);
                return null;
            }
        }

        public async Task<FeatureGuidePoco> GetFeatureGuideForEditAsync(int guideId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@guideId", guideId);

                return await connection.QueryFirstOrDefaultAsync<FeatureGuidePoco>(
                    "sp_GetFeatureGuideForEdit", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetFeatureGuideForEditAsync failed for guideId={GuideId}", guideId);
                return null;
            }
        }

        public async Task<int> InsertFeatureGuideAsync(FeatureGuidePoco guide)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@categoryId", guide.CategoryID);
            parameters.Add("@title", guide.Title);
            parameters.Add("@slug", guide.Slug);
            parameters.Add("@excerpt", guide.Excerpt);
            parameters.Add("@content", guide.Content);
            parameters.Add("@thumbnailUrl", guide.ThumbnailUrl);
            parameters.Add("@authorName", guide.AuthorName);
            parameters.Add("@sortOrder", guide.SortOrder);
            parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_InsertFeatureGuide", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@newId");
        }

        public async Task<int> UpdateFeatureGuideAsync(FeatureGuidePoco guide)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@guideId", guide.GuideID);
            parameters.Add("@categoryId", guide.CategoryID);
            parameters.Add("@title", guide.Title);
            parameters.Add("@slug", guide.Slug);
            parameters.Add("@excerpt", guide.Excerpt);
            parameters.Add("@content", guide.Content);
            parameters.Add("@thumbnailUrl", guide.ThumbnailUrl);
            parameters.Add("@sortOrder", guide.SortOrder);
            parameters.Add("@isPublished", guide.IsPublished);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_UpdateFeatureGuide", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<int> DeleteFeatureGuideAsync(int guideId)
        {
            using var connection = new SqlConnection(_connectionString);
            var parameters = new DynamicParameters();
            parameters.Add("@guideId", guideId);
            parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await connection.ExecuteAsync("sp_DeleteFeatureGuide", parameters, commandType: CommandType.StoredProcedure);
            return parameters.Get<int>("@result");
        }

        public async Task<List<FeatureGuidePoco>> GetGuidesByCategoryAsync(int categoryId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", categoryId);

                var result = await connection.QueryAsync<FeatureGuidePoco>(
                    "sp_GetGuidesByCategory", parameters, commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGuidesByCategoryAsync failed for categoryId={CategoryId}", categoryId);
                return new List<FeatureGuidePoco>();
            }
        }

        // ============================================================
        // SHOP - User
        // ============================================================

        public async Task<List<ShopCategoryPoco>> GetShopCategoriesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ShopCategoryPoco>(
                    "sp_Web_Shop_GetCategories", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetShopCategoriesAsync failed");
                return new List<ShopCategoryPoco>();
            }
        }

        public async Task<(List<ShopItemPoco> Items, int TotalCount)> GetShopItemsAsync(int? categoryId, int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", categoryId);
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<ShopItemPoco>(
                    "sp_Web_Shop_GetItems", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetShopItemsAsync failed");
                return (new List<ShopItemPoco>(), 0);
            }
        }

        public async Task<ShopItemPoco> GetShopItemByIdAsync(int itemId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@itemId", itemId);

                return await connection.QueryFirstOrDefaultAsync<ShopItemPoco>(
                    "sp_Web_Shop_GetItemById", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetShopItemByIdAsync failed for itemId={ItemId}", itemId);
                return null;
            }
        }

        public async Task<ShopPurchaseResult> PurchaseShopItemAsync(string username, int itemId, int quantity, string ipAddress)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@itemId", itemId);
                parameters.Add("@quantity", quantity);
                parameters.Add("@ipAddress", ipAddress);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@newBalance", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@purchaseId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_Shop_PurchaseItem", parameters, commandType: CommandType.StoredProcedure);

                return new ShopPurchaseResult
                {
                    ResultCode = parameters.Get<int>("@result"),
                    NewBalance = parameters.Get<int>("@newBalance"),
                    PurchaseId = parameters.Get<int>("@purchaseId")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "PurchaseShopItemAsync failed: user={Username}, item={ItemId}", username, itemId);
                return new ShopPurchaseResult { ResultCode = -99 };
            }
        }

        public async Task<ShopPurchaseResult> GiftShopItemAsync(string username, int itemId, string recipientUsername, string ipAddress)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@itemId", itemId);
                parameters.Add("@recipientUsername", recipientUsername);
                parameters.Add("@ipAddress", ipAddress);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@newBalance", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@purchaseId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_Shop_GiftItem", parameters, commandType: CommandType.StoredProcedure);

                return new ShopPurchaseResult
                {
                    ResultCode = parameters.Get<int>("@result"),
                    NewBalance = parameters.Get<int>("@newBalance"),
                    PurchaseId = parameters.Get<int>("@purchaseId")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GiftShopItemAsync failed: user={Username}, item={ItemId}, recipient={Recipient}", username, itemId, recipientUsername);
                return new ShopPurchaseResult { ResultCode = -99 };
            }
        }

        public async Task<(List<ShopPurchasePoco> Items, int TotalCount)> GetShopPurchaseHistoryAsync(string username, int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var items = await connection.QueryAsync<ShopPurchasePoco>(
                    "sp_Web_Shop_GetPurchaseHistory", parameters, commandType: CommandType.StoredProcedure);
                int totalCount = parameters.Get<int>("@totalCount");

                return (items.AsList(), totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetShopPurchaseHistoryAsync failed for user={Username}", username);
                return (new List<ShopPurchasePoco>(), 0);
            }
        }

        public async Task<int> GetShopDailyPurchaseCountAsync(string username, int itemId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@itemId", itemId);

                return await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_Web_Shop_GetDailyPurchaseCount", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetShopDailyPurchaseCountAsync failed");
                return 0;
            }
        }

        public async Task<bool> CheckUserExistsAsync(string username)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);

                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_Web_Shop_CheckUserExists", parameters, commandType: CommandType.StoredProcedure);
                return result == 1;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "CheckUserExistsAsync failed for user={Username}", username);
                return false;
            }
        }

        public async Task<int> GetUserBalanceAsync(string username)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);

                return await connection.QueryFirstOrDefaultAsync<int>(
                    "sp_Web_Shop_GetUserBalance", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetUserBalanceAsync failed for user={Username}", username);
                return 0;
            }
        }

        private static int GetDefaultDailyCheckInRewardCoins(int streakDay)
        {
            if (streakDay <= 0)
                return DailyCheckInRewards[0];

            if (streakDay <= DailyCheckInRewards.Length)
                return DailyCheckInRewards[streakDay - 1];

            var lastReward = DailyCheckInRewards[^1];
            return lastReward + (streakDay - DailyCheckInRewards.Length) * 100;
        }

        private async Task EnsureDailyCheckInRewardConfigTableAsync(SqlConnection connection)
        {
            await connection.ExecuteAsync(@"
                IF OBJECT_ID(N'dbo.Web_DailyCheckInRewardRule', N'U') IS NULL
                BEGIN
                    CREATE TABLE dbo.Web_DailyCheckInRewardRule (
                        RewardRuleId INT IDENTITY(1,1) PRIMARY KEY,
                        DayNumber INT NOT NULL,
                        RewardCoins INT NOT NULL DEFAULT(0),
                        IsActive BIT NOT NULL DEFAULT(1),
                        SortOrder INT NOT NULL DEFAULT(0),
                        CreatedDate DATETIME2 NOT NULL DEFAULT(GETDATE())
                    );

                    CREATE UNIQUE INDEX UX_Web_DailyCheckInRewardRule_DayNumber
                        ON dbo.Web_DailyCheckInRewardRule (DayNumber);

                    CREATE INDEX IX_Web_DailyCheckInRewardRule_IsActive_DayNumber
                        ON dbo.Web_DailyCheckInRewardRule (IsActive, DayNumber);
                END;
            ");

            var count = await connection.QuerySingleOrDefaultAsync<int>(@"SELECT COUNT(*) FROM dbo.Web_DailyCheckInRewardRule");
            if (count == 0)
            {
                var defaultRules = DailyCheckInRewards.Select((reward, index) => new { DayNumber = index + 1, RewardCoins = reward, SortOrder = index + 1 }).ToList();
                foreach (var rule in defaultRules)
                {
                    await connection.ExecuteAsync(@"
                        INSERT INTO dbo.Web_DailyCheckInRewardRule (DayNumber, RewardCoins, IsActive, SortOrder, CreatedDate)
                        VALUES (@DayNumber, @RewardCoins, 1, @SortOrder, GETDATE())
                    ", rule);
                }
            }
        }

        private async Task<int> GetDailyCheckInRewardCoinsAsync(SqlConnection connection, int streakDay)
        {
            await EnsureDailyCheckInRewardConfigTableAsync(connection);

            var rules = (await connection.QueryAsync<DailyCheckInRewardRulePoco>(@"
                SELECT RewardRuleId, DayNumber, RewardCoins, IsActive, SortOrder, CreatedDate
                FROM dbo.Web_DailyCheckInRewardRule
                WHERE IsActive = 1
                ORDER BY DayNumber ASC
            ")).AsList();

            if (rules.Count > 0)
            {
                var exact = rules.FirstOrDefault(x => x.DayNumber == streakDay);
                if (exact != null)
                    return exact.RewardCoins;

                var fallback = rules.Where(x => x.DayNumber < streakDay)
                    .OrderByDescending(x => x.DayNumber)
                    .FirstOrDefault();

                if (fallback != null)
                    return fallback.RewardCoins;

                return rules[0].RewardCoins;
            }

            return 0;
        }

        private async Task EnsureDailyCheckInTableAsync(SqlConnection connection)
        {
            await connection.ExecuteAsync(@"
                IF OBJECT_ID(N'dbo.Web_DailyCheckIn', N'U') IS NULL
                BEGIN
                    CREATE TABLE dbo.Web_DailyCheckIn (
                        Id INT IDENTITY(1,1) PRIMARY KEY,
                        Username NVARCHAR(50) NOT NULL,
                        CheckInDate DATE NOT NULL,
                        StreakDay INT NOT NULL DEFAULT(1),
                        RewardCoins INT NOT NULL DEFAULT(0),
                        CreatedDate DATETIME2 NOT NULL DEFAULT(GETDATE())
                    );

                    CREATE UNIQUE INDEX UX_Web_DailyCheckIn_Username_CheckInDate
                        ON dbo.Web_DailyCheckIn (Username, CheckInDate);

                    CREATE INDEX IX_Web_DailyCheckIn_Username_CheckInDate
                        ON dbo.Web_DailyCheckIn (Username, CheckInDate DESC);
                END;
            ");
        }

        public async Task<DailyCheckInStatePoco> GetDailyCheckInStateAsync(string username)
        {
            var state = new DailyCheckInStatePoco { Username = username ?? string.Empty, Message = "Bạn chưa điểm danh hôm nay." };
            if (string.IsNullOrWhiteSpace(username))
                return state;

            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInTableAsync(connection);

                state.Balance = await GetUserBalanceAsync(username);

                var history = (await connection.QueryAsync<DailyCheckInHistoryPoco>(
                    @"SELECT TOP 30 Id, Username, CheckInDate, StreakDay, RewardCoins, CreatedDate
                      FROM dbo.Web_DailyCheckIn
                      WHERE Username = @username
                      ORDER BY CheckInDate DESC",
                    new { username })).ToList();

                state.RecentHistory = history;
                if (history.Count == 0)
                {
                    state.TodayRewardCoins = await GetDailyCheckInRewardCoinsAsync(connection, 1);
                    state.NextRewardCoins = state.TodayRewardCoins;
                    return state;
                }

                var latest = history[0];
                state.LastCheckInDate = latest.CheckInDate;
                state.CurrentStreak = latest.StreakDay;
                var today = DateTime.UtcNow.AddHours(7).Date;
                state.CheckedInToday = latest.CheckInDate.Date == today;
                if (!state.CheckedInToday && latest.CheckInDate.Date < today.AddDays(-1)) state.CurrentStreak = 0;
                state.TotalClaimed = await connection.ExecuteScalarAsync<int>("SELECT ISNULL(SUM(RewardCoins),0) FROM dbo.Web_DailyCheckIn WHERE Username=@username", new {username});
                state.NextRewardCoins = state.CheckedInToday ? 0 : await GetDailyCheckInRewardCoinsAsync(connection, state.CurrentStreak + 1);
                state.TodayRewardCoins = state.NextRewardCoins == 0 ? await GetDailyCheckInRewardCoinsAsync(connection, state.CurrentStreak) : state.NextRewardCoins;
                state.Message = state.CheckedInToday
                    ? "Bạn đã điểm danh hôm nay. Hãy quay lại vào ngày mai để tiếp tục chuỗi." 
                    : "Sẵn sàng nhận thưởng điểm danh mới.";

                return state;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetDailyCheckInStateAsync failed for user={Username}", username);
                return state;
            }
        }

        public async Task<DailyCheckInClaimResult> ClaimDailyCheckInAsync(string username)
        {
            using var connection = new SqlConnection(_connectionString);
            await EnsureDailyCheckInTableAsync(connection);
            return await connection.QuerySingleAsync<DailyCheckInClaimResult>("sp_Web_DailyCheckIn_Claim", new { username }, commandType: CommandType.StoredProcedure);
        }

        public async Task<List<DailyCheckInRewardRulePoco>> GetDailyCheckInRewardRulesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInRewardConfigTableAsync(connection);
                var result = await connection.QueryAsync<DailyCheckInRewardRulePoco>(@"
                    SELECT RewardRuleId, DayNumber, RewardCoins, IsActive, SortOrder, CreatedDate
                    FROM dbo.Web_DailyCheckInRewardRule
                    ORDER BY DayNumber ASC");
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetDailyCheckInRewardRulesAsync failed");
                return new List<DailyCheckInRewardRulePoco>();
            }
        }

        public async Task<DailyCheckInRewardRulePoco> GetDailyCheckInRewardRuleByIdAsync(int ruleId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInRewardConfigTableAsync(connection);
                return await connection.QueryFirstOrDefaultAsync<DailyCheckInRewardRulePoco>(@"
                    SELECT RewardRuleId, DayNumber, RewardCoins, IsActive, SortOrder, CreatedDate
                    FROM dbo.Web_DailyCheckInRewardRule
                    WHERE RewardRuleId = @ruleId",
                    new { ruleId });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetDailyCheckInRewardRuleByIdAsync failed for ruleId={RuleId}", ruleId);
                return null;
            }
        }

        public async Task<int> CreateDailyCheckInRewardRuleAsync(DailyCheckInRewardRulePoco rule)
        {
            if (rule == null || rule.DayNumber <= 0 || rule.RewardCoins < 0)
                return 0;

            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInRewardConfigTableAsync(connection);

                var existing = await connection.QueryFirstOrDefaultAsync<int?>(@"
                    SELECT RewardRuleId
                    FROM dbo.Web_DailyCheckInRewardRule
                    WHERE DayNumber = @DayNumber",
                    new { rule.DayNumber });
                if (existing.HasValue)
                    return -1;

                var sortOrder = rule.SortOrder > 0 ? rule.SortOrder : (await connection.QuerySingleOrDefaultAsync<int>(@"
                    SELECT ISNULL(MAX(SortOrder), 0) + 1 FROM dbo.Web_DailyCheckInRewardRule"));

                return await connection.ExecuteScalarAsync<int>(@"
                    INSERT INTO dbo.Web_DailyCheckInRewardRule (DayNumber, RewardCoins, IsActive, SortOrder, CreatedDate)
                    VALUES (@DayNumber, @RewardCoins, @IsActive, @SortOrder, GETDATE());
                    SELECT CAST(SCOPE_IDENTITY() AS INT);
                ", new { rule.DayNumber, rule.RewardCoins, IsActive = rule.IsActive, SortOrder = sortOrder });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "CreateDailyCheckInRewardRuleAsync failed");
                return -99;
            }
        }

        public async Task<int> UpdateDailyCheckInRewardRuleAsync(DailyCheckInRewardRulePoco rule)
        {
            if (rule == null || rule.RewardRuleId <= 0 || rule.DayNumber <= 0 || rule.RewardCoins < 0)
                return 0;

            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInRewardConfigTableAsync(connection);

                var existing = await connection.QueryFirstOrDefaultAsync<int?>(@"
                    SELECT RewardRuleId
                    FROM dbo.Web_DailyCheckInRewardRule
                    WHERE DayNumber = @DayNumber AND RewardRuleId <> @RewardRuleId",
                    new { rule.DayNumber, rule.RewardRuleId });
                if (existing.HasValue)
                    return -1;

                return await connection.ExecuteAsync(@"
                    UPDATE dbo.Web_DailyCheckInRewardRule
                    SET DayNumber = @DayNumber,
                        RewardCoins = @RewardCoins,
                        IsActive = @IsActive,
                        SortOrder = @SortOrder
                    WHERE RewardRuleId = @RewardRuleId
                ", rule);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "UpdateDailyCheckInRewardRuleAsync failed for ruleId={RuleId}", rule.RewardRuleId);
                return -99;
            }
        }

        public async Task<int> ToggleDailyCheckInRewardRuleAsync(int ruleId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInRewardConfigTableAsync(connection);
                return await connection.ExecuteAsync(@"
                    UPDATE dbo.Web_DailyCheckInRewardRule
                    SET IsActive = CASE WHEN IsActive = 1 THEN 0 ELSE 1 END
                    WHERE RewardRuleId = @ruleId
                ", new { ruleId });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "ToggleDailyCheckInRewardRuleAsync failed for ruleId={RuleId}", ruleId);
                return -99;
            }
        }

        public async Task<int> DeleteDailyCheckInRewardRuleAsync(int ruleId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                await EnsureDailyCheckInRewardConfigTableAsync(connection);
                return await connection.ExecuteAsync(@"
                    DELETE FROM dbo.Web_DailyCheckInRewardRule
                    WHERE RewardRuleId = @ruleId
                ", new { ruleId });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "DeleteDailyCheckInRewardRuleAsync failed for ruleId={RuleId}", ruleId);
                return -99;
            }
        }

        // ============================================================
        // SHOP - Admin
        // ============================================================

        public async Task<List<ShopItemPoco>> GetAllShopItemsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ShopItemPoco>(
                    "sp_Web_Shop_AdminGetAllItems", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllShopItemsAsync failed");
                return new List<ShopItemPoco>();
            }
        }

        public async Task<List<ShopCategoryPoco>> GetAllShopCategoriesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<ShopCategoryPoco>(
                    "sp_Web_Shop_AdminGetAllCategories", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllShopCategoriesAsync failed");
                return new List<ShopCategoryPoco>();
            }
        }

        public async Task<ShopCategoryPoco> GetShopCategoryByIdAsync(int categoryId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", categoryId);

                // Reuse admin get all and filter, or direct query
                var result = await connection.QueryFirstOrDefaultAsync<ShopCategoryPoco>(
                    "SELECT CategoryId, CategoryName, DisplayOrder, IsActive, CreatedDate FROM Tbl_Web_Shop_Categories WHERE CategoryId = @categoryId",
                    parameters);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetShopCategoryByIdAsync failed for categoryId={CategoryId}", categoryId);
                return null;
            }
        }

        public async Task<int> InsertShopItemAsync(ShopItemPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", item.CategoryId);
                parameters.Add("@itemName", item.ItemName);
                parameters.Add("@description", item.Description);
                parameters.Add("@iconPath", item.IconPath);
                parameters.Add("@originalPrice", item.OriginalPrice);
                parameters.Add("@currentPrice", item.CurrentPrice);
                parameters.Add("@cashItemId", item.CashItemId);
                parameters.Add("@cashItemCount", item.CashItemCount);
                parameters.Add("@maxPurchasePerDay", item.MaxPurchasePerDay);
                parameters.Add("@isFeatured", item.IsFeatured);
                parameters.Add("@displayOrder", item.DisplayOrder);
                parameters.Add("@isActive", item.IsActive);
                parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_Shop_AdminCreateItem", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "InsertShopItemAsync failed");
                return -1;
            }
        }

        public async Task<int> UpdateShopItemAsync(ShopItemPoco item)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@itemId", item.ItemId);
                parameters.Add("@categoryId", item.CategoryId);
                parameters.Add("@itemName", item.ItemName);
                parameters.Add("@description", item.Description);
                parameters.Add("@iconPath", item.IconPath);
                parameters.Add("@originalPrice", item.OriginalPrice);
                parameters.Add("@currentPrice", item.CurrentPrice);
                parameters.Add("@cashItemId", item.CashItemId);
                parameters.Add("@cashItemCount", item.CashItemCount);
                parameters.Add("@maxPurchasePerDay", item.MaxPurchasePerDay);
                parameters.Add("@isFeatured", item.IsFeatured);
                parameters.Add("@displayOrder", item.DisplayOrder);
                parameters.Add("@isActive", item.IsActive);

                return await connection.ExecuteScalarAsync<int>("sp_Web_Shop_AdminUpdateItem", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "UpdateShopItemAsync failed for itemId={ItemId}", item.ItemId);
                return 0;
            }
        }

        public async Task<int> DeleteShopItemAsync(int itemId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@itemId", itemId);

                return await connection.ExecuteScalarAsync<int>("sp_Web_Shop_AdminDeleteItem", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "DeleteShopItemAsync failed for itemId={ItemId}", itemId);
                return 0;
            }
        }

        public async Task<int> InsertShopCategoryAsync(ShopCategoryPoco category)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryName", category.CategoryName);
                parameters.Add("@displayOrder", category.DisplayOrder);
                parameters.Add("@isActive", category.IsActive);
                parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_Shop_AdminCreateCategory", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "InsertShopCategoryAsync failed");
                return -1;
            }
        }

        public async Task<int> UpdateShopCategoryAsync(ShopCategoryPoco category)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@categoryId", category.CategoryId);
                parameters.Add("@categoryName", category.CategoryName);
                parameters.Add("@displayOrder", category.DisplayOrder);
                parameters.Add("@isActive", category.IsActive);

                return await connection.ExecuteScalarAsync<int>("sp_Web_Shop_AdminUpdateCategory", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "UpdateShopCategoryAsync failed for categoryId={CategoryId}", category.CategoryId);
                return 0;
            }
        }

        public async Task<(int ResultCode, int NewBalance)> AdminAddCoinsAsync(string adminUsername, string targetUsername, int amount, string reason)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@adminUsername", adminUsername);
                parameters.Add("@targetUsername", targetUsername);
                parameters.Add("@amount", amount);
                parameters.Add("@reason", reason);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@newBalance", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_Shop_AdminAddCoins", parameters, commandType: CommandType.StoredProcedure);

                return (parameters.Get<int>("@result"), parameters.Get<int>("@newBalance"));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AdminAddCoinsAsync failed: admin={Admin}, target={Target}, amount={Amount}", adminUsername, targetUsername, amount);
                return (-99, 0);
            }
        }

        // ============================================================
        // SPENDING MILESTONE (Mốc tiêu phí — tích lũy mua shop)
        // ============================================================

        public async Task<List<SpendingMilestonePoco>> GetActiveSpendingMilestonesAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var rows = await connection.QueryAsync<SpendingMilestonePoco>(
                    "sp_Web_GetSpendingMilestones", commandType: CommandType.StoredProcedure);
                return rows.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetActiveSpendingMilestonesAsync failed");
                return new List<SpendingMilestonePoco>();
            }
        }

        public async Task<decimal> GetUserSpendingInRangeAsync(string username, DateTime rangeStart, DateTime rangeEnd)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@range_start", rangeStart);
                parameters.Add("@range_end", rangeEnd);
                parameters.Add("@total", dbType: DbType.Decimal, direction: ParameterDirection.Output, precision: 18, scale: 0);

                await connection.ExecuteAsync("sp_Web_GetUserSpendingInRange", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<decimal>("@total");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetUserSpendingInRangeAsync failed for user={Username}", username);
                return 0m;
            }
        }

        public async Task<List<SpendingMilestoneClaimPoco>> GetUserSpendingClaimsAsync(string username)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var rows = await connection.QueryAsync<SpendingMilestoneClaimPoco>(
                    "sp_Web_GetUserSpendingClaims",
                    new { username },
                    commandType: CommandType.StoredProcedure);
                return rows.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetUserSpendingClaimsAsync failed for user={Username}", username);
                return new List<SpendingMilestoneClaimPoco>();
            }
        }

        public async Task<(int ResultCode, int ClaimID)> TryInsertSpendingClaimAsync(int milestoneId, string username, string periodKey, decimal spendingAmount, int rewardCoins)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@milestone_id", milestoneId);
                parameters.Add("@username", username);
                parameters.Add("@period_key", periodKey);
                parameters.Add("@spending_amount", spendingAmount);
                parameters.Add("@reward_coins", rewardCoins);
                parameters.Add("@claim_id", dbType: DbType.Int32, direction: ParameterDirection.Output);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_TryInsertSpendingClaim", parameters, commandType: CommandType.StoredProcedure);
                return (parameters.Get<int>("@result"), parameters.Get<int>("@claim_id"));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "TryInsertSpendingClaimAsync failed: milestone={MilestoneId} user={Username} key={PeriodKey}",
                    milestoneId, username, periodKey);
                return (-1, 0);
            }
        }

        public async Task UpdateSpendingClaimStatusAsync(int claimId, string status, string note = null)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@claim_id", claimId);
                parameters.Add("@status", status);
                parameters.Add("@note", note);

                await connection.ExecuteAsync("sp_Web_UpdateSpendingClaimStatus", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "UpdateSpendingClaimStatusAsync failed for claim={ClaimId}", claimId);
            }
        }

        /// <summary>
        /// Orchestrator. Compute current period for each active milestone, sum user spending in range,
        /// and atomically claim any milestone where spending >= threshold AND not yet claimed for this PeriodKey.
        /// Returns the list of newly-granted claims so the caller can deliver items via IShopDeliveryService.
        /// </summary>
        public async Task<List<SpendingMilestoneGrantResult>> TryGrantSpendingMilestonesAsync(string username)
        {
            var grants = new List<SpendingMilestoneGrantResult>();
            if (string.IsNullOrEmpty(username)) return grants;

            try
            {
                var milestones = await GetActiveSpendingMilestonesAsync();
                if (milestones.Count == 0) return grants;

                var now = DateTime.Now;
                foreach (var m in milestones)
                {
                    if (!TryComputePeriod(m, now, out var periodKey, out var rangeStart, out var rangeEnd))
                        continue; // milestone not currently in active period (e.g. DateRange expired)

                    // For non-Lifetime periods + CountHistorical=false, clamp range start to milestone CreatedDate
                    if (!m.CountHistoricalPurchases && rangeStart < m.CreatedDate)
                        rangeStart = m.CreatedDate;

                    if (rangeStart >= rangeEnd) continue;

                    var spent = await GetUserSpendingInRangeAsync(username, rangeStart, rangeEnd);
                    if (spent < m.ThresholdAmount) continue;

                    var (rc, claimId) = await TryInsertSpendingClaimAsync(m.MilestoneID, username, periodKey, spent, m.RewardCoins);
                    if (rc == 1 && claimId > 0)
                    {
                        grants.Add(new SpendingMilestoneGrantResult
                        {
                            MilestoneID  = m.MilestoneID,
                            ClaimID      = claimId,
                            MilestoneName = m.MilestoneName,
                            RewardCoins  = m.RewardCoins,
                            RewardItems  = m.RewardItems
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "TryGrantSpendingMilestonesAsync failed for user={Username}", username);
            }

            return grants;
        }

        /// <summary>
        /// Compute the active period window + PeriodKey string for a milestone at a given moment.
        /// Returns false if the milestone is not currently active (e.g. DateRange outside [start,end]).
        /// </summary>
        public static bool TryComputePeriod(SpendingMilestonePoco m, DateTime now, out string periodKey, out DateTime rangeStart, out DateTime rangeEnd)
        {
            periodKey = string.Empty;
            rangeStart = DateTime.MinValue;
            rangeEnd = DateTime.MaxValue;

            switch ((m.PeriodType ?? "Lifetime").Trim())
            {
                case "Lifetime":
                    periodKey  = "LIFETIME";
                    rangeStart = new DateTime(2000, 1, 1);
                    rangeEnd   = now.AddSeconds(1);
                    return true;

                case "Monthly":
                    periodKey  = now.ToString("yyyy-MM");
                    rangeStart = new DateTime(now.Year, now.Month, 1);
                    rangeEnd   = rangeStart.AddMonths(1);
                    return true;

                case "Weekly":
                {
                    var weekStartDay = m.WeekStartDay ?? 1; // default Monday
                    if (weekStartDay < 1 || weekStartDay > 7) weekStartDay = 1;

                    // Map .NET DayOfWeek (Sunday=0..Saturday=6) → ISO (Monday=1..Sunday=7)
                    int isoDow = ((int)now.DayOfWeek + 6) % 7 + 1;
                    int daysFromStart = ((isoDow - weekStartDay) + 7) % 7;
                    var weekStart = now.Date.AddDays(-daysFromStart);

                    rangeStart = weekStart;
                    rangeEnd   = weekStart.AddDays(7);
                    periodKey  = weekStart.ToString("yyyy-MM-dd"); // unique per week
                    return true;
                }

                case "DateRange":
                    if (m.PeriodStartDate == null || m.PeriodEndDate == null) return false;
                    if (now < m.PeriodStartDate.Value || now >= m.PeriodEndDate.Value) return false;
                    rangeStart = m.PeriodStartDate.Value;
                    rangeEnd   = m.PeriodEndDate.Value;
                    periodKey  = "DR-" + m.MilestoneID;
                    return true;

                default:
                    return false;
            }
        }

        // ----- Spending Milestone (admin) -----

        public async Task<(List<SpendingMilestonePoco> Items, int TotalCount)> GetAllSpendingMilestonesAsync(int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@page", page);
                parameters.Add("@pageSize", pageSize);
                parameters.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var rows = await connection.QueryAsync<SpendingMilestonePoco>(
                    "sp_Admin_GetSpendingMilestones", parameters, commandType: CommandType.StoredProcedure);
                return (rows.ToList(), parameters.Get<int>("@totalCount"));
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetAllSpendingMilestonesAsync failed");
                return (new List<SpendingMilestonePoco>(), 0);
            }
        }

        public async Task<SpendingMilestonePoco> GetSpendingMilestoneByIdAsync(int milestoneId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<SpendingMilestonePoco>(
                    "sp_Admin_GetSpendingMilestoneById",
                    new { milestone_id = milestoneId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetSpendingMilestoneByIdAsync failed for id={Id}", milestoneId);
                return null;
            }
        }

        public async Task<int> CreateSpendingMilestoneAsync(SpendingMilestonePoco m)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@milestone_name",    m.MilestoneName);
                parameters.Add("@threshold_amount",  m.ThresholdAmount);
                parameters.Add("@period_type",       m.PeriodType ?? "Lifetime");
                parameters.Add("@week_start_day",    m.WeekStartDay);
                parameters.Add("@period_start_date", m.PeriodStartDate);
                parameters.Add("@period_end_date",   m.PeriodEndDate);
                parameters.Add("@count_historical",  m.CountHistoricalPurchases);
                parameters.Add("@reward_coins",      m.RewardCoins);
                parameters.Add("@reward_items",      m.RewardItems);
                parameters.Add("@description",       m.Description);
                parameters.Add("@sort_order",        m.SortOrder);
                parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Admin_CreateSpendingMilestone", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateSpendingMilestoneAsync failed");
                return -1;
            }
        }

        public async Task<int> UpdateSpendingMilestoneAsync(SpendingMilestonePoco m)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@milestone_id",      m.MilestoneID);
                parameters.Add("@milestone_name",    m.MilestoneName);
                parameters.Add("@threshold_amount",  m.ThresholdAmount);
                parameters.Add("@period_type",       m.PeriodType ?? "Lifetime");
                parameters.Add("@week_start_day",    m.WeekStartDay);
                parameters.Add("@period_start_date", m.PeriodStartDate);
                parameters.Add("@period_end_date",   m.PeriodEndDate);
                parameters.Add("@count_historical",  m.CountHistoricalPurchases);
                parameters.Add("@reward_coins",      m.RewardCoins);
                parameters.Add("@reward_items",      m.RewardItems);
                parameters.Add("@description",       m.Description);
                parameters.Add("@sort_order",        m.SortOrder);
                parameters.Add("@is_active",         m.IsActive);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Admin_UpdateSpendingMilestone", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@result");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateSpendingMilestoneAsync failed for id={Id}", m.MilestoneID);
                return -1;
            }
        }

        public async Task<int> ToggleSpendingMilestoneAsync(int milestoneId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@milestone_id", milestoneId);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Admin_ToggleSpendingMilestone", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@result");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "ToggleSpendingMilestoneAsync failed for id={Id}", milestoneId);
                return 0;
            }
        }

        // ============================================================
        // DEPOSIT (SePay)
        // ============================================================

        public async Task<int> CreateDepositAsync(string username, decimal amount)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);
                parameters.Add("@amount", amount);
                parameters.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_CreateDeposit", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateDepositAsync failed for user {User} amount {Amount}", username, amount);
                return 0;
            }
        }

        public async Task<int> CompleteDepositAsync(int transactionId, int sepayId, string referenceCode, decimal transferAmount)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@transaction_id", transactionId);
                parameters.Add("@sepay_id", sepayId);
                parameters.Add("@reference_code", referenceCode);
                parameters.Add("@transfer_amount", transferAmount);
                parameters.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_CompleteDeposit", parameters, commandType: CommandType.StoredProcedure);
                return parameters.Get<int>("@result");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CompleteDepositAsync failed for transactionId={Id}", transactionId);
                return -99;
            }
        }

        public async Task<TransactionPoco> GetTransactionStatusAsync(int transactionId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@transaction_id", transactionId);

                return await connection.QueryFirstOrDefaultAsync<TransactionPoco>(
                    "sp_Web_GetTransactionStatus", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetTransactionStatusAsync failed for id={Id}", transactionId);
                return null;
            }
        }

        public async Task<List<DepositBonusPoco>> GetActiveBonusTiersAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var result = await connection.QueryAsync<DepositBonusPoco>(
                    "sp_Web_Bonus_GetActive", commandType: CommandType.StoredProcedure);
                return result.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetActiveBonusTiersAsync failed");
                return new List<DepositBonusPoco>();
            }
        }

        // ============================================================
        // GIFT BOX (Mở Hộp Quà) — User
        // ============================================================

        public async Task<GiftBoxConfigPoco> GetGiftBoxActiveConfigAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<GiftBoxConfigPoco>(
                    "sp_Web_GiftBox_GetActiveConfig", commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxActiveConfigAsync failed");
                return null;
            }
        }

        public async Task<GiftBoxStatePoco> GetGiftBoxStateAsync(string username)
        {
            var state = new GiftBoxStatePoco();
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);

                using var multi = await connection.QueryMultipleAsync(
                    "sp_Web_GiftBox_GetState", parameters, commandType: CommandType.StoredProcedure);

                state.Config = (await multi.ReadAsync<GiftBoxConfigPoco>()).FirstOrDefault();
                var progress = (await multi.ReadAsync<GiftBoxProgressRow>()).FirstOrDefault();
                if (progress != null)
                {
                    state.CurrentRound = progress.CurrentRound;
                    state.RoundOrdinal = progress.RoundOrdinal;
                    state.NextCost = progress.NextCost;
                    state.CostStep = progress.CostStep;
                    state.AdvanceMode = progress.AdvanceMode;
                    state.Status = progress.Status;
                }
                state.Boxes = (await multi.ReadAsync<GiftBoxBoxPoco>()).AsList();
                state.Balance = (await multi.ReadAsync<int>()).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxStateAsync failed for user={Username}", username);
            }
            return state;
        }

        public async Task<GiftBoxOpenResult> OpenGiftBoxAsync(string username, int boxIndex, string ipAddress)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@username", username);
                p.Add("@boxIndex", boxIndex);
                p.Add("@ipAddress", ipAddress);
                p.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@giftId", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@giftName", dbType: DbType.String, size: 150, direction: ParameterDirection.Output);
                p.Add("@iconPath", dbType: DbType.String, size: 300, direction: ParameterDirection.Output);
                p.Add("@rewardType", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@cashItemId", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@cashItemCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@coinAmount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@isAdvance", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                p.Add("@newBalance", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@nextRound", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@isLastRound", dbType: DbType.Boolean, direction: ParameterDirection.Output);
                p.Add("@newRoundBoxCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@nextCost", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@replayed", dbType: DbType.Boolean, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_GiftBox_OpenBox", p, commandType: CommandType.StoredProcedure);

                return new GiftBoxOpenResult
                {
                    ResultCode = p.Get<int>("@result"),
                    GiftId = p.Get<int?>("@giftId") ?? 0,
                    GiftName = p.Get<string>("@giftName"),
                    IconPath = p.Get<string>("@iconPath"),
                    RewardType = p.Get<int>("@rewardType"),
                    CashItemId = p.Get<int>("@cashItemId"),
                    CashItemCount = p.Get<int>("@cashItemCount"),
                    CoinAmount = p.Get<int>("@coinAmount"),
                    IsAdvance = p.Get<bool>("@isAdvance"),
                    NewBalance = p.Get<int>("@newBalance"),
                    NextRound = p.Get<int>("@nextRound"),
                    IsLastRound = p.Get<bool>("@isLastRound"),
                    NewRoundBoxCount = p.Get<int>("@newRoundBoxCount"),
                    NextCost = p.Get<int>("@nextCost"),
                    Replayed = p.Get<bool>("@replayed")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "OpenGiftBoxAsync failed: user={Username}, box={BoxIndex}", username, boxIndex);
                return new GiftBoxOpenResult { ResultCode = -99 };
            }
        }

        // ============================================================
        // GIFT BOX — Admin (Config / Round / Gift)
        // ============================================================

        public async Task<List<GiftBoxConfigPoco>> GetGiftBoxConfigsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var rows = await connection.QueryAsync<GiftBoxConfigPoco>(
                    "sp_Web_GiftBox_Admin_GetConfigs", commandType: CommandType.StoredProcedure);
                return rows.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxConfigsAsync failed");
                return new List<GiftBoxConfigPoco>();
            }
        }

        public async Task<GiftBoxConfigPoco> GetGiftBoxConfigByIdAsync(int configId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@configId", configId);
                return await connection.QueryFirstOrDefaultAsync<GiftBoxConfigPoco>(
                    "sp_Web_GiftBox_Admin_GetConfigById", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxConfigByIdAsync failed for configId={ConfigId}", configId);
                return null;
            }
        }

        public async Task<int> InsertGiftBoxConfigAsync(GiftBoxConfigPoco config)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@eventName", config.EventName);
                p.Add("@description", config.Description);
                p.Add("@costType", config.CostType);
                p.Add("@costAmount", config.CostAmount);
                p.Add("@isActive", config.IsActive);
                p.Add("@allowReplay", config.AllowReplay);
                p.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);
                await connection.ExecuteAsync("sp_Web_GiftBox_Admin_InsertConfig", p, commandType: CommandType.StoredProcedure);
                return p.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertGiftBoxConfigAsync failed");
                return 0;
            }
        }

        public async Task<int> UpdateGiftBoxConfigAsync(GiftBoxConfigPoco config)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@configId", config.ConfigId);
                p.Add("@eventName", config.EventName);
                p.Add("@description", config.Description);
                p.Add("@costType", config.CostType);
                p.Add("@costAmount", config.CostAmount);
                p.Add("@isActive", config.IsActive);
                p.Add("@allowReplay", config.AllowReplay);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_UpdateConfig", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateGiftBoxConfigAsync failed for configId={ConfigId}", config.ConfigId);
                return 0;
            }
        }

        public async Task<int> DeleteGiftBoxConfigAsync(int configId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@configId", configId);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_DeleteConfig", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteGiftBoxConfigAsync failed for configId={ConfigId}", configId);
                return 0;
            }
        }

        public async Task<int> SetGiftBoxActiveAsync(int configId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@configId", configId);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_SetActive", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SetGiftBoxActiveAsync failed for configId={ConfigId}", configId);
                return 0;
            }
        }

        public async Task<int> ResetGiftBoxAsync(int configId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@configId", configId);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_Reset", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ResetGiftBoxAsync failed for configId={ConfigId}", configId);
                return 0;
            }
        }

        public async Task<List<GiftBoxRoundPoco>> GetGiftBoxRoundsAsync(int configId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@configId", configId);
                var rows = await connection.QueryAsync<GiftBoxRoundPoco>(
                    "sp_Web_GiftBox_Admin_GetRounds", parameters, commandType: CommandType.StoredProcedure);
                return rows.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxRoundsAsync failed for configId={ConfigId}", configId);
                return new List<GiftBoxRoundPoco>();
            }
        }

        public async Task<GiftBoxRoundPoco> GetGiftBoxRoundByIdAsync(int roundId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@roundId", roundId);
                return await connection.QueryFirstOrDefaultAsync<GiftBoxRoundPoco>(
                    "sp_Web_GiftBox_Admin_GetRoundById", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxRoundByIdAsync failed for roundId={RoundId}", roundId);
                return null;
            }
        }

        public async Task<int> InsertGiftBoxRoundAsync(int configId, int roundNumber, int boxCount, int costAmount, int costStep, int advanceMode)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@configId", configId);
                p.Add("@roundNumber", roundNumber);
                p.Add("@boxCount", boxCount);
                p.Add("@costAmount", costAmount);
                p.Add("@costStep", costStep);
                p.Add("@advanceMode", advanceMode);
                p.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);
                await connection.ExecuteAsync("sp_Web_GiftBox_Admin_InsertRound", p, commandType: CommandType.StoredProcedure);
                return p.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertGiftBoxRoundAsync failed for configId={ConfigId}", configId);
                return 0;
            }
        }

        public async Task<int> UpdateGiftBoxRoundAsync(int roundId, int roundNumber, int boxCount, int costAmount, int costStep, int advanceMode)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@roundId", roundId);
                p.Add("@roundNumber", roundNumber);
                p.Add("@boxCount", boxCount);
                p.Add("@costAmount", costAmount);
                p.Add("@costStep", costStep);
                p.Add("@advanceMode", advanceMode);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_UpdateRound", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateGiftBoxRoundAsync failed for roundId={RoundId}", roundId);
                return 0;
            }
        }

        public async Task<int> DeleteGiftBoxRoundAsync(int roundId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@roundId", roundId);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_DeleteRound", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteGiftBoxRoundAsync failed for roundId={RoundId}", roundId);
                return 0;
            }
        }

        public async Task<List<GiftBoxGiftPoco>> GetGiftBoxGiftsAsync(int roundId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@roundId", roundId);
                var rows = await connection.QueryAsync<GiftBoxGiftPoco>(
                    "sp_Web_GiftBox_Admin_GetGifts", parameters, commandType: CommandType.StoredProcedure);
                return rows.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxGiftsAsync failed for roundId={RoundId}", roundId);
                return new List<GiftBoxGiftPoco>();
            }
        }

        public async Task<GiftBoxGiftPoco> GetGiftBoxGiftByIdAsync(int giftId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@giftId", giftId);
                return await connection.QueryFirstOrDefaultAsync<GiftBoxGiftPoco>(
                    "sp_Web_GiftBox_Admin_GetGiftById", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetGiftBoxGiftByIdAsync failed for giftId={GiftId}", giftId);
                return null;
            }
        }

        public async Task<int> InsertGiftBoxGiftAsync(GiftBoxGiftPoco gift)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@roundId", gift.RoundId);
                p.Add("@giftName", gift.GiftName);
                p.Add("@iconPath", gift.IconPath);
                p.Add("@rewardType", gift.RewardType);
                p.Add("@cashItemId", gift.CashItemId);
                p.Add("@cashItemCount", gift.CashItemCount);
                p.Add("@coinAmount", gift.CoinAmount);
                p.Add("@isAdvance", gift.IsAdvance);
                p.Add("@isActive", gift.IsActive);
                p.Add("@displayOrder", gift.DisplayOrder);
                p.Add("@weight", gift.Weight);
                p.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);
                await connection.ExecuteAsync("sp_Web_GiftBox_Admin_InsertGift", p, commandType: CommandType.StoredProcedure);
                return p.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertGiftBoxGiftAsync failed for roundId={RoundId}", gift.RoundId);
                return 0;
            }
        }

        public async Task<int> UpdateGiftBoxGiftAsync(GiftBoxGiftPoco gift)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@giftId", gift.GiftId);
                p.Add("@giftName", gift.GiftName);
                p.Add("@iconPath", gift.IconPath);
                p.Add("@rewardType", gift.RewardType);
                p.Add("@cashItemId", gift.CashItemId);
                p.Add("@cashItemCount", gift.CashItemCount);
                p.Add("@coinAmount", gift.CoinAmount);
                p.Add("@isAdvance", gift.IsAdvance);
                p.Add("@isActive", gift.IsActive);
                p.Add("@displayOrder", gift.DisplayOrder);
                p.Add("@weight", gift.Weight);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_UpdateGift", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateGiftBoxGiftAsync failed for giftId={GiftId}", gift.GiftId);
                return 0;
            }
        }

        public async Task<int> DeleteGiftBoxGiftAsync(int giftId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@giftId", giftId);
                return await connection.ExecuteAsync("sp_Web_GiftBox_Admin_DeleteGift", parameters, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteGiftBoxGiftAsync failed for giftId={GiftId}", giftId);
                return 0;
            }
        }

        // ============================================================
        // LUCKY WHEEL (Vòng Quay May Mắn) — user
        // ============================================================

        public async Task<LuckyWheelStatePoco> GetLuckyWheelStateAsync(string username)
        {
            var state = new LuckyWheelStatePoco();
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var parameters = new DynamicParameters();
                parameters.Add("@username", username);

                using var multi = await connection.QueryMultipleAsync(
                    "sp_Web_LuckyWheel_GetState", parameters, commandType: CommandType.StoredProcedure);

                state.Config      = (await multi.ReadAsync<LuckyWheelConfigPoco>()).FirstOrDefault();
                state.Prizes      = (await multi.ReadAsync<LuckyWheelPrizePoco>()).AsList();
                state.UserState   = (await multi.ReadAsync<LuckyWheelUserStatePoco>()).FirstOrDefault()
                                    ?? new LuckyWheelUserStatePoco();
                state.MyHistory   = (await multi.ReadAsync<LuckyWheelSpinLogPoco>()).AsList();
                state.JackpotFeed = (await multi.ReadAsync<LuckyWheelSpinLogPoco>()).AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelStateAsync failed for user={Username}", username);
            }
            return state;
        }

        public async Task<LuckyWheelSpinResult> SpinLuckyWheelAsync(string username, int spinCount, string ipAddress)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@username", username);
                p.Add("@spinCount", spinCount);
                p.Add("@ipAddress", ipAddress);
                p.Add("@result", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@spinsDone", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@newBalance", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@newTickets", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@freeRemaining", dbType: DbType.Int32, direction: ParameterDirection.Output);
                p.Add("@dayRemaining", dbType: DbType.Int32, direction: ParameterDirection.Output);

                List<LuckyWheelSpinEntry> spins;
                using (var multi = await connection.QueryMultipleAsync(
                    "sp_Web_LuckyWheel_Spin", p, commandType: CommandType.StoredProcedure))
                {
                    spins = (await multi.ReadAsync<LuckyWheelSpinEntry>()).AsList();
                }

                return new LuckyWheelSpinResult
                {
                    ResultCode    = p.Get<int>("@result"),
                    SpinsDone     = p.Get<int>("@spinsDone"),
                    NewBalance    = p.Get<int>("@newBalance"),
                    NewTickets    = p.Get<int>("@newTickets"),
                    FreeRemaining = p.Get<int>("@freeRemaining"),
                    DayRemaining  = p.Get<int>("@dayRemaining"),
                    Spins         = spins
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SpinLuckyWheelAsync failed: user={Username}, count={Count}", username, spinCount);
                return new LuckyWheelSpinResult { ResultCode = -99 };
            }
        }

        public async Task<int> GrantLuckyWheelTicketsAsync(string username, int amount, string reason, int refId = 0)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@username", username);
                p.Add("@amount", amount);
                p.Add("@reason", reason);
                p.Add("@refId", refId);

                await connection.ExecuteAsync("sp_Web_LuckyWheel_GrantTickets", p, commandType: CommandType.StoredProcedure);
                return 1;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GrantLuckyWheelTicketsAsync failed: user={Username}, amount={Amount}", username, amount);
                return -1;
            }
        }

        public async Task<int> GetLuckyWheelTicketsAsync(string username)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.ExecuteScalarAsync<int>(
                    "sp_Web_LuckyWheel_GetTickets",
                    new { username },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelTicketsAsync failed for user={Username}", username);
                return 0;
            }
        }

        // ============================================================
        // LUCKY WHEEL — admin (Config / Prize / Log)
        // ============================================================

        public async Task<List<LuckyWheelConfigPoco>> GetLuckyWheelConfigsAsync()
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var rows = await connection.QueryAsync<LuckyWheelConfigPoco>(
                    "sp_Web_LuckyWheel_Admin_GetConfigs", commandType: CommandType.StoredProcedure);
                return rows.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelConfigsAsync failed");
                return new List<LuckyWheelConfigPoco>();
            }
        }

        public async Task<LuckyWheelConfigPoco> GetLuckyWheelConfigByIdAsync(int wheelId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<LuckyWheelConfigPoco>(
                    "sp_Web_LuckyWheel_Admin_GetConfigById",
                    new { wheelId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelConfigByIdAsync failed for id={Id}", wheelId);
                return null;
            }
        }

        public async Task<int> InsertLuckyWheelConfigAsync(LuckyWheelConfigPoco config)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@wheelName", config.WheelName);
                p.Add("@description", config.Description);
                p.Add("@costCoin", config.CostCoin);
                p.Add("@freeSpinsPerDay", config.FreeSpinsPerDay);
                p.Add("@maxSpinsPerDay", config.MaxSpinsPerDay);
                p.Add("@maxSpinsPerRequest", config.MaxSpinsPerRequest);
                p.Add("@spinCooldownSeconds", config.SpinCooldownSeconds);
                p.Add("@showOdds", config.ShowOdds);
                p.Add("@isActive", config.IsActive);
                p.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_LuckyWheel_Admin_InsertConfig", p, commandType: CommandType.StoredProcedure);
                return p.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertLuckyWheelConfigAsync failed");
                return -1;
            }
        }

        public async Task<int> UpdateLuckyWheelConfigAsync(LuckyWheelConfigPoco config)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@wheelId", config.WheelId);
                p.Add("@wheelName", config.WheelName);
                p.Add("@description", config.Description);
                p.Add("@costCoin", config.CostCoin);
                p.Add("@freeSpinsPerDay", config.FreeSpinsPerDay);
                p.Add("@maxSpinsPerDay", config.MaxSpinsPerDay);
                p.Add("@maxSpinsPerRequest", config.MaxSpinsPerRequest);
                p.Add("@spinCooldownSeconds", config.SpinCooldownSeconds);
                p.Add("@showOdds", config.ShowOdds);
                p.Add("@isActive", config.IsActive);

                return await connection.ExecuteAsync("sp_Web_LuckyWheel_Admin_UpdateConfig", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateLuckyWheelConfigAsync failed for id={Id}", config.WheelId);
                return -1;
            }
        }

        public async Task<int> DeleteLuckyWheelConfigAsync(int wheelId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.ExecuteAsync(
                    "sp_Web_LuckyWheel_Admin_DeleteConfig",
                    new { wheelId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteLuckyWheelConfigAsync failed for id={Id}", wheelId);
                return -1;
            }
        }

        public async Task<int> SetLuckyWheelActiveAsync(int wheelId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.ExecuteAsync(
                    "sp_Web_LuckyWheel_Admin_SetActive",
                    new { wheelId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SetLuckyWheelActiveAsync failed for id={Id}", wheelId);
                return -1;
            }
        }

        public async Task<int> ResetLuckyWheelDailyAsync(int wheelId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.ExecuteAsync(
                    "sp_Web_LuckyWheel_Admin_ResetDaily",
                    new { wheelId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ResetLuckyWheelDailyAsync failed for id={Id}", wheelId);
                return -1;
            }
        }

        public async Task<List<LuckyWheelPrizePoco>> GetLuckyWheelPrizesAsync(int wheelId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var rows = await connection.QueryAsync<LuckyWheelPrizePoco>(
                    "sp_Web_LuckyWheel_Admin_GetPrizes",
                    new { wheelId },
                    commandType: CommandType.StoredProcedure);
                return rows.AsList();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelPrizesAsync failed for wheel={WheelId}", wheelId);
                return new List<LuckyWheelPrizePoco>();
            }
        }

        public async Task<LuckyWheelPrizePoco> GetLuckyWheelPrizeByIdAsync(int prizeId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.QueryFirstOrDefaultAsync<LuckyWheelPrizePoco>(
                    "sp_Web_LuckyWheel_Admin_GetPrizeById",
                    new { prizeId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelPrizeByIdAsync failed for id={Id}", prizeId);
                return null;
            }
        }

        public async Task<int> InsertLuckyWheelPrizeAsync(LuckyWheelPrizePoco prize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@wheelId", prize.WheelId);
                p.Add("@prizeName", prize.PrizeName);
                p.Add("@iconPath", prize.IconPath);
                p.Add("@sliceColor", prize.SliceColor);
                p.Add("@rewardType", prize.RewardType);
                p.Add("@cashItemId", prize.CashItemId);
                p.Add("@cashItemCount", prize.CashItemCount);
                p.Add("@coinAmount", prize.CoinAmount);
                p.Add("@spinAmount", prize.SpinAmount);
                p.Add("@weight", prize.Weight);
                p.Add("@stockTotal", prize.StockTotal);
                p.Add("@isJackpot", prize.IsJackpot);
                p.Add("@isActive", prize.IsActive);
                p.Add("@displayOrder", prize.DisplayOrder);
                p.Add("@newId", dbType: DbType.Int32, direction: ParameterDirection.Output);

                await connection.ExecuteAsync("sp_Web_LuckyWheel_Admin_InsertPrize", p, commandType: CommandType.StoredProcedure);
                return p.Get<int>("@newId");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "InsertLuckyWheelPrizeAsync failed for wheel={WheelId}", prize.WheelId);
                return -1;
            }
        }

        public async Task<int> UpdateLuckyWheelPrizeAsync(LuckyWheelPrizePoco prize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@prizeId", prize.PrizeId);
                p.Add("@prizeName", prize.PrizeName);
                p.Add("@iconPath", prize.IconPath);
                p.Add("@sliceColor", prize.SliceColor);
                p.Add("@rewardType", prize.RewardType);
                p.Add("@cashItemId", prize.CashItemId);
                p.Add("@cashItemCount", prize.CashItemCount);
                p.Add("@coinAmount", prize.CoinAmount);
                p.Add("@spinAmount", prize.SpinAmount);
                p.Add("@weight", prize.Weight);
                p.Add("@stockTotal", prize.StockTotal);
                p.Add("@isJackpot", prize.IsJackpot);
                p.Add("@isActive", prize.IsActive);
                p.Add("@displayOrder", prize.DisplayOrder);

                return await connection.ExecuteAsync("sp_Web_LuckyWheel_Admin_UpdatePrize", p, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateLuckyWheelPrizeAsync failed for id={Id}", prize.PrizeId);
                return -1;
            }
        }

        public async Task<int> DeleteLuckyWheelPrizeAsync(int prizeId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.ExecuteAsync(
                    "sp_Web_LuckyWheel_Admin_DeletePrize",
                    new { prizeId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "DeleteLuckyWheelPrizeAsync failed for id={Id}", prizeId);
                return -1;
            }
        }

        public async Task<int> RefillLuckyWheelStockAsync(int prizeId)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                return await connection.ExecuteAsync(
                    "sp_Web_LuckyWheel_Admin_RefillStock",
                    new { prizeId },
                    commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "RefillLuckyWheelStockAsync failed for id={Id}", prizeId);
                return -1;
            }
        }

        public async Task<(List<LuckyWheelSpinLogPoco> Items, int TotalCount)> GetLuckyWheelSpinLogsAsync(
            string username, int wheelId, int page, int pageSize)
        {
            try
            {
                using var connection = new SqlConnection(_connectionString);
                var p = new DynamicParameters();
                p.Add("@username", username);
                p.Add("@wheelId", wheelId);
                p.Add("@page", page);
                p.Add("@pageSize", pageSize);
                p.Add("@totalCount", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var rows = await connection.QueryAsync<LuckyWheelSpinLogPoco>(
                    "sp_Web_LuckyWheel_Admin_GetSpinLogs", p, commandType: CommandType.StoredProcedure);
                return (rows.AsList(), p.Get<int>("@totalCount"));
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "GetLuckyWheelSpinLogsAsync failed");
                return (new List<LuckyWheelSpinLogPoco>(), 0);
            }
        }
    }
}
