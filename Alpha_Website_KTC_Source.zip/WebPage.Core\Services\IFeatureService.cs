namespace WebPage.Services
{
    /// <summary>
    /// Runtime feature flag service. Reads from FeatureFlags section in appsettings.json.
    /// Used in Views to conditionally show/hide UI elements.
    /// </summary>
    public interface IFeatureService
    {
        bool IsEnabled(string featureName);
    }
}
